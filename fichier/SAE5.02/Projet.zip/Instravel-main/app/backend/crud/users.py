from __future__ import annotations

"""CRUD pour la table `users`.

Ce module gère les opérations sur les utilisateurs (création, recherche, mise à jour)
et le chargement d'une photo de profil par défaut.
"""

from backend.database import Database, get_db
from pathlib import Path


def _load_default_photo() -> bytes | None:
    """Charge en mémoire l'image de profil par défaut (profil.jpg) si disponible.

    Le chemin est calculé relativement à ce fichier: ../../Images/profil.jpg
    (c'est-à-dire app/Images/profil.jpg dans la structure du projet).
    Retourne None si le fichier n'existe pas.
    """
    try:
        path = (Path(__file__).resolve().parent.parent.parent / "Images" / "profil.jpg")
        with open(path, "rb") as f:
            return f.read()
    except FileNotFoundError:
        return None


class UsersCRUD:
    """CRUD simple pour la table `users` (avec biographie).

    Args:
        db: Instance de :class:`backend.database.Database` (optionnelle). Si non fournie,
            la connexion singleton retournée par :func:`backend.database.get_db` est utilisée.
    """

    def __init__(self, db: Database | None = None):
        self.db = db or get_db()
        if not hasattr(self.__class__, "_default_photo_cache"):
            self.__class__._default_photo_cache = _load_default_photo()

    def get_user_by_mail_and_password(self, mail, password):
        """Récupère un utilisateur via email + mot de passe hashé.

        Note:
            Cette méthode utilise un curseur directement sur ``self.db.conn``.
        """
        cursor = self.db.conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT * FROM users WHERE mail=%s AND password=%s",
            (mail, password),
        )
        user = cursor.fetchone()
        cursor.close()
        return user

    def create_user(
        self,
        username: str,
        mail: str,
        nationalite: str | None = None,
        photo: bytes | None = None,
        password: str | None = None,
        biographie: str | None = None,
    ) -> int:
        """Crée un utilisateur.

        Args:
            username: Nom d'utilisateur.
            mail: Adresse email.
            nationalite: Nationalité (optionnelle).
            photo: Photo de profil (BLOB). Si None, une photo par défaut est utilisée si disponible.
            password: Mot de passe (hashé).
            biographie: Biographie (optionnelle).

        Returns:
            Identifiant de l'utilisateur créé.
        """
        if photo is None:
            photo = getattr(self.__class__, "_default_photo_cache", None)
        sql = """
            INSERT INTO users (username, mail, `nationalité`, photo, password, biographie)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        self.db.cursor.execute(sql, (username, mail, nationalite, photo, password, biographie))
        self.db.commit()
        return self.db.cursor.lastrowid

    def get_user(self, id_user: int) -> dict | None:
        """Récupère un utilisateur par identifiant."""
        sql = """
            SELECT id_user,
                   username,
                   mail,
                   `nationalité` AS nationalite,
                   photo,
                   password,
                   biographie,
                   status
            FROM users
            WHERE id_user = %s
        """
        self.db.cursor.execute(sql, (id_user,))
        return self.db.cursor.fetchone()

    def get_user_by_username(self, username: str) -> dict | None:
        """Récupère un utilisateur par nom d'utilisateur."""
        sql = """
            SELECT id_user,
                   username,
                   mail,
                   `nationalité` AS nationalite,
                   photo,
                   password,
                   biographie,
                   status
            FROM users
            WHERE username = %s
            LIMIT 1
        """
        self.db.cursor.execute(sql, (username,))
        return self.db.cursor.fetchone()
    
    def get_user_by_mail(self, mail: str) -> dict | None:
        """Récupère un utilisateur par adresse email."""
        sql = """
            SELECT id_user,
                   username,
                   mail,
                   `nationalité` AS nationalite,
                   photo,
                   password,
                   biographie
            FROM users
            WHERE mail = %s
            LIMIT 1
        """
        self.db.cursor.execute(sql, (mail,))
        return self.db.cursor.fetchone()

    def get_users(self) -> list[dict]:
        """Liste les utilisateurs."""
        sql = """
            SELECT id_user,
                   username,
                   mail,
                   `nationalité` AS nationalite,
                   photo,
                   password,
                   biographie
            FROM users
            ORDER BY id_user DESC
        """
        self.db.cursor.execute(sql)
        return self.db.cursor.fetchall()

    def update_user(
        self,
        id_user: int,
        *,
        username: str | None = None,
        mail: str | None = None,
        nationalite: str | None = None,
        photo: bytes | None = None,
        password: str | None = None,
        biographie: str | None = None,
        status: str | None = None,
    ) -> bool:
        """Met à jour un utilisateur.

        Args:
            id_user: Identifiant de l'utilisateur.

        Returns:
            True si une ligne a été modifiée.
        """
        field_map = {
            "username": "username",
            "mail": "mail",
            "nationalite": "`nationalité`",
            "photo": "photo",
            "password": "password",
            "biographie": "biographie",
            "status": "status",
        }
        values: list = []
        sets: list[str] = []

        if username is not None:
            sets.append(f"{field_map['username']} = %s")
            values.append(username)
        if mail is not None:
            sets.append(f"{field_map['mail']} = %s")
            values.append(mail)
        if nationalite is not None:
            sets.append(f"{field_map['nationalite']} = %s")
            values.append(nationalite)
        if photo is not None:
            sets.append(f"{field_map['photo']} = %s")
            values.append(photo)
        if password is not None:
            sets.append(f"{field_map['password']} = %s")
            values.append(password)
        if biographie is not None:
            sets.append(f"{field_map['biographie']} = %s")
            values.append(biographie)
        if status is not None:
            sets.append(f"{field_map['status']} = %s")
            values.append(status)

        if not sets:
            return False

        sql = f"UPDATE users SET {', '.join(sets)} WHERE id_user = %s"
        values.append(id_user)
        self.db.cursor.execute(sql, values)
        self.db.commit()
        return self.db.cursor.rowcount > 0

    def get_user_by_mail_and_password(self, mail: str, password: str) -> dict | None:
        """Récupère un utilisateur via email + mot de passe hashé."""
        sql = """
            SELECT id_user,
                   username,
                   mail,
                   `nationalité` AS nationalite,
                   photo,
                   password,
                   biographie
            FROM users
            WHERE mail = %s AND password = %s
            LIMIT 1
        """
        self.db.cursor.execute(sql, (mail, password))
        return self.db.cursor.fetchone()


    def delete_user(self, id_user: int) -> bool:
        """Supprime un utilisateur et purge ses relations d'abonnement si possible."""
        try:
            from backend.crud.abonnement import AbonnementCRUD
            AbonnementCRUD(self.db).purge_user(id_user)
        except Exception:
            pass
        sql = "DELETE FROM users WHERE id_user = %s"
        self.db.cursor.execute(sql, (id_user,))
        self.db.commit()
        return self.db.cursor.rowcount > 0
    
    def close(self):
        """Ferme la connexion base de données associée."""
        self.db.close()