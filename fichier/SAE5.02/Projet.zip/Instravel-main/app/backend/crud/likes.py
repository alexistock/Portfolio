from __future__ import annotations

"""CRUD pour la table `likes`.

Ce module gère les likes déposés par les utilisateurs sur les étapes.
"""

from backend.database import Database, get_db


class likesCRUD:
    """CRUD simple pour la table `likes`.

    Args:
        db: Instance de :class:`backend.database.Database` (optionnelle). Si non fournie,
            la connexion singleton retournée par :func:`backend.database.get_db` est utilisée.
    """

    def __init__(self, db: Database | None = None):
        self.db = db or get_db()

    def create_like(
        self,
        id_user: int,
        id_etape: int,
    ) -> int:
        """Crée un like.

        Args:
            id_user: Identifiant de l'utilisateur.
            id_etape: Identifiant de l'étape.

        Returns:
            Identifiant de la ligne créée.
        """
        sql = """
            INSERT INTO likes (id_user, id_etape)
            VALUES (%s, %s)
        """
        self.db.cursor.execute(sql, (id_user, id_etape))
        self.db.commit()
        return self.db.cursor.lastrowid

    def get_like(self, id_like: int) -> dict | None:
        """Récupère un like par identifiant.

        Note:
            Cette méthode retourne actuellement le résultat de ``fetchall()``.

        Args:
            id_like: Identifiant du like.

        Returns:
            Résultat de requête (structure dépendante du driver).
        """
        sql = """
            SELECT id_like,
                   id_user,
                   id_etape
            FROM likes
            WHERE id_like = %s
        """
        self.db.cursor.execute(sql, (id_like,))
        return self.db.cursor.fetchall()

    def get_likes_by_etape(self, id_etape: int) -> list[dict] | None:
        """Liste les likes d'une étape.

        Args:
            id_etape: Identifiant de l'étape.

        Returns:
            Liste des likes.
        """
        sql = """
            SELECT id_like,
                   id_user,
                   id_etape
            FROM likes
            WHERE id_etape = %s
            ORDER BY id_like DESC
        """
        self.db.cursor.execute(sql, (id_etape,))
        return self.db.cursor.fetchall()

    def delete_like(self, id_like: int) -> bool:
        """Supprime un like.

        Args:
            id_like: Identifiant du like.

        Returns:
            True si une ligne a été supprimée.
        """
        sql = "DELETE FROM likes WHERE id_like = %s"
        self.db.cursor.execute(sql, (id_like,))
        self.db.commit()
        return self.db.cursor.rowcount > 0
    
    def delete_likes_by_etape(self, id_etape: int) -> int:
        """Supprime tous les likes associés à une étape."""
        sql = "DELETE FROM likes WHERE id_etape = %s"
        self.db.cursor.execute(sql, (id_etape,))
        self.db.commit()
        return self.db.cursor.rowcount
    
    # --- Dans le fichier likes.py, classe likesCRUD ---

    def delete_likes_by_voyage(self, id_voyage: int) -> int:
        """Supprime les likes associés aux étapes d'un voyage.

        Args:
            id_voyage: Identifiant du voyage.

        Returns:
            Nombre de likes supprimés.
        """
        sql = """
            DELETE L
            FROM likes L
            JOIN etapes E ON L.id_etape = E.id_etape
            WHERE E.id_voyage = %s
        """
        self.db.cursor.execute(sql, (id_voyage,))
        self.db.commit() # Le commit est nécessaire
        return self.db.cursor.rowcount
    
    def close(self):
        """Ferme la connexion base de données associée."""
        self.db.close()