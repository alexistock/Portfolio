from __future__ import annotations

"""CRUD pour la table `hashtag`.

Ce module gère les hashtags et fournit des helpers comme :meth:`HashtagsCRUD.get_or_create`.
"""

from backend.database import Database, get_db


class HashtagsCRUD:
    """CRUD simple pour la table `hashtag`.

    Colonnes: id_hashtag (AUTO_INCREMENT), nom_hashtag (varchar(15) NOT NULL)
    """

    def __init__(self, db: Database | None = None):
        self.db = db or get_db()

    def create_hashtag(self, nom_hashtag: str) -> int:
        """Crée un hashtag.

        Args:
            nom_hashtag: Nom du hashtag (incluant ou non ``#`` selon la convention de l'UI).

        Returns:
            Identifiant du hashtag créé.
        """
        sql = "INSERT INTO hashtag (nom_hashtag) VALUES (%s)"
        self.db.cursor.execute(sql, (nom_hashtag,))
        self.db.commit()
        return self.db.cursor.lastrowid

    def get_hashtag(self, id_hashtag: int) -> dict | None:
        """Récupère un hashtag par identifiant."""
        sql = "SELECT id_hashtag, nom_hashtag FROM hashtag WHERE id_hashtag = %s"
        self.db.cursor.execute(sql, (id_hashtag,))
        return self.db.cursor.fetchone()
    
    def search_hashtags_By_Name(self, name: str):
        """Recherche des hashtags par nom (LIKE).

        Args:
            name: Fragment de nom.

        Returns:
            Liste de hashtags correspondants.
        """
        sql = "SELECT id_hashtag, nom_hashtag FROM hashtag WHERE nom_hashtag LIKE %s"
        self.db.cursor.execute(sql, (f"%{name}%",))
        return self.db.cursor.fetchall()

    def get_hashtags(self) -> list[dict]:
        """Liste tous les hashtags."""
        sql = "SELECT id_hashtag, nom_hashtag FROM hashtag ORDER BY id_hashtag DESC"
        self.db.cursor.execute(sql)
        return self.db.cursor.fetchall()

    def update_hashtag(self, id_hashtag: int, *, nom_hashtag: str | None = None) -> bool:
        """Met à jour le nom d'un hashtag."""
        if nom_hashtag is None:
            return False
        sql = "UPDATE hashtag SET nom_hashtag = %s WHERE id_hashtag = %s"
        self.db.cursor.execute(sql, (nom_hashtag, id_hashtag))
        self.db.commit()
        return self.db.cursor.rowcount > 0

    def delete_etape_hashtags_by_voyage(self, id_voyage: int) -> bool:
        """Supprime toutes les associations etape_hashtag pour les étapes d'un voyage donné."""
        sql = """
            DELETE eh FROM etape_hashtag eh
            JOIN etapes e ON eh.id_etape = e.id_etape
            WHERE e.id_voyage = %s
        """
        self.db.cursor.execute(sql, (id_voyage,))
        self.db.commit()
        return self.db.cursor.rowcount > 0

    def delete_hashtag(self, id_hashtag: int) -> bool:
        """Supprime un hashtag."""
        sql = "DELETE FROM hashtag WHERE id_hashtag = %s"
        self.db.cursor.execute(sql, (id_hashtag,))
        self.db.commit()
        return self.db.cursor.rowcount > 0

    def get_or_create(self, nom_hashtag: str) -> int:
        """Récupère l'ID d'un hashtag par son nom, ou le crée.

        Args:
            nom_hashtag: Nom du hashtag.

        Returns:
            Identifiant du hashtag existant ou nouvellement créé.
        """
        sql_select = "SELECT id_hashtag FROM hashtag WHERE nom_hashtag = %s"
        self.db.cursor.execute(sql_select, (nom_hashtag,))
        result = self.db.cursor.fetchone()
        
        if result:
            return result['id_hashtag']
        
        sql_insert = "INSERT INTO hashtag (nom_hashtag) VALUES (%s)"
        self.db.cursor.execute(sql_insert, (nom_hashtag,))
        self.db.commit()
        
        return self.db.cursor.lastrowid

    def close(self):
        """Ferme la connexion base de données associée."""
        self.db.close()
