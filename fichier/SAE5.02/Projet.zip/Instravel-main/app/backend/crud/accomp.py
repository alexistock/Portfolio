from __future__ import annotations

"""CRUD pour la gestion des accompagnateurs d'un voyage.

Ce module fournit des accès à la table (ou vue) utilisée pour représenter les
accompagnateurs associés à un voyage.
"""

from backend.database import Database, get_db


class accompCRUD:
    """CRUD simple pour les accompagnateurs.

    Args:
        db: Instance de :class:`backend.database.Database` (optionnelle). Si non fournie,
            la connexion singleton retournée par :func:`backend.database.get_db` est utilisée.
    """

    def __init__(self, db: Database | None = None):
        self.db = db or get_db()

    def create_accompagnateur(
        self,
        id_user: int,
        id_voyage: int,
    ) -> int:
        """Crée une association utilisateur -> voyage.

        Args:
            id_user: Identifiant de l'utilisateur.
            id_voyage: Identifiant du voyage.

        Returns:
            L'identifiant de la ligne créée (``lastrowid``).
        """
        sql = """
            INSERT INTO accompagnateurs (id_user, id_voyage)
            VALUES (%s, %s)
        """
        self.db.cursor.execute(sql, (id_user, id_voyage))
        self.db.commit()
        return self.db.cursor.lastrowid

    def get_accompagnateur(self, id_accomp: int) -> dict | None:
        """Récupère un accompagnateur par identifiant.

        Args:
            id_accomp: Identifiant de l'association.

        Returns:
            Résultat de requête (structure dépendante du driver). En pratique, la méthode
            retourne actuellement une liste issue de ``fetchall()``.
        """
        sql = """
            SELECT `id_accomp`,
                   id_user,
                   id_voyage
            FROM accomp
            WHERE id_accomp = %s
        """
        self.db.cursor.execute(sql, (id_accomp,))
        return self.db.cursor.fetchall()

    def get_accompagnateurs_by_voyage(self, id_voyage: int) -> list[dict] | None:
        """Liste les accompagnateurs d'un voyage.

        Args:
            id_voyage: Identifiant du voyage.

        Returns:
            Liste de dictionnaires (une entrée par utilisateur accompagnateur).
        """
        sql = """
            SELECT id_user,
                   id_voyage
            FROM accomp
            WHERE id_voyage = %s
            ORDER BY id_voyage DESC
        """
        self.db.cursor.execute(sql, (id_voyage,))
        return self.db.cursor.fetchall()

    def delete_accompagnateurs_by_voyage(self, id_voyage: int) -> int:
        """Supprime tous les accompagnateurs associés à un voyage."""
        sql = "DELETE FROM accomp WHERE id_voyage = %s"
        self.db.cursor.execute(sql, (id_voyage,))
        self.db.commit()
        return self.db.cursor.rowcount

    def delete_accomp(self, id_accomp: int) -> bool:
        """Supprime une association accompagnateur.

        Args:
            id_accomp: Identifiant de l'association.

        Returns:
            True si une ligne a été supprimée.
        """
        sql = "DELETE FROM accomp WHERE id_accomp = %s"
        self.db.cursor.execute(sql, (id_accomp,))
        self.db.commit()
        return self.db.cursor.rowcount > 0

    def close(self):
        """Ferme la connexion base de données associée."""
        self.db.close()