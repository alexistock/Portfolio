from __future__ import annotations

"""CRUD pour la table `voyages`.

Ce module contient les opérations de création, lecture, mise à jour et suppression
de voyages.
"""

from backend.database import Database, get_db


class VoyagesCRUD:
    """CRUD simple pour la table `voyages`.

    Args:
        db: Instance de :class:`backend.database.Database` (optionnelle). Si non fournie,
            la connexion singleton retournée par :func:`backend.database.get_db` est utilisée.
    """

    def __init__(self, db: Database | None = None):
        self.db = db or get_db()

    def create_voyage(self, id_user: int, nom_voyage: str | None = None,
                      date_depart: str | None = None, date_arrivee: str | None = None) -> int:
        """Crée un voyage.

        Args:
            id_user: Identifiant du propriétaire.
            nom_voyage: Nom du voyage.
            date_depart: Date de départ (format attendu côté DB).
            date_arrivee: Date d'arrivée (format attendu côté DB).

        Returns:
            Identifiant du voyage créé.
        """
        sql = (
            """
            INSERT INTO voyages (nom_voyage, `date_départ`, `date_arrivée`, id_user)
            VALUES (%s, %s, %s, %s)
            """
        )
        self.db.cursor.execute(sql, (nom_voyage, date_depart, date_arrivee, id_user))
        self.db.commit()
        return self.db.cursor.lastrowid

    def get_voyages_by_owner(self, id_user: int) -> dict | None:
        """Liste les voyages appartenant à un utilisateur.

        Args:
            id_user: Identifiant de l'utilisateur.

        Returns:
            Liste de voyages (peut être vide).
        """
        sql = (
            """
            SELECT id_voyage, nom_voyage, `date_départ` AS date_depart, `date_arrivée` AS date_arrivee, id_user
            FROM voyages
            WHERE id_user = %s
            """
        )
        self.db.cursor.execute(sql, (id_user,))
        rows = self.db.cursor.fetchall()
        return rows or []


    def get_voyage(self, id_voyage: int) -> dict | None:
        """Récupère un voyage par identifiant."""
        sql = (
            """
            SELECT id_voyage, nom_voyage, `date_départ` AS date_depart, `date_arrivée` AS date_arrivee, id_user
            FROM voyages
            WHERE id_voyage = %s
            """
        )
        self.db.cursor.execute(sql, (id_voyage,))
        return self.db.cursor.fetchone()

    def get_voyages(self) -> list[dict]:
        """Liste tous les voyages."""
        sql = (
            """
            SELECT id_voyage, nom_voyage, `date_départ` AS date_depart, `date_arrivée` AS date_arrivee, id_user
            FROM voyages
            ORDER BY id_voyage DESC
            """
        )
        self.db.cursor.execute(sql)
        return self.db.cursor.fetchall()



    def update_voyage(self, id_voyage: int, *, nom_voyage: str | None = None, id_user: int | None = None,
                       date_depart: str | None = None, date_arrivee: str | None = None) -> bool:
        """Met à jour un voyage.

        Args:
            id_voyage: Identifiant du voyage.
            nom_voyage: Nouveau nom.
            id_user: Nouveau propriétaire.
            date_depart: Nouvelle date de départ.
            date_arrivee: Nouvelle date d'arrivée.

        Returns:
            True si une ligne a été modifiée.
        """
        field_map = {
            "nom_voyage": "nom_voyage",
            "id_user": "id_user",
            "date_depart": "`date_départ`",
            "date_arrivee": "`date_arrivée`",
        }
        values: list = []
        sets: list[str] = []

        if nom_voyage is not None:
            sets.append(f"{field_map['nom_voyage']} = %s")
            values.append(nom_voyage)
        if id_user is not None:
            sets.append(f"{field_map['id_user']} = %s")
            values.append(id_user)
        if date_depart is not None:
            sets.append(f"{field_map['date_depart']} = %s")
            values.append(date_depart)
        if date_arrivee is not None:
            sets.append(f"{field_map['date_arrivee']} = %s")
            values.append(date_arrivee)

        if not sets:
            return False

        sql = f"UPDATE voyages SET {', '.join(sets)} WHERE id_voyage = %s"
        values.append(id_voyage)
        self.db.cursor.execute(sql, values)
        self.db.commit()
        return self.db.cursor.rowcount > 0

    def delete_voyage(self, id_voyage: int) -> bool:
        """Supprime un voyage."""
        sql = "DELETE FROM voyages WHERE id_voyage = %s"
        self.db.cursor.execute(sql, (id_voyage,))
        self.db.commit()
        return self.db.cursor.rowcount > 0

    def close(self):
        """Ferme la connexion base de données associée."""
        self.db.close()
