from __future__ import annotations

"""CRUD pour la table `commentaires`.

Schéma (dump):
    commentaires(
        id_comm INT AUTO_INCREMENT PRIMARY KEY,
        commentaire LONGTEXT NOT NULL,
        date_comm DATETIME DEFAULT CURRENT_TIMESTAMP,
        id_user INT NOT NULL,
        id_etape INT NOT NULL,
        id_hashtag INT NULL (optionnel dans dump mais nous gérons via table de jointure comm_hashtag)
    )

On n'utilise pas id_hashtag ici afin de privilégier la table de jointure `comm_hashtag`.
"""

from typing import List, Optional
from backend.database import Database, get_db


class CommentairesCRUD:
    """CRUD pour la table `commentaires`.

    Args:
        db: Instance de :class:`backend.database.Database` (optionnelle). Si non fournie,
            la connexion singleton retournée par :func:`backend.database.get_db` est utilisée.
    """

    def __init__(self, db: Database | None = None):
        self.db = db or get_db()

    def create_commentaire(self, commentaire: str, id_user: int, id_etape: int) -> int:
        """Crée un commentaire.

        Args:
            commentaire: Contenu texte du commentaire.
            id_user: Identifiant de l'auteur.
            id_etape: Identifiant de l'étape concernée.

        Returns:
            Identifiant du commentaire créé.
        """
        sql = (
            """
            INSERT INTO commentaires (commentaire, id_user, id_etape)
            VALUES (%s, %s, %s)
            """
        )
        self.db.cursor.execute(sql, (commentaire, id_user, id_etape))
        self.db.commit()
        return self.db.cursor.lastrowid

    def get_commentaire(self, id_comm: int) -> dict | None:
        """Récupère un commentaire par identifiant."""
        sql = (
            """
            SELECT id_comm, commentaire, date_comm, id_user, id_etape
            FROM commentaires
            WHERE id_comm = %s
            """
        )
        self.db.cursor.execute(sql, (id_comm,))
        return self.db.cursor.fetchone()

    def get_commentaires_for_etape(self, id_etape: int) -> List[dict]:
        """Liste les commentaires d'une étape.

        La requête effectue une jointure vers `users` afin de retourner le champ `username`.

        Args:
            id_etape: Identifiant de l'étape.

        Returns:
            Liste de commentaires (dictionnaires).
        """
        sql = (
            """
            SELECT c.id_comm,
                   c.commentaire,
                   c.date_comm,
                   c.id_user,
                   c.id_etape,
                   u.username
            FROM commentaires c
            JOIN users u ON u.id_user = c.id_user
            WHERE c.id_etape = %s
            ORDER BY c.id_comm DESC
            """
        )
        self.db.cursor.execute(sql, (id_etape,))
        return self.db.cursor.fetchall()

    def delete_commentaire(self, id_comm: int) -> bool:
        """Supprime un commentaire."""
        sql = "DELETE FROM commentaires WHERE id_comm = %s"
        self.db.cursor.execute(sql, (id_comm,))
        self.db.commit()
        return self.db.cursor.rowcount > 0

    # Dans la classe CommentairesCRUD
    def delete_commentaires_by_voyage(self, id_voyage: int) -> bool:
        """Supprime tous les commentaires pour un voyage donné (via jointure avec `etapes`)."""
        # Joindre étapes et commentaires pour trouver tous les commentaires du voyage
        sql = """
            DELETE c FROM commentaires c
            JOIN etapes e ON c.id_etape = e.id_etape
            WHERE e.id_voyage = %s
        """
        self.db.cursor.execute(sql, (id_voyage,))
        self.db.commit()
        return self.db.cursor.rowcount > 0
    def delete_commentaires_by_etape(self, id_etape: int) -> int:
        """Supprime tous les commentaires pour une étape donnée."""
        sql = "DELETE FROM commentaires WHERE id_etape = %s"
        self.db.cursor.execute(sql, (id_etape,))
        self.db.commit() # <<< CRITIQUE : Assure que la suppression est appliquée
        return self.db.cursor.rowcount
    
    def close(self):
        """Ferme la connexion base de données associée."""
        self.db.close()