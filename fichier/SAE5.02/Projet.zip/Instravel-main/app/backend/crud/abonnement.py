from __future__ import annotations

"""CRUD pour la table `abonnement` (relations de suivi entre utilisateurs).

Table (simpliste) :
    abonnement(id_user1 INT NOT NULL, id_user2 INT NOT NULL)

Convention :
    - id_user1 suit id_user2 (follower -> followed)
    - Pas de clé primaire déclarée dans le dump, on considère (id_user1, id_user2) comme unique.
"""

from backend.database import Database, get_db


class AbonnementCRUD:
    """CRUD pour la table `abonnement`.

    La table `abonnement` modélise les relations de suivi entre utilisateurs.

    Convention:
        - `id_user1` suit `id_user2` (follower -> followed)

    Args:
        db: Instance de :class:`backend.database.Database` (optionnelle). Si non fournie,
            la connexion singleton retournée par :func:`backend.database.get_db` est utilisée.
    """

    def __init__(self, db: Database | None = None):
        self.db = db or get_db()

    def follow(self, follower_id: int, followed_id: int) -> bool:
        """Crée une relation de suivi.

        Args:
            follower_id: Identifiant de l'utilisateur qui suit.
            followed_id: Identifiant de l'utilisateur suivi.

        Returns:
            True si l'insertion a été effectuée.
        """
        if follower_id == followed_id:
            return False
        if self.is_following(follower_id, followed_id):
            return False
        sql = "INSERT INTO abonnement (id_user1, id_user2) VALUES (%s, %s)"
        self.db.cursor.execute(sql, (follower_id, followed_id))
        self.db.commit()
        return self.db.cursor.rowcount > 0

    def unfollow(self, follower_id: int, followed_id: int) -> bool:
        """Supprime une relation de suivi."""
        sql = "DELETE FROM abonnement WHERE id_user1 = %s AND id_user2 = %s"
        self.db.cursor.execute(sql, (follower_id, followed_id))
        self.db.commit()
        return self.db.cursor.rowcount > 0

    def is_following(self, follower_id: int, followed_id: int) -> bool:
        """Indique si `follower_id` suit `followed_id`."""
        sql = (
            "SELECT 1 FROM abonnement WHERE id_user1 = %s AND id_user2 = %s LIMIT 1"
        )
        self.db.cursor.execute(sql, (follower_id, followed_id))
        return self.db.cursor.fetchone() is not None

    def get_followers(self, user_id: int) -> list[dict]:
        """Liste les followers (abonnés) d'un utilisateur."""
        sql = (
            """
            SELECT u.id_user, u.username, u.mail
            FROM abonnement a
            JOIN users u ON u.id_user = a.id_user1
            WHERE a.id_user2 = %s
            ORDER BY u.id_user DESC
            """
        )
        self.db.cursor.execute(sql, (user_id,))
        return self.db.cursor.fetchall()

    def get_following(self, user_id: int) -> list[dict]:
        """Liste les comptes suivis par un utilisateur."""
        sql = (
            """
            SELECT u.id_user, u.username, u.mail
            FROM abonnement a
            JOIN users u ON u.id_user = a.id_user2
            WHERE a.id_user1 = %s
            ORDER BY u.id_user DESC
            """
        )
        self.db.cursor.execute(sql, (user_id,))
        return self.db.cursor.fetchall()

    def count_followers(self, user_id: int) -> int:
        """Compte le nombre de followers d'un utilisateur."""
        sql = "SELECT COUNT(*) AS c FROM abonnement WHERE id_user2 = %s"
        self.db.cursor.execute(sql, (user_id,))
        row = self.db.cursor.fetchone()
        return int(row["c"]) if row else 0

    def count_following(self, user_id: int) -> int:
        """Compte le nombre de comptes suivis par un utilisateur."""
        sql = "SELECT COUNT(*) AS c FROM abonnement WHERE id_user1 = %s"
        self.db.cursor.execute(sql, (user_id,))
        row = self.db.cursor.fetchone()
        return int(row["c"]) if row else 0

    def is_mutual(self, user_a: int, user_b: int) -> bool:
        """Indique si deux utilisateurs se suivent mutuellement."""
        return self.is_following(user_a, user_b) and self.is_following(user_b, user_a)

    def get_mutuals(self, user_id: int) -> list[dict]:
        """Liste les abonnements mutuels d'un utilisateur."""
        sql = (
            """
            SELECT u.id_user, u.username, u.mail
            FROM abonnement a
            JOIN abonnement b ON a.id_user2 = b.id_user1 AND b.id_user2 = a.id_user1
            JOIN users u ON u.id_user = a.id_user2
            WHERE a.id_user1 = %s
            ORDER BY u.id_user DESC
            """
        )
        self.db.cursor.execute(sql, (user_id,))
        return self.db.cursor.fetchall()

    def purge_user(self, user_id: int) -> int:
        """Supprime toutes les relations d'abonnement impliquant un utilisateur.

        Args:
            user_id: Identifiant de l'utilisateur.

        Returns:
            Nombre de lignes supprimées.
        """
        sql = "DELETE FROM abonnement WHERE id_user1 = %s OR id_user2 = %s"
        self.db.cursor.execute(sql, (user_id, user_id))
        self.db.commit()
        return self.db.cursor.rowcount

    def close(self):
        """Ferme la connexion base de données associée."""
        self.db.close()
