import customtkinter as ctk
import threading
from geopy.geocoders import Nominatim

class LocationEntry(ctk.CTkFrame):
    def __init__(self, master, width=320, placeholder_text="Ex: Paris, France", *args, **kwargs):
        super().__init__(master, fg_color="transparent", *args, **kwargs)
        
        self.geolocator = Nominatim(user_agent="mon_app_voyage_unique_id_v3") # ID unique
        
        self.width = width
        self.search_timer = None
        
        self.is_valid_selection = False 
        
        # Layout
        self.entry = ctk.CTkEntry(self, width=self.width, placeholder_text=placeholder_text)
        self.entry.pack(anchor="w", pady=(0, 2))
        
        self.entry.bind("<KeyRelease>", self.on_key_release)
        
        self.suggestion_frame = ctk.CTkScrollableFrame(self, width=self.width, height=150, fg_color="#2b2b2b")

    def get(self): return self.entry.get()
    def delete(self, first, last=None): self.entry.delete(first, last)
    def insert(self, index, string): self.entry.insert(index, string)

    # --- NOUVEAU : Méthode pour définir une valeur initiale valide (pour EditStage) ---
    def set_value(self, text):
        """Utilisé pour pré-remplir le champ (considéré comme valide)"""
        self.entry.delete(0, "end")
        self.entry.insert(0, text)
        self.is_valid_selection = True
        self.entry.configure(border_color=["#979DA2", "#565B5E"]) # Couleur par défaut CTk

    # --- NOUVEAU : Getter pour vérifier la validité ---
    def is_selection_valid(self):
        return self.is_valid_selection

    def on_key_release(self, event):
        if event.keysym in ["Return", "Up", "Down"]: return
        
        # --- MODIFICATION : Dès qu'on tape, c'est invalide ---
        self.is_valid_selection = False
        self.entry.configure(border_color="red") # Feedback visuel immédiat
        
        text = self.entry.get()
        if len(text) < 3:
            self.hide_suggestions()
            return
        if self.search_timer: self.search_timer.cancel()
        self.search_timer = threading.Timer(0.5, self.perform_search, [text])
        self.search_timer.start()

    def perform_search(self, query):
        try:
            locations = self.geolocator.geocode(
                query, exactly_one=False, limit=5, language='fr', addressdetails=True 
            )
            self.after(0, lambda: self.update_suggestions(locations))
        except Exception as e:
            print(f"Erreur geopy: {e}")

    def update_suggestions(self, locations):
        for widget in self.suggestion_frame.winfo_children():
            widget.destroy()

        if not locations:
            self.hide_suggestions()
            return

        self.show_suggestions()
        seen_labels = set()

        for loc in locations:
            address = loc.raw.get("address", {})
            city = (address.get("city") or address.get("town") or address.get("village") or 
                    address.get("municipality") or address.get("hamlet") or 
                    address.get("administrative") or address.get("state"))
            country = address.get("country")

            if city and country:
                clean_label = f"{city}, {country}"
            else:
                clean_label = loc.address.split(",")[0] + (f", {country}" if country else "")

            if clean_label in seen_labels: continue
            seen_labels.add(clean_label)
            
            btn = ctk.CTkButton(
                self.suggestion_frame, text=clean_label, anchor="w",
                fg_color="transparent", hover_color="#404040", height=30,
                command=lambda a=clean_label: self.select_location(a)
            )
            btn.pack(fill="x")

    def select_location(self, address):
        self.entry.delete(0, "end")
        self.entry.insert(0, address)
        self.hide_suggestions()
        
        # --- MODIFICATION : La sélection valide l'entrée ---
        self.is_valid_selection = True
        self.entry.configure(border_color="green") # Feedback visuel de succès

    def show_suggestions(self):
        self.suggestion_frame.pack(anchor="w", pady=(0, 5))

    def hide_suggestions(self):
        self.suggestion_frame.pack_forget()