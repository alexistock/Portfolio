-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: final_version_instravel
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abonnement`
--

DROP TABLE IF EXISTS `abonnement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `abonnement` (
  `id_user1` int NOT NULL,
  `id_user2` int NOT NULL,
  KEY `id_user1` (`id_user1`),
  KEY `id_user2` (`id_user2`),
  CONSTRAINT `abonnement_ibfk_1` FOREIGN KEY (`id_user1`) REFERENCES `users` (`id_user`),
  CONSTRAINT `abonnement_ibfk_2` FOREIGN KEY (`id_user2`) REFERENCES `users` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abonnement`
--

LOCK TABLES `abonnement` WRITE;
/*!40000 ALTER TABLE `abonnement` DISABLE KEYS */;
/*!40000 ALTER TABLE `abonnement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accomp`
--

DROP TABLE IF EXISTS `accomp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accomp` (
  `id_user` int NOT NULL,
  `id_voyage` int NOT NULL,
  KEY `id_user` (`id_user`),
  KEY `id_voyage` (`id_voyage`),
  CONSTRAINT `accomp_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`),
  CONSTRAINT `accomp_ibfk_2` FOREIGN KEY (`id_voyage`) REFERENCES `voyages` (`id_voyage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accomp`
--

LOCK TABLES `accomp` WRITE;
/*!40000 ALTER TABLE `accomp` DISABLE KEYS */;
/*!40000 ALTER TABLE `accomp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comm_hashtag`
--

DROP TABLE IF EXISTS `comm_hashtag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comm_hashtag` (
  `id_comm` int NOT NULL,
  `id_hashtag` int NOT NULL,
  KEY `id_comm` (`id_comm`),
  KEY `id_hashtag` (`id_hashtag`),
  CONSTRAINT `comm_hashtag_ibfk_1` FOREIGN KEY (`id_comm`) REFERENCES `commentaires` (`id_comm`),
  CONSTRAINT `comm_hashtag_ibfk_2` FOREIGN KEY (`id_hashtag`) REFERENCES `hashtag` (`id_hashtag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comm_hashtag`
--

LOCK TABLES `comm_hashtag` WRITE;
/*!40000 ALTER TABLE `comm_hashtag` DISABLE KEYS */;
/*!40000 ALTER TABLE `comm_hashtag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commentaires`
--

DROP TABLE IF EXISTS `commentaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commentaires` (
  `id_comm` int NOT NULL AUTO_INCREMENT,
  `commentaire` longtext NOT NULL,
  `date_comm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_user` int NOT NULL,
  `id_etape` int NOT NULL,
  `id_hashtag` int DEFAULT NULL,
  PRIMARY KEY (`id_comm`),
  KEY `id_user` (`id_user`),
  KEY `id_etape` (`id_etape`),
  KEY `id_hashtag` (`id_hashtag`),
  CONSTRAINT `commentaires_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`),
  CONSTRAINT `commentaires_ibfk_2` FOREIGN KEY (`id_etape`) REFERENCES `etapes` (`id_etape`),
  CONSTRAINT `commentaires_ibfk_3` FOREIGN KEY (`id_hashtag`) REFERENCES `hashtag` (`id_hashtag`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commentaires`
--

LOCK TABLES `commentaires` WRITE;
/*!40000 ALTER TABLE `commentaires` DISABLE KEYS */;
/*!40000 ALTER TABLE `commentaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etape_hashtag`
--

DROP TABLE IF EXISTS `etape_hashtag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `etape_hashtag` (
  `id_etape` int NOT NULL,
  `id_hashtag` int NOT NULL,
  KEY `id_etape` (`id_etape`),
  KEY `id_hashtag` (`id_hashtag`),
  CONSTRAINT `etape_hashtag_ibfk_1` FOREIGN KEY (`id_etape`) REFERENCES `etapes` (`id_etape`),
  CONSTRAINT `etape_hashtag_ibfk_2` FOREIGN KEY (`id_hashtag`) REFERENCES `hashtag` (`id_hashtag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etape_hashtag`
--

LOCK TABLES `etape_hashtag` WRITE;
/*!40000 ALTER TABLE `etape_hashtag` DISABLE KEYS */;
/*!40000 ALTER TABLE `etape_hashtag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapes`
--

DROP TABLE IF EXISTS `etapes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `etapes` (
  `id_etape` int NOT NULL AUTO_INCREMENT,
  `nom_etape` varchar(50) NOT NULL,
  `date_etape` date NOT NULL DEFAULT (curdate()),
  `description` longtext,
  `localisation` varchar(50) DEFAULT NULL,
  `nb_commentaire` int DEFAULT NULL,
  `id_voyage` int NOT NULL,
  PRIMARY KEY (`id_etape`),
  KEY `id_voyage` (`id_voyage`),
  CONSTRAINT `etapes_ibfk_1` FOREIGN KEY (`id_voyage`) REFERENCES `voyages` (`id_voyage`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapes`
--

LOCK TABLES `etapes` WRITE;
/*!40000 ALTER TABLE `etapes` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hashtag`
--

DROP TABLE IF EXISTS `hashtag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hashtag` (
  `id_hashtag` int NOT NULL AUTO_INCREMENT,
  `nom_hashtag` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id_hashtag`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hashtag`
--

LOCK TABLES `hashtag` WRITE;
/*!40000 ALTER TABLE `hashtag` DISABLE KEYS */;
/*!40000 ALTER TABLE `hashtag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `photos` (
  `id_photo` int NOT NULL AUTO_INCREMENT,
  `photo` longblob,
  `id_etape` int NOT NULL,
  PRIMARY KEY (`id_photo`),
  KEY `id_etape` (`id_etape`),
  CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`id_etape`) REFERENCES `etapes` (`id_etape`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `user`
--

DROP TABLE IF EXISTS `user`;
/*!50001 DROP VIEW IF EXISTS `user`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `user` AS SELECT 
 1 AS `id_user`,
 1 AS `username`,
 1 AS `mail`,
 1 AS `nationalité`,
 1 AS `biographie`,
 1 AS `password`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `mail` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `biographie` text,
  `nationalité` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `photo` longblob,
  `status` varchar(15) DEFAULT 'public',
  `password` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `users_public`
--

DROP TABLE IF EXISTS `users_public`;
/*!50001 DROP VIEW IF EXISTS `users_public`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `users_public` AS SELECT 
 1 AS `id_user`,
 1 AS `username`,
 1 AS `mail`,
 1 AS `nationalité`,
 1 AS `photo`,
 1 AS `biographie`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `voyages`
--

DROP TABLE IF EXISTS `voyages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voyages` (
  `id_voyage` int NOT NULL AUTO_INCREMENT,
  `nom_voyage` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date_départ` date NOT NULL DEFAULT (curdate()),
  `date_arrivée` date DEFAULT NULL,
  `id_user` int NOT NULL,
  PRIMARY KEY (`id_voyage`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `voyages_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voyages`
--

LOCK TABLES `voyages` WRITE;
/*!40000 ALTER TABLE `voyages` DISABLE KEYS */;
/*!40000 ALTER TABLE `voyages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'final_version_instravel'
--

--
-- Final view structure for view `user`
--

/*!50001 DROP VIEW IF EXISTS `user`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`InstravelApp`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `user` AS select `users`.`id_user` AS `id_user`,`users`.`username` AS `username`,`users`.`mail` AS `mail`,`users`.`nationalité` AS `nationalité`,`users`.`biographie` AS `biographie`,`users`.`password` AS `password` from `users` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `users_public`
--

/*!50001 DROP VIEW IF EXISTS `users_public`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`InstravelApp`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `users_public` AS select `users`.`id_user` AS `id_user`,`users`.`username` AS `username`,`users`.`mail` AS `mail`,`users`.`nationalité` AS `nationalité`,`users`.`photo` AS `photo`,`users`.`biographie` AS `biographie` from `users` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-23 21:20:45
