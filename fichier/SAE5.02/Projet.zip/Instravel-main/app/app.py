import customtkinter as ctk
from Pages.home import HomePage
from Pages.sign_in import SignInPage
from Pages.sign_up import SignUpPage
from Pages.edit_profil import EditProfil
from Pages.View_My_Profil import ViewMyProfilePage
from Pages.View_Other_Profil import ViewOtherProfilePage
from Pages.lost_password import LostPasswordPage
from Pages.reset_password import ResetPassword
from Pages.view_travel import ViewTravelView
from Pages.edit_travel import EditTravelView
from Pages.create_stage import CreateStageView
from Pages.view_stage import StageView
from Pages.edit_stage import EditStageView
from Pages.create_travel import CreateTravelView
from Pages.view_other_travel import ViewOtherTravelView
from Pages.view_other_stage import OtherStageView
from Pages.Error_page import ErrorPage

class Application(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Mon Application")
        self.geometry("800x500")
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        self.resizable(False, False)

        self.pages = {}       
        self.current_page = None
        self.current_user = "yaniset"  # Utilisateur par défaut
        self.current_user_id = 2
        self.destroy = False

        self.show_page("SignIn")

    def show_page(self, name, force_reload=False, **kwargs):
        if self.current_page:
            self.current_page.pack_forget()

        if name in ("LostPassword", "ResetPassword"):
            self.geometry("600x300")
        else:
            self.geometry("800x500")

        if force_reload and name in self.pages:
            self.pages[name].destroy()
            del self.pages[name]
            
        if name in ("ViewTravelDetail", "ViewMyProfile") and force_reload and "ViewMyProfile" in self.pages and name != "ViewMyProfile":
            self.pages["ViewMyProfile"].destroy()
            del self.pages["ViewMyProfile"]

        if name not in self.pages:
            if name == "SignIn":
                self.pages[name] = SignInPage(self)
            elif name == "SignUp":
                self.pages[name] = SignUpPage(self)
            elif name == "Home":
                self.pages[name] = HomePage(self, username=self.current_user)
            elif name == "ViewMyProfile":
                self.pages[name] = ViewMyProfilePage(self, username=self.current_user)
            elif name == "ViewOtherProfile":
                target_username = kwargs.get("target_username", self.current_user)
                self.pages[name] = ViewOtherProfilePage(self, viewer_username=self.current_user, target_username=target_username)
            elif name == "EditProfil":
                self.pages[name] = EditProfil(self, username=self.current_user)   
            elif name == "LostPassword":
                self.pages[name] = LostPasswordPage(self)
            elif name == "CreateTravel":
                self.pages[name] = CreateTravelView(self, id_user=self.current_user_id)
            elif name == "ViewOtherTravel":
                travel_id = kwargs.get("travel_id", None)
                self.pages[name] = ViewOtherTravelView(self, travel_id=travel_id)
            elif name == "ViewTravelDetail":
                travel_id = kwargs.get("travel_id", None)
                self.pages[name] = ViewTravelView(self, travel_id=travel_id)
            elif name == "EditTravel":
                travel_id = kwargs.get("travel_id")
                if travel_id is None:
                    raise ValueError("travel_id is required for EditTravel page")
                self.pages[name] = EditTravelView(self, travel_id=travel_id)
            elif name == "StageView":
                etape_id = kwargs.get("id_item")
                if etape_id is None:
                    raise ValueError("id_item (ID de l'étape) est requis pour StageView")
                self.pages[name] = StageView(self, etape_id=etape_id)
            elif name == "OtherStageView":
                etape_id = kwargs.get("id_item")
                if etape_id is None:
                    raise ValueError("id_item (ID de l'étape) est requis pour OtherStageView")
                self.pages[name] = OtherStageView(self, etape_id=etape_id)
            elif name == "ResetPassword":
                user = kwargs.get("user", "")
                code_verif = kwargs.get("code_verif", "")
                self.pages[name] = ResetPassword(self, user=user, code_verif=code_verif)
            elif name == "CreateStage":
                id_item = kwargs.get("id_item", None)
                if id_item is None:
                    raise ValueError("id_item (ID du voyage) est requis pour CreateStage page")
                self.pages[name] = CreateStageView(self, id_voyage=id_item)
            elif name == "EditStage":
                id_etape = kwargs.get("id_etape", None)
                if id_etape is None:
                    raise ValueError("id_etape (ID de l'étape) est requis pour EditStage page")
                self.pages[name] = EditStageView(self, etape_id=id_etape)
            elif name == "ErrorPage":
                error_message = kwargs.get("error_message")
                self.pages[name] = ErrorPage(self, error_message=error_message)    
        # Affichage de la page
        self.current_page = self.pages[name]
        self.current_page.pack(fill="both", expand=True)

if __name__ == "__main__":
    app = Application()
    app.mainloop()