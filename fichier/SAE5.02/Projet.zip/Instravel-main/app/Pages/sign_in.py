"""Page de connexion (UI).

Ce module contient l'écran permettant à un utilisateur de se connecter.
"""

import hashlib
import customtkinter as ctk
from PIL import Image
from backend.crud.users import UsersCRUD

class SignInPage(ctk.CTkFrame):
    """Écran de connexion.

    Args:
        master: Application/contrôleur principal gérant la navigation via ``show_page``.
    """

    def __init__(self, master):
        super().__init__(master)


        self.logo = ctk.CTkImage(light_image=Image.open('Images/Logo.jpg'),size=(300,150))
        self.logo_set = ctk.CTkLabel(self, text="", image=self.logo)
        self.logo_set.place(x=415, y=-30)

        self.auth_img = ctk.CTkImage(light_image=Image.open('Images/Auth_img.png'),size=(320,569))
        self.auth_img_set = ctk.CTkLabel(self, text="", image=self.auth_img)
        self.auth_img_set.place(x=0, y=0)

        self.mail = ctk.CTkLabel(self, text="Mail :", font=("Courgette", 20))
        self.mail.place(x=435, y=190)

        self.mail_widget = ctk.CTkEntry(self, width=250)
        self.mail_widget.place(x=435, y=220)

        self.password_txt = ctk.CTkLabel(self, text="Password :", font=("Courgette", 20))
        self.password_txt.place(x=435, y=260)

        self.password_widget = ctk.CTkEntry(self, show="*", width=250)
        self.password_widget.place(x=435, y=290)

        self.login_txt = ctk.CTkLabel(self, text="Bienvenue sur notre page de login !", font=("Courgette", 20))
        self.login_txt.place(x=405, y=130)

        self.login_button = ctk.CTkButton(self, width=250, height= 40, text="Connection", command=self.valide_login)
        self.login_button.place(x=435, y=330)

        self.lost_password = ctk.CTkLabel(self, text="Mot de passe oublié ?", font=("Courgette", 14), text_color="cyan", cursor="hand2")
        self.lost_password.place(x=435, y=370)
        self.lost_password.bind("<Enter>", lambda e: self.lost_password.configure(font=("Courgette", 14, "underline")))
        self.lost_password.bind("<Leave>", lambda e: self.lost_password.configure(font=("Courgette", 14)))
        self.lost_password.bind("<Button-1>", lambda e: self.master.show_page("LostPassword"))

        self.page_inscription = ctk.CTkLabel(self, text="Pas encore membre ? ", font=("Courgette", 14))
        self.page_inscription.place(x=335, y=450)

        self.page_inscription_redirect = ctk.CTkLabel(self, text="S'inscrire", font=("Courgette", 14),text_color="cyan", cursor="hand2")
        self.page_inscription_redirect.place(x=475, y=450)

        self.page_inscription_redirect.bind("<Enter>", lambda e: self.page_inscription_redirect.configure(font=("Courgette", 14, "underline")))
        self.page_inscription_redirect.bind("<Leave>", lambda e: self.page_inscription_redirect.configure(font=("Courgette", 14)))
        self.page_inscription_redirect.bind("<Button-1>", lambda e: self.master.show_page("SignUp"))

        self.label=None

    def valide_login(self):
        """Valide les identifiants et redirige vers l'accueil si succès."""
        mail = self.mail_widget.get().strip()
        password = self.password_widget.get().strip()
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        if self.label is not None:
            self.label.destroy()
            self.label=None

        if not mail or not password:
            self.label=ctk.CTkLabel(self, text="⚠️ Remplissez tous les champs", text_color="orange")
            self.label.place(x=435, y=400)
            return

        crud = UsersCRUD()
        user = crud.get_user_by_mail_and_password(mail, hashed_password)

        if user:
            username = user.get('username') if isinstance(user, dict) else str(user)
            self.master.current_user = username
            self.master.current_user_id = user.get('id_user') if isinstance(user, dict) else str(user)
            print(f"user après login {self.master.current_user_id}")
            self.label=ctk.CTkLabel(self, text=f"✅ Bienvenue {username} !", text_color="green")
            self.label.place(x=435, y=400)
            self.after(1000, lambda: self.master.show_page("Home", force_reload=True))
            if "SignIn" in self.master.pages:
                del self.master.pages["SignIn"]
        else:
            self.label = ctk.CTkLabel(self, text="❌ Identifiants invalides", text_color="red")
            self.label.place(x=435, y=400)