"""Page "mot de passe oublié" (UI).

Ce module contient l'écran permettant d'initier une réinitialisation de mot de passe
en envoyant un code de vérification par email.
"""

import random
import smtplib
from email.mime.text import MIMEText
import regex as re
import customtkinter as ctk
from backend.crud.users import UsersCRUD

class LostPasswordPage(ctk.CTkFrame):
    """Écran de demande de réinitialisation.

    Args:
        master: Application/contrôleur principal gérant la navigation via ``show_page``.
    """

    def __init__(self, master):
        """Initialise l'écran de demande de réinitialisation.

        Args:
            master: Application/contrôleur principal gérant la navigation via ``show_page``.
        """
        super().__init__(master)

        self.title = ctk.CTkLabel(self, text="Mot de passe oublié", font=("Courgette", 20))
        self.title.place (x=200, y=25)

        self.info_label = ctk.CTkLabel(self, text="Bienvenue sur la page de réinitialisation de mot de passe, afin de récupérer \n votre compte, veuillez entrer votre adresse mail : ", font=("Courgette", 14))
        self.info_label.place(x=50, y=100)

        self.email_entry = ctk.CTkEntry(self, width=250, placeholder_text="Entrez votre email")
        self.email_entry.place(x=175, y=160)

        self.send_button = ctk.CTkButton(self, text="Valider", command=self.send_reset_link)
        self.send_button.place(x=200, y=200)

        self.back_button = ctk.CTkButton(self, text="Retour", command=lambda: self.master.show_page("SignIn"))
        self.back_button.place(x=0, y=0)


    def send_reset_link(self):
        """Vérifie l'email, envoie un code, puis redirige vers la page de vérification."""
        SMTP_SERVER = "smtp.gmail.com"
        SMTP_PORT = 587
        SMTP_USER = "instravelapp@gmail.com"
        SMTP_PASSWORD = "dwoh gczn mrgr wfpf"

        email = self.email_entry.get().strip()
        if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            self.info_label.configure(text="Veuillez entrer une adresse email valide.", text_color="red")
            return
        users_crud = UsersCRUD()
        user = users_crud.get_user_by_mail(email)
        if user:
            id_user = user['id_user']
            code_verif = random.randint(100000, 999999)
            email_content = f"Bonjour {user['username']},\n\n Voici le code de vérification pour la réinitialisation du mot de passe, copier ce code dans la fenêtre de vérification afin de passer à la suite  : {code_verif}\n\nSi vous n'avez pas demandé cette réinitialisation, ignorez cet email."
            
            msg = MIMEText(email_content)
            msg['Subject'] = "Réinitialisation de votre mot de passe"
            msg['From'] = SMTP_USER
            msg['To'] = email

            try :
                with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                    server.starttls()
                    server.login(SMTP_USER, SMTP_PASSWORD)
                    server.sendmail(SMTP_USER, [email], msg.as_string())
            except Exception as e:
                self.master.show_page("ErrorPage", error_message=f"Erreur lors de l'envoi de l'email : {e}", redirect_page="SignIn")
                return
            self.info_label.configure(text="Un lien de réinitialisation a été envoyé à votre adresse email.", text_color="green")
            self.after(2000, lambda: self.master.show_page("ResetPassword", user=id_user, code_verif=code_verif))
            if "LostPassword" in self.master.pages:
                del self.master.pages["LostPassword"]
        else:
            self.info_label.configure(text="Aucun utilisateur trouvé avec cette adresse email.", text_color="red")