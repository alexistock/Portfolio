import customtkinter as ctk
from PIL import Image
from pathlib import Path
from backend.crud.photo import PhotosCRUD
from backend.crud.users import UsersCRUD
from backend.crud.abonnement import AbonnementCRUD
from backend.crud.voyages import VoyagesCRUD
from backend.crud.etapes import EtapesCRUD
from .View_Other_Profil import ViewOtherProfilePage
from PIL import ImageDraw, ImageOps
import io

BASE_DIR = Path(__file__).resolve().parent.parent
IMAGES_DIR = BASE_DIR / "Images"


def load_image(relative_name: str, size: tuple[int, int]) -> ctk.CTkImage:
    """Charge une image depuis le dossier Images et la convertit en CTkImage.
    
    Args:
        relative_name (str): Nom du fichier image relatif au dossier Images
        size (tuple[int, int]): Taille de l'image (largeur, hauteur)
        
    Returns:
        ctk.CTkImage: Image convertie pour CustomTkinter
    """
    path = IMAGES_DIR / relative_name
    try:
        img = Image.open(path)
    except FileNotFoundError:
        img = Image.new("RGB", size, color=(64, 64, 64))
    return ctk.CTkImage(light_image=img, size=size)


def create_avatar(photo_bytes, size=(40, 40)):
    """Crée un avatar circulaire à partir de données binaires d'image.
    
    Args:
        photo_bytes: Données binaires de l'image (bytes)
        size (tuple): Taille de l'avatar (largeur, hauteur), par défaut (40, 40)
        
    Returns:
        ctk.CTkImage or None: Avatar circulaire ou None si échec
    """
    if not isinstance(photo_bytes, bytes):
        return None
    try:
        raw_img = Image.open(io.BytesIO(photo_bytes)).convert("RGBA")
        raw_img = ImageOps.fit(raw_img, size, Image.LANCZOS)
        mask = Image.new("L", size, 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, size[0], size[1]), fill=255)
        raw_img.putalpha(mask)
        return ctk.CTkImage(light_image=raw_img, size=size)
    except Exception:
        return None


class ViewMyProfilePage(ctk.CTkFrame):
    """Page principale de profil utilisateur permettant de visualiser et gérer son profil.
    
    Cette classe gère l'affichage du profil de l'utilisateur connecté, incluant
    ses informations personnelles, ses voyages, ses galeries photos, et ses abonnés/abonnements.
    """
    def __init__(self, master, username: str):
        """Initialise la page de profil utilisateur.
        
        Args:
            master: Widget parent (généralement l'application principale)
            username (str): Nom d'utilisateur de l'utilisateur connecté
        """
        super().__init__(master)
        self.configure(corner_radius=0)

        self.username = username
        self.current_subpage = None

        # Load user data
        self._load_user_data()

        # Show the profile page by default
        self.show_subpage("View_Profil")

    def _load_user_data(self):
        """Charge les données utilisateur depuis la base de données.
        
        Récupère les informations du profil, les abonnés et les abonnements
        de l'utilisateur connecté et stocke ces données dans les attributs de l'instance.
        """
        user = UsersCRUD()
        data = user.get_user_by_username(self.username)
        if isinstance(data, dict):
            self.id_user = str(data.get("id_user"))
            self.username = str(data.get("username"))

            self.bio = data.get("biographie")
            if self.bio:
                self.bio = str(self.bio)

            self.nationalite = data.get("nationalite")
            if self.nationalite:
                self.nationalite = str(self.nationalite)
            else:
                self.nationalite = "Inconnu"

            self.photo = data.get("photo")

        follow = AbonnementCRUD()

        # Récupération des abonnés avec leurs infos complètes
        abonnées = follow.get_followers(self.id_user)
        self.nb_abonnées = len(abonnées)

        self.liste_abonnées = []
        for abonnée in abonnées:
            username = abonnée['username']
            # Récupérer les infos complètes de l'abonné
            abonne_data = user.get_user_by_username(username)
            if abonne_data:
                self.liste_abonnées.append({
                    'username': username,
                    'photo': abonne_data.get('photo'),
                    'bio': abonne_data.get('biographie', ''),
                    'nationalite': abonne_data.get('nationalite', '')
                })

        # Récupération des abonnements avec leurs infos complètes
        abonnements = follow.get_following(self.id_user)
        self.nb_abonnements = len(abonnements)

        self.liste_abonnements = []
        for abonnement in abonnements:
            username = abonnement['username']
            # Récupérer les infos complètes de l'abonnement
            abonne_data = user.get_user_by_username(username)
            if abonne_data:
                self.liste_abonnements.append({
                    'username': username,
                    'photo': abonne_data.get('photo'),
                    'bio': abonne_data.get('biographie', ''),
                    'nationalite': abonne_data.get('nationalite', '')
                })

    def show_subpage(self, page_name):
        """Affiche une sous-page dans la page de profil.
        
        Args:
            page_name (str): Nom de la sous-page à afficher
                           ("View_Profil", "View_All_Pictures", "View_All_Followers", "View_All_Followings")
        """
        if self.current_subpage:
            self.current_subpage.destroy()

        if page_name == "View_Profil":
            self.current_subpage = View_Profil(self)
        elif page_name == "View_All_Pictures":
            self.current_subpage = View_All_Pictures(self)
        elif page_name == "View_All_Followers":
            self.current_subpage = View_All_Followers(self)
        elif page_name == "View_All_Followings":
            self.current_subpage = View_All_Followings(self)

        self.current_subpage.pack(fill="both", expand=True)

    def go_back(self):
        """Retourne à la page précédente dans l'application principale."""
        self.master.show_page("Home", force_reload=True)

    def show_travel_details(self, id_voyage: int):
        """Affiche la page de détails d'un voyage spécifique.
        
        Args:
            id_voyage (int): Identifiant du voyage à afficher
        """
        self.master.show_page("ViewTravelDetail", travel_id=id_voyage, force_reload=True)


class View_Profil(ctk.CTkFrame):
    """Sous-page affichant les informations principales du profil utilisateur.
    
    Affiche l'avatar, le nom d'utilisateur, la biographie, la nationalité,
    les statistiques d'abonnés/abonnements, ainsi que les onglets Voyages et Galeries.
    """
    def __init__(self, master):
        """Initialise la sous-page de profil.
        
        Args:
            master: Instance de ViewMyProfilePage parente
        """
        super().__init__(master)
        self.configure(fg_color="transparent")

        # --- Fonctions de navigation locale (Pas de changement) ---
        def see_all_pictures():
            self.master.show_subpage("View_All_Pictures")

        def modify_profil():
            self.master.master.show_page("EditProfil", force_reload=True)

        def see_all_followers():
            self.master.show_subpage("View_All_Followers")

        def see_all_followings():
            self.master.show_subpage("View_All_Followings")

        # Conteneur principal
        main_frame = ctk.CTkFrame(self, corner_radius=15)
        main_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Header avec bouton retour
        header = ctk.CTkFrame(main_frame, fg_color="transparent")
        header.pack(padx=20, pady=15, fill="x")

        # Bouton retour
        back_btn = ctk.CTkButton(
            header,
            text="← Retour",
            width=80,
            command=self.master.go_back
        )
        back_btn.grid(row=0, column=0, padx=(0, 10), sticky="w")

        header.grid_columnconfigure(1, minsize=100)
        header.grid_columnconfigure(2, weight=1)
        header.grid_rowconfigure(0, weight=0)
        header.grid_rowconfigure(1, weight=0)
        header.grid_rowconfigure(2, weight=0)

        # Avatar (cercle) - Gestion des données binaires
        size = (90, 90)
        self.profile_img = None
        if isinstance(self.master.photo, bytes):
            try:
                raw_img = Image.open(io.BytesIO(self.master.photo)).convert("RGBA")
                raw_img = ImageOps.fit(raw_img, size, Image.LANCZOS)
                mask = Image.new("L", size, 0)
                draw = ImageDraw.Draw(mask)
                draw.ellipse((0, 0, size[0], size[1]), fill=255)
                raw_img.putalpha(mask)
                self.profile_img = ctk.CTkImage(light_image=raw_img, size=size)
            except Exception:
                self.profile_img = None

        self.profile_img_set = ctk.CTkLabel(header, text="", image=self.profile_img)
        self.profile_img_set.grid(row=0, column=1, rowspan=2, padx=(0, 20), sticky="nw")

        # Colonne de droite
        right = ctk.CTkFrame(header, fg_color="transparent")
        right.grid(row=0, column=2, sticky="nwe")
        right.grid_columnconfigure(0, weight=1)
        right.grid_columnconfigure(1, weight=0)

        # Ligne 0: username + bouton paramètres
        self.username = ctk.CTkLabel(
            right, text=self.master.username, font=("Courgette", 22, "bold")
        )
        self.username.grid(row=0, column=0, sticky="w")

        self.modif_btn = ctk.CTkButton(
            right, text="⚙", width=40, height=32, font=("Courgette", 18), command=modify_profil
        )
        self.modif_btn.grid(row=0, column=1, sticky="e", padx=(8, 0))

        # Ligne 1: stats
        stats = ctk.CTkFrame(right, fg_color="transparent")
        stats.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        stats.grid_columnconfigure(0, weight=1, uniform="stats")
        stats.grid_columnconfigure(1, weight=1, uniform="stats")

        def stat_block(parent, col, number, label_text, on_click=None):
            block = ctk.CTkFrame(parent, fg_color="transparent")
            block.grid(row=0, column=col, sticky="ew")
            num_lbl = ctk.CTkLabel(
                block,
                text=str(number),
                font=("Courgette", 20, "bold"),
                cursor="hand2" if on_click else "arrow",
            )
            num_lbl.pack()
            lbl = ctk.CTkLabel(block, text=label_text, font=("Courgette", 14))
            lbl.pack()
            if on_click:
                for w in (block, num_lbl, lbl):
                    w.bind("<Button-1>", lambda _e: on_click())
            return num_lbl

        self.followers_lbl = stat_block(stats, 0, self.master.nb_abonnées, "Abonnés", see_all_followers)
        self.following_lbl = stat_block(stats, 1, self.master.nb_abonnements, "Abonnements", see_all_followings)

        # Bio + nationalité (sur toute la largeur du header)
        bio_frame = ctk.CTkFrame(header, fg_color="transparent")
        bio_frame.grid(row=2, column=1, columnspan=2, sticky="ew", pady=(8, 0))

        display_bio = self.master.bio.strip() if (self.master.bio and self.master.bio.strip()) else "Aucune bio pour le moment."
        display_nat = f"Pays: {self.master.nationalite}" if self.master.nationalite else ""

        bio_label = ctk.CTkLabel(
            bio_frame, text=display_bio, font=("Courgette", 14), justify="left", anchor="w", wraplength=740
        )
        bio_label.grid(row=0, column=0, sticky="w")

        if display_nat:
            nat_label = ctk.CTkLabel(bio_frame, text=display_nat, font=("Courgette", 13), anchor="w")
            nat_label.grid(row=1, column=0, sticky="w", pady=(4, 0))

        # Onglets: Voyages + Galeries (remontés en réduisant les marges)
        photos_container = ctk.CTkFrame(main_frame, fg_color="transparent")
        photos_container.pack(padx=20, pady=(0, 0), fill="both", expand=True)

        tabs = ctk.CTkTabview(photos_container)
        tabs.pack(fill="both", expand=True, padx=6, pady=6)

        tabs.add("Voyages")
        tabs.add("Galeries")

        voyages_tab = tabs.tab("Voyages")
        galeries_tab = tabs.tab("Galeries")

        # Onglet Voyages
        voyages_list = ctk.CTkScrollableFrame(voyages_tab, fg_color="transparent")
        voyages_list.pack(fill="both", expand=True, padx=4, pady=(0, 0))

        voyages = []

        voyages_crud = VoyagesCRUD()
        photos_crud = PhotosCRUD()
        etapes_crud = EtapesCRUD()

        try:
            for voyage in voyages_crud.get_voyages_by_owner(int(self.master.id_user)):
                cover_img = "landscape2.jpg"
                cover_obj = None

                etapes = etapes_crud.get_etapes_by_voyage(voyage["id_voyage"])
                if etapes:
                    photos = photos_crud.get_photos_by_etape(etapes[0]["id_etape"])
                    if photos and photos[0].get("photo"):
                        try:
                            photo_binary = photos[0]["photo"]
                            img = Image.open(io.BytesIO(photo_binary)).convert("RGBA")
                            img = ImageOps.fit(img, (64, 64), Image.LANCZOS)
                            cover_obj = ctk.CTkImage(light_image=img, size=(64, 64))
                        except Exception:
                            cover_img = "landscape2.jpg"

                voyages.append({
                    "id_voyage": voyage["id_voyage"],
                    "titre": voyage.get("nom_voyage", "Voyage sans titre"),
                    "date": voyage.get("date_depart", ""),
                    "cover": cover_img,
                    "cover_obj": cover_obj
                })
        except Exception:
            pass

        # --- DÉFINITION DE LA FONCTION DE NAVIGATION (NETTOYÉE) ---
        def navigate_to_travel(travel_id: int, travel_data: dict):
            """Appelle la méthode du contrôleur de profil pour la navigation"""
            if travel_id:
                self.master.show_travel_details(travel_id)
            else:
                pass

        # --- BOUCLE CORRIGÉE POUR LA NAVIGATION ---
        for i, v in enumerate(voyages):
            # --- Capture des données pour la lambda ---
            current_travel_id = v.get("id_voyage")
            current_travel_data = v

            item = ctk.CTkFrame(
                voyages_list,
                corner_radius=12,
                fg_color="#1f1f1f" if i % 2 == 0 else "#232323",
            )
            item.pack(fill="x", padx=4, pady=4)

            left = ctk.CTkFrame(item, fg_color="transparent")
            left.pack(side="left", padx=10, pady=6)

            # Utiliser cover_obj (photo de la BDD) si disponible, sinon fallback sur l'image par défaut
            if v.get("cover_obj"):
                cover = v.get("cover_obj")
            else:
                cover = load_image(v.get("cover", "landscape1.jpg"), (64, 64))
            cover_lbl = ctk.CTkLabel(left, text="", image=cover)
            cover_lbl.pack(side="left", padx=(0, 10))

            text_col = ctk.CTkFrame(left, fg_color="transparent")
            text_col.pack(side="left")

            titre_lbl = ctk.CTkLabel(text_col, text=v["titre"], font=("Courgette", 16, "bold"))
            titre_lbl.pack(anchor="w")
            date_lbl = ctk.CTkLabel(text_col, text=v.get("date", ""), font=("Courgette", 13))
            date_lbl.pack(anchor="w")

            # Commande du Bouton "Ouvrir"
            action_btn = ctk.CTkButton(
                item, text="Ouvrir", width=100, height=32,
                # CORRECTION : La lambda capture les données et l'ID du voyage pour cette itération
                command=lambda id=current_travel_id, data=current_travel_data: navigate_to_travel(id, data)
            )
            action_btn.pack(side="right", padx=10, pady=6)

            # Commande de la Carte (Clic)
            for w in (item, left, cover_lbl, text_col, titre_lbl, date_lbl):
                w.configure(cursor="hand2")
                # CORRECTION : La lambda capture les données et l'ID du voyage
                w.bind("<Button-1>", lambda _e, id=current_travel_id, data=current_travel_data: navigate_to_travel(id, data))
        # --- FIN DE LA BOUCLE CORRIGÉE ---

        # Onglet Galeries
        gallery_scroll = ctk.CTkScrollableFrame(galeries_tab, fg_color="transparent")
        gallery_scroll.pack(fill="both", expand=True, padx=4, pady=(0, 0))

        grid = ctk.CTkFrame(gallery_scroll, fg_color="transparent")
        grid.pack(fill="both", expand=True)

        gallery_items: list[tuple[ctk.CTkImage, int]] = []

        self.voyages = voyages_crud.get_voyages_by_owner(self.master.id_user)

        # Récupérer toutes les étapes en bouclant sur chaque voyage
        etapes_des_voyages = []
        for v in self.voyages:
            etapes = etapes_crud.get_etapes_by_voyage(v["id_voyage"])
            etapes_des_voyages.extend(etapes)

        # Récupérer toutes les photos en bouclant sur chaque étape
        etapes_photos = []
        for etape in etapes_des_voyages:
            photos = photos_crud.get_photos_by_etape(etape["id_etape"])
            etapes_photos.extend(photos)

        for img_to_gallery in etapes_photos:
            photo_data = img_to_gallery.get("photo")
            if isinstance(photo_data, bytes):
                try:
                    pil_img = Image.open(io.BytesIO(photo_data))
                    gallery_items.append((ctk.CTkImage(light_image=pil_img, size=(200, 200)), img_to_gallery['id_etape']))
                except Exception:
                    pass

        if not gallery_items:
            ctk.CTkLabel(
                gallery_scroll, text="Aucune photo trouvée.", font=("Courgette", 16)
            ).pack(pady=12)
        else:
            cols = 3
            for c in range(cols):
                grid.grid_columnconfigure(c, weight=1, uniform="gal")
            for i, (ctk_image, etape_id) in enumerate(gallery_items):
                r, c = divmod(i, cols)
                lbl = ctk.CTkLabel(grid, text="", image=ctk_image)
                lbl.grid(row=r, column=c, padx=6, pady=4, sticky="nsew")


class View_All_Pictures(ctk.CTkFrame):
    """Sous-page affichant la galerie photos complète de l'utilisateur."""
    def __init__(self, master):
        """Initialise la galerie photos.
        
        Args:
            master: Instance de ViewMyProfilePage parente
        """
        super().__init__(master)
        self.configure(fg_color="transparent")

        top_bar = ctk.CTkFrame(self, fg_color="transparent")
        top_bar.pack(fill="x", pady=(0, 0))

        close_btn = ctk.CTkButton(
            top_bar,
            text="✖",
            width=40,
            height=30,
            fg_color="red",
            hover_color="#aa0000",
            command=lambda: self.master.show_subpage("View_Profil")
        )
        close_btn.pack(side="right", padx=10)

        titre = "Ma galerie photos"
        titre = ctk.CTkLabel(top_bar, text=titre, font=("Courgette", 20, "bold"))
        titre.pack(side="left")

        photos_frame = ctk.CTkFrame(self, fg_color="transparent")
        photos_frame.pack(padx=10, pady=(0, 0), fill="both", expand=True)
        photos_frame.columnconfigure(0, weight=1)
        photos_frame.columnconfigure(1, weight=1)
        photos_frame.columnconfigure(2, weight=1)
        photos_frame.rowconfigure(1, weight=1)

        photo_1 = load_image('landscape1.jpg', (200, 200))
        photo_1_set = ctk.CTkLabel(photos_frame, text="", image=photo_1)
        photo_1_set.grid(row=1, column=0, padx=10, pady=8, sticky="nsew")

        photo_2 = load_image('landscape2.jpg', (200, 200))
        photo_2_set = ctk.CTkLabel(photos_frame, text="", image=photo_2)
        photo_2_set.grid(row=1, column=1, padx=10, pady=8, sticky="nsew")

        photo_3 = load_image('landscape3.webp', (200, 200))
        photo_3_set = ctk.CTkLabel(photos_frame, text="", image=photo_3)
        photo_3_set.grid(row=1, column=2, padx=10, pady=8, sticky="nsew")


class View_All_Followers(ctk.CTkFrame):
    """Sous-page affichant la liste complète des abonnés de l'utilisateur.
    
    Permet de visualiser, rechercher et naviguer vers les profils des abonnés.
    """
    def __init__(self, master):
        """Initialise la page des abonnés.
        
        Args:
            master: Instance de ViewMyProfilePage parente
        """
        super().__init__(master)
        self.configure(fg_color="transparent")

        # Data - maintenant avec photos incluses
        self.tous_abonnes = list(self.master.liste_abonnées)
        self.filtrés = list(self.tous_abonnes)

        # Header
        top_bar = ctk.CTkFrame(self, fg_color="transparent")
        top_bar.pack(fill="x", pady=(10, 0))

        close_btn = ctk.CTkButton(
            top_bar,
            text="✖",
            width=40,
            height=30,
            fg_color="red",
            hover_color="#aa0000",
            command=lambda: self.master.show_subpage("View_Profil"),
        )
        close_btn.pack(side="right", padx=10)

        titre = ctk.CTkLabel(top_bar, text="Mes abonnés", font=("Courgette", 20, "bold"))
        titre.pack(side="left")

        self.compte_label = ctk.CTkLabel(
            top_bar,
            text=f"{len(self.filtrés)} au total",
            font=("Courgette", 14),
        )
        self.compte_label.pack(side="left", padx=(10, 0))

        # Search
        search_frame = ctk.CTkFrame(self, corner_radius=12)
        search_frame.pack(fill="x", padx=12, pady=(12, 0))
        self.search_entry = ctk.CTkEntry(
            search_frame,
            placeholder_text="Rechercher un abonné...",
            height=36,
            font=("Courgette", 14),
        )
        self.search_entry.pack(fill="x", padx=12, pady=12)
        self.search_entry.bind("<KeyRelease>", self._filtrer)

        # List
        self.list_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.list_frame.pack(fill="both", expand=True, padx=12, pady=12)

        self._construire_liste(self.filtrés)

    def _construire_liste(self, utilisateurs):
        # Clear
        for w in self.list_frame.winfo_children():
            w.destroy()

        if not utilisateurs:
            vide = ctk.CTkLabel(
                self.list_frame,
                text="Aucun abonné trouvé",
                font=("Courgette", 16),
            )
            vide.pack(pady=20)
            self.compte_label.configure(text="0 au total")
            return

        # Image par défaut pour les avatars
        default_avatar = load_image("profil.jpg", (40, 40))

        for i, user_data in enumerate(utilisateurs):
            username = user_data['username']

            item = ctk.CTkFrame(
                self.list_frame,
                corner_radius=12,
                fg_color="#1f1f1f" if i % 2 == 0 else "#232323",
            )
            item.pack(fill="x", padx=4, pady=6)

            left = ctk.CTkFrame(item, fg_color="transparent")
            left.pack(side="left", padx=10, pady=8)

            # Générer l'avatar à partir des données binaires
            avatar_img = create_avatar(user_data.get('photo'))
            avatar = ctk.CTkLabel(left, text="", image=avatar_img if avatar_img else default_avatar)
            avatar.pack(side="left", padx=(0, 10))

            nom = ctk.CTkLabel(left, text=username, font=("Courgette", 16, "bold"))
            nom.pack(side="left")

            btn = ctk.CTkButton(
                item,
                text="Voir",
                width=80,
                height=32,
                fg_color="#2563eb",
                hover_color="#1d4ed8",
                command=lambda u=username: self._open_other_profile(u),
            )
            btn.pack(side="right", padx=10, pady=8)

        self.compte_label.configure(text=f"{len(utilisateurs)} au total")

    def _filtrer(self, _event=None):
        q = self.search_entry.get().strip().lower()
        if not q:
            self.filtrés = list(self.tous_abonnes)
        else:
            self.filtrés = [u for u in self.tous_abonnes if q in u['username'].lower()]
        self._construire_liste(self.filtrés)

    def _open_other_profile(self, target_username: str):
        # Ouvre le profil d'un autre utilisateur
        self.master.master.show_page("ViewOtherProfile", target_username=target_username, force_reload=True)


class View_All_Followings(ctk.CTkFrame):
    """Sous-page affichant la liste complète des abonnements de l'utilisateur.
    
    Permet de visualiser, rechercher et naviguer vers les profils des abonnements.
    """
    def __init__(self, master):
        super().__init__(master)
        self.configure(fg_color="transparent")

        # Data - maintenant avec photos incluses
        self.tous_abonnements = list(self.master.liste_abonnements)
        self.filtrés = list(self.tous_abonnements)

        # Header
        top_bar = ctk.CTkFrame(self, fg_color="transparent")
        top_bar.pack(fill="x", pady=(10, 0))

        close_btn = ctk.CTkButton(
            top_bar,
            text="✖",
            width=40,
            height=30,
            fg_color="red",
            hover_color="#aa0000",
            command=lambda: self.master.show_subpage("View_Profil"),
        )
        close_btn.pack(side="right", padx=10)

        titre = ctk.CTkLabel(top_bar, text="Mes abonnements", font=("Courgette", 20, "bold"))
        titre.pack(side="left")

        self.compte_label = ctk.CTkLabel(
            top_bar,
            text=f"{len(self.filtrés)} au total",
            font=("Courgette", 14),
        )
        self.compte_label.pack(side="left", padx=(10, 0))

        # Search
        search_frame = ctk.CTkFrame(self, corner_radius=12)
        search_frame.pack(fill="x", padx=12, pady=(12, 0))
        self.search_entry = ctk.CTkEntry(
            search_frame,
            placeholder_text="Rechercher un abonnement...",
            height=36,
            font=("Courgette", 14),
        )
        self.search_entry.pack(fill="x", padx=12, pady=12)
        self.search_entry.bind("<KeyRelease>", self._filtrer)

        # List
        self.list_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.list_frame.pack(fill="both", expand=True, padx=12, pady=12)

        self._construire_liste(self.filtrés)

    def _construire_liste(self, utilisateurs):
        # Clear
        for w in self.list_frame.winfo_children():
            w.destroy()

        if not utilisateurs:
            vide = ctk.CTkLabel(
                self.list_frame,
                text="Aucun abonnement trouvé",
                font=("Courgette", 16),
            )
            vide.pack(pady=20)
            self.compte_label.configure(text="0 au total")
            return

        # Image par défaut pour les avatars
        default_avatar = load_image("profil.jpg", (40, 40))

        for i, user_data in enumerate(utilisateurs):
            username = user_data['username']

            item = ctk.CTkFrame(
                self.list_frame,
                corner_radius=12,
                fg_color="#1f1f1f" if i % 2 == 0 else "#232323",
            )
            item.pack(fill="x", padx=4, pady=6)

            left = ctk.CTkFrame(item, fg_color="transparent")
            left.pack(side="left", padx=10, pady=8)

            # Générer l'avatar à partir des données binaires
            avatar_img = create_avatar(user_data.get('photo'))
            avatar = ctk.CTkLabel(left, text="", image=avatar_img if avatar_img else default_avatar)
            avatar.pack(side="left", padx=(0, 10))

            nom = ctk.CTkLabel(left, text=username, font=("Courgette", 16, "bold"))
            nom.pack(side="left")

            btn = ctk.CTkButton(
                item,
                text="Voir",
                width=80,
                height=32,
                fg_color="#2563eb",
                hover_color="#1d4ed8",
                command=lambda u=username: self._open_other_profile(u),
            )
            btn.pack(side="right", padx=10, pady=8)

        self.compte_label.configure(text=f"{len(utilisateurs)} au total")

    def _filtrer(self, _event=None):
        q = self.search_entry.get().strip().lower()
        if not q:
            self.filtrés = list(self.tous_abonnements)
        else:
            self.filtrés = [u for u in self.tous_abonnements if q in u['username'].lower()]
        self._construire_liste(self.filtrés)

    def _open_other_profile(self, target_username: str):
        # Ouvre le profil d'un autre utilisateur
        self.master.master.show_page("ViewOtherProfile", target_username=target_username, force_reload=True)