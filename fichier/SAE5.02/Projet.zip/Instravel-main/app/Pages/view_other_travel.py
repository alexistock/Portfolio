import customtkinter as ctk
from PIL import Image
from typing import List, Optional
import io
from CTkMessagebox import CTkMessagebox
from tkintermapview import TkinterMapView
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter
from backend.crud.voyages import VoyagesCRUD
from backend.crud.accomp import accompCRUD
from backend.crud.users import UsersCRUD 
from backend.crud.etapes import EtapesCRUD
from backend.crud.photo import PhotosCRUD 
from backend.crud.commentaire import CommentairesCRUD
from backend.crud.hashtags import HashtagsCRUD
from backend.crud.likes import likesCRUD
from backend.crud.etape_hashtag import EtapeHashtagCRUD


class ViewOtherTravelView(ctk.CTkFrame):
    """Vue détaillée d'un voyage d'un autre utilisateur.
    
    Affiche les informations du voyage, la carte interactive,
    les accompagnateurs et la liste des étapes avec aperçus.
    """
    def __init__(self, parent, travel_id: int):
        """Initialise la vue détaillée d'un voyage.
        
        Args:
            parent: Widget parent (généralement l'application principale)
            travel_id (int): Identifiant du voyage à afficher
        """
        super().__init__(parent)
        
        #: Référence à l'application principale pour la navigation.
        self.master = parent
        #: ID unique du voyage actuellement affiché.
        self.id_voyage = travel_id
        
        # --- Attributs de données du voyage ---
        self.name_of_travel: Optional[str] = None
        self.beginning_date: Optional[str] = None
        self.end_date: Optional[str] = None
        self.escorts: List[str] = []
        
        #: Liste pour maintenir les références des objets CtkImage des étapes.
        self.stage_photos_refs = []
        
        # --- Initialisation des CRUDs ---
        self.crud_Voyage = VoyagesCRUD()
        self.crud_Accomp = accompCRUD()
        self.crud_Users = UsersCRUD()
        self.crud_Etapes = EtapesCRUD()
        self.crud_Photos = PhotosCRUD()
        self.crud_Commentaire = CommentairesCRUD()
        self.crud_Hashtags = HashtagsCRUD()
        self.crud_Likes = likesCRUD()
        self.crud_EtapeHashtag = EtapeHashtagCRUD()
        
        self.load_travel_data()
        
        # Vérification si le voyage a été chargé et affichage de l'UI
        if not self.name_of_travel:
            # Affichage d'un message d'erreur si l'ID est invalide
            ctk.CTkLabel(self, text=f"Erreur: Le voyage {travel_id} n'existe pas.", text_color="red", font=("Arial", 18, "bold")).pack(pady=50)
            ctk.CTkButton(
                self, 
                text="← Retour à la gestion", 
                command=lambda: self.master.show_page("ManageTravel", force_reload=True),
                width=200, fg_color="#3a3a3a"
            ).pack(pady=20)
            return

        self.setup_ui()
        
    def load_travel_data(self):
        """Charge les données du voyage depuis la base de données.
        
        Récupère les informations du voyage, les dates de départ/arrivée,
        et la liste des accompagnateurs associés.
        """
        voyage_data = self.crud_Voyage.get_voyage(self.id_voyage)
        
        escorts_names = []
        rows = self.crud_Accomp.get_accompagnateurs_by_voyage(self.id_voyage)
        
        if rows:
            for row in rows:
                user = self.crud_Users.get_user(row["id_user"])
                if user:
                    escorts_names.append(user["username"])
        
        if voyage_data:
            # Assignation directe des attributs
            self.name_of_travel = voyage_data["nom_voyage"]
            self.beginning_date = voyage_data["date_depart"]
            self.end_date = voyage_data["date_arrivee"]
            self.escorts = escorts_names

    def setup_ui(self):
        """Configure l'interface utilisateur de la vue voyage.
        
        Crée le header compact, les sections d'informations,
        la carte interactive et la liste des étapes.
        """

        # --- 1. LOGIQUE & DATA ---
        self.map_markers = []
        self.map_path = None
        self.geolocator = Nominatim(user_agent="Instravel")
        self.geocode = RateLimiter(self.geolocator.geocode, min_delay_seconds=1)

        # --- 2. HEADER COMPACT (Titre + Retour) ---
        # On réduit le pady au strict minimum (5, 0)
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.pack(fill="x", padx=20, pady=(10, 0)) 

        # Bouton Retour à gauche
        ctk.CTkButton(
            header_frame, 
            text="←", 
            command=lambda: self.master.show_page("Home", force_reload=True),
            width=40, height=35, # Bouton plus compact (icône seule ou texte court)
            fg_color="#3a3a3a", hover_color="#505050", font=("Arial", 16, "bold"),
        ).pack(side="left")

        # Titre collé au bouton retour
        ctk.CTkLabel(
            header_frame, 
            text=self.name_of_travel,
            font=("Courgette", 28, "bold"), # Taille légèrement réduite pour l'équilibre
            anchor="w"
        ).pack(side="left", padx=15)

        # --- 3. ZONE SCROLLABLE ---
        # On commence le scroll direct après le header
        scroll = ctk.CTkScrollableFrame(self, fg_color=self.cget("fg_color"))
        scroll.pack(padx=10, pady=(5, 10), fill="both", expand=True)

        # --- 4. BLOCS INFOS (Période & Accompagnateurs) ---
        # On réduit le pady ici pour que ce soit "directement en dessous"
        info_wrapper = ctk.CTkFrame(scroll, fg_color="transparent")
        info_wrapper.pack(fill="x", padx=10, pady=(5, 10))

        left_info = ctk.CTkFrame(info_wrapper, fg_color="transparent")
        left_info.pack(side="left", fill="both", expand=True, padx=(0, 5))
        
        right_info = ctk.CTkFrame(info_wrapper, fg_color="transparent")
        right_info.pack(side="right", fill="both", expand=True, padx=(5, 0))

        # Appels des fonctions d'affichage
        self.display_date(left_info)
        self.display_escorts(right_info)

        # --- 5. SECTION CARTE ---
        self.map_frame = ctk.CTkFrame(scroll, fg_color="#2b2b2b", height=400) # Hauteur un peu réduite
        self.map_frame.pack_propagate(False) 
        self.map_frame.pack(fill="x", padx=10, pady=(0, 15))

        self.map_widget = TkinterMapView(self.map_frame, corner_radius=15)
        self.map_widget.pack(fill="both", expand=True, padx=2, pady=2)

        # --- 6. SECTION ÉTAPES ---
        self.stages_wrapper = ctk.CTkFrame(scroll, fg_color="transparent")
        self.stages_wrapper.pack(fill="x", padx=10, pady=(0, 10))
        
        self.display_stages_section(self.stages_wrapper)

    def display_date(self, parent):
        """Affiche la période du voyage dans un cadre.
        
        Args:
            parent: Widget parent pour l'affichage des dates
        """
        frame = ctk.CTkFrame(parent, corner_radius=10, fg_color="#1f1f1f")
        frame.pack(fill="x", pady=10, padx=5)
        
        ctk.CTkLabel(frame, text="🗓️ Période du voyage", font=("Arial", 16, "bold"), text_color="#00aaff").pack(anchor="w", padx=20, pady=(10, 5))
        
        # Frame interne pour aligner les dates
        date_frame = ctk.CTkFrame(frame, fg_color="transparent")
        date_frame.pack(fill="x", padx=15, pady=(5, 15))
        
        # Départ
        ctk.CTkLabel(date_frame, text="Départ :", font=("Arial", 14, "bold"), text_color="#dcdcdc").pack(side="left", padx=(5, 10))
        ctk.CTkLabel(date_frame, text=self.beginning_date, font=("Arial", 14)).pack(side="left")
        
        # Arrivée
        ctk.CTkLabel(date_frame, text="Arrivée :", font=("Arial", 14, "bold"), text_color="#dcdcdc").pack(side="left", padx=(40, 10))
        ctk.CTkLabel(date_frame, text=self.end_date, font=("Arial", 14)).pack(side="left")

    def display_escorts(self, parent):
        """Affiche la liste des accompagnateurs du voyage.
        
        Args:
            parent: Widget parent pour l'affichage des accompagnateurs
        """
        frame = ctk.CTkFrame(parent, corner_radius=10, fg_color="#1f1f1f")
        frame.pack(fill="x", pady=10, padx=5)
        
        ctk.CTkLabel(frame, text="👥 Accompagnateurs", font=("Arial", 16, "bold"), text_color="#00aaff").pack(anchor="w", padx=20, pady=(10, 5))
        
        escorts_frame = ctk.CTkFrame(frame, fg_color="transparent")
        escorts_frame.pack(fill="x", padx=15, pady=(0, 10))

        if self.escorts:
            escorts_text = ", ".join(self.escorts)
            ctk.CTkLabel(escorts_frame, text=escorts_text, font=("Arial", 14), text_color="#dcdcdc", wraplength=350, justify="left").pack(anchor="w", padx=5, pady=5)
        else:
            ctk.CTkLabel(escorts_frame, text="Aucun accompagnateur n'a été ajouté.", font=("Arial", 12), text_color="#bdbdbd").pack(anchor="w", padx=5, pady=10)









    def clear_map(self):
        for m in getattr(self, "map_markers", []):
            try:
                m.delete()
            except Exception:
                pass
        self.map_markers = []
        if getattr(self, "map_path", None):
            try:
                self.map_path.delete()
            except Exception:
                pass
        self.map_path = None




    def update_map(self, etapes):
        if not hasattr(self, "map_widget"):
            return

        self.clear_map()
        coords = []

        for e in etapes:
            loc_query = e.get("localisation")
            if not loc_query:
                continue

            try:
                loc = self.geocode(loc_query, exactly_one=True, timeout=10)
            except Exception:
                loc = None

            if not loc:
                continue

            lat, lon = loc.latitude, loc.longitude
            coords.append((lat, lon))

            try:
                marker = self.map_widget.set_marker(lat, lon, text=e.get("nom_etape") or loc_query)
                self.map_markers.append(marker)
            except Exception:
                pass

        if coords:
            self.map_widget.set_position(coords[0][0], coords[0][1])
            self.map_widget.set_zoom(8 if len(coords) == 1 else 5)

            try:
                self.map_path = self.map_widget.set_path(coords)
            except Exception:
                self.map_path = None

















    # ==== LOGIQUE D'AFFICHAGE ET GESTION DES ÉTAPES ====

    def display_stages_section(self, parent):
        """
        Affiche la section principale des étapes avec le bouton 'Ajouter Étape'.

        :param parent: Le cadre parent (stages_wrapper).
        :type parent: ctk.CTkFrame
        """
        
        stages_frame = ctk.CTkFrame(parent, corner_radius=15, fg_color="#1f1f1f")
        stages_frame.pack(fill="x", pady=10)
        
        header_stages = ctk.CTkFrame(stages_frame, fg_color="transparent")
        header_stages.pack(fill="x", padx=15, pady=10)

        ctk.CTkLabel(header_stages, text="🗺️ Étapes du Voyage", font=("Arial", 18, "bold"), text_color="#00aaff").pack(side="left")
        

        # Conteneur pour la liste des cartes d'étapes 
        self.stages_container = ctk.CTkFrame(stages_frame, fg_color="transparent")
        self.stages_container.pack(fill="x", padx=15, pady=10)
        
        self.load_and_display_stages()

    def load_and_display_stages(self):
        """Charge les données des étapes pour le voyage courant et met à jour l'affichage."""
        
        # Nettoyer l'ancien affichage
        for widget in self.stages_container.winfo_children():
            widget.destroy()
        self.stage_photos_refs.clear()

        # 1. Récupérer toutes les étapes pour ce voyage
        etapes = self.crud_Etapes.get_etapes_by_voyage(self.id_voyage)
        
        if not etapes:
            ctk.CTkLabel(self.stages_container, text="Aucune étape n'a encore été ajoutée.", text_color="#bdbdbd").pack(pady=10)
            return

        # 2. Afficher les étapes sous forme de cartes
        for etape in etapes:
            self.create_stage_card(self.stages_container, etape)
        self.update_map(etapes)

    def create_stage_card(self, parent, etape_data: dict):
        """
        Crée et affiche une carte d'aperçu interactive pour une seule étape.

        :param parent: Le conteneur où la carte doit être placée.
        :type parent: ctk.CTkFrame
        :param etape_data: Dictionnaire contenant les données de l'étape.
        :type etape_data: dict
        """
        
        id_etape = etape_data["id_etape"]
        
        card = ctk.CTkFrame(parent, corner_radius=10, fg_color="#2b2b2b")
        card.pack(fill="x", pady=5)
        card.grid_columnconfigure(1, weight=1)

        # --- Colonne 0: Aperçu de la Photo ---
        photo_blob = self.crud_Photos.get_first_photo_blob_by_etape(id_etape)
        
        img_label = ctk.CTkLabel(card, text="📸", width=80, height=80, fg_color="#3a3a3a")
        img_label.grid(row=0, column=0, rowspan=2, padx=10, pady=10, sticky="n")

        if photo_blob:
            try:
                img = Image.open(io.BytesIO(photo_blob))
                img.thumbnail((70, 70))
                photo_tk = ctk.CTkImage(light_image=img, size=(70, 70))
                img_label.configure(image=photo_tk, text="")
                self.stage_photos_refs.append(photo_tk) # Conserver la référence
            except Exception:
                img_label.configure(text="Erreur img")

        # --- Colonne 1: Infos Texte ---
        title = etape_data.get("nom_etape", "Sans titre")
        location = etape_data.get("localisation", "Localisation inconnue")
        
        ctk.CTkLabel(
            card, text=title, font=("Arial", 15, "bold")
        ).grid(row=0, column=1, sticky="w", padx=10, pady=(10, 2))
        
        ctk.CTkLabel(
            card, text=f"📍 {location}", font=("Arial", 11), text_color="#bdbdbd"
        ).grid(row=1, column=1, sticky="w", padx=10, pady=(0, 10))


        # --- Colonne 2: Boutons d'Action ---
        actions_frame = ctk.CTkFrame(card, fg_color="transparent")
        actions_frame.grid(row=0, column=2, rowspan=2, padx=15, pady=10)

        # Bouton Voir Détail
        ctk.CTkButton(
            actions_frame, text="Voir", width=80,
            command=lambda id=id_etape: self.master.show_page("OtherStageView", id_item=id, force_reload=True)
        ).pack(pady=3)

