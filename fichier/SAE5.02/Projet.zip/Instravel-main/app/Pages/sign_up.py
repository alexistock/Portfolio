"""Page d'inscription (UI).

Ce module contient l'écran permettant de créer un compte utilisateur.
"""

import hashlib
import customtkinter as ctk
from PIL import Image
import re
from backend.crud.users import UsersCRUD

EMAIL_REGEX = r"^[\w\.-]+@[\w\.-]+\.\w+$"


class SignUpPage(ctk.CTkFrame):
    """Écran d'inscription.

    Args:
        master: Application/contrôleur principal gérant la navigation via ``show_page``.
    """

    def __init__(self, master):
        super().__init__(master)

        self.logo = ctk.CTkImage(light_image=Image.open('Images/Logo.jpg'), size=(300, 150))
        self.logo_set = ctk.CTkLabel(self, text="", image=self.logo)
        self.logo_set.place(x=415, y=-30)

        self.auth_img = ctk.CTkImage(light_image=Image.open('Images/Auth_img.png'), size=(320, 569))
        self.auth_img_set = ctk.CTkLabel(self, text="", image=self.auth_img)
        self.auth_img_set.place(x=0, y=0)

        self.username_txt = ctk.CTkLabel(self, text="Nom d'utilisateur :", font=("Courgette", 20))
        self.username_txt.place(x=435, y=180)

        self.username_widget = ctk.CTkEntry(self, width=250)
        self.username_widget.place(x=435, y=210)

        self.mail_txt = ctk.CTkLabel(self, text="Mail :", font=("Courgette", 20))
        self.mail_txt.place(x=435, y=240)

        self.mail_widget = ctk.CTkEntry(self, width=250)
        self.mail_widget.place(x=435, y=270)

        self.password_txt = ctk.CTkLabel(self, text="Mot de passe :", font=("Courgette", 20))
        self.password_txt.place(x=435, y=300)

        self.password_widget = ctk.CTkEntry(self, show="*", width=250)
        self.password_widget.place(x=435, y=330)

        self.login_txt = ctk.CTkLabel(self, text="Inscrit toi pour nous rejoindre !", font=("Courgette", 20))
        self.login_txt.place(x=425, y=125)

        self.inscription_button = ctk.CTkButton(self, width=250, height=40, text="Nous rejoindre !", command=self.valide_inscription)
        self.inscription_button.place(x=435, y=380)

        self.page_inscription = ctk.CTkLabel(self, text="Déjà un compte ? ", font=("Courgette", 14))
        self.page_inscription.place(x=335, y=465)

        self.page_connection_redirect = ctk.CTkLabel(self, text="Se connecter", font=("Courgette", 14), text_color="cyan", cursor="hand2")
        self.page_connection_redirect.place(x=450, y=465)

        self.page_connection_redirect.bind("<Enter>", lambda e: self.page_connection_redirect.configure(font=("Courgette", 14, "underline")))
        self.page_connection_redirect.bind("<Leave>", lambda e: self.page_connection_redirect.configure(font=("Courgette", 14)))
        self.page_connection_redirect.bind("<Button-1>", lambda e: self.master.show_page("SignIn", force_reload=True))

        self.label=None

    def valide_inscription(self):
        """Valide le formulaire, crée l'utilisateur et redirige vers la connexion."""
        crud = UsersCRUD()
        username = self.username_widget.get().strip()
        mail = self.mail_widget.get().strip()
        password = self.password_widget.get().strip()
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        if self.label is not None:
            self.label.destroy()
            self.label=None

        if not username or not mail or not password:
            self.label=ctk.CTkLabel(self, text="⚠️ Remplis tous les champs", text_color="orange")
            self.label.place(x=435, y=420)
            return
        
        if crud.get_user_by_username(username):
            self.label=ctk.CTkLabel(self, text="❌ Nom d'utilisateur déjà utilisé", text_color="red")
            self.label.place(x=435, y=420)
            return

        if not re.match(EMAIL_REGEX, mail):
            self.label=ctk.CTkLabel(self, text="❌ Adresse email invalide", text_color="red")
            self.label.place(x=435, y=420)
            return

        if crud.get_user_by_mail(mail):
            self.label=ctk.CTkLabel(self, text="❌ Email déjà utilisé", text_color="red")
            self.label.place(x=435, y=420)
            return

        try:
            crud.create_user(username=username, mail=mail, password=hashed_password)
            self.inscription_button.destroy()
            self.label=ctk.CTkLabel(self, text="✅ Compte créé avec succès !", text_color="green")
            self.label.place(x=435, y=360)
            self.after(2000, lambda: self.master.show_page("SignIn", force_reload=True))
            if "SignUp" in self.master.pages:
                del self.master.pages["SignUp"]
        except Exception as e:
            self.label=ctk.CTkLabel(self, text=f"❌ Erreur lors de l'inscription, veuillez réessayer", text_color="red")
            self.label.place(x=435, y=400)

