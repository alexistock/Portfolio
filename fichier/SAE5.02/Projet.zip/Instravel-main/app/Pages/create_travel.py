"""Création d'un voyage (UI).

Ce module contient la vue permettant de créer un voyage et d'associer des
accompagnateurs.
"""

import customtkinter as ctk
from tkcalendar import DateEntry
from typing import List, Optional
from backend.crud.voyages import VoyagesCRUD
from backend.crud.accomp import accompCRUD
from backend.crud.users import UsersCRUD

class Travel:
    """Modèle simple (en mémoire) représentant un voyage en cours de création."""

    def __init__(self, name: str = "", start_date: str = "", end_date: str = "",
                 escorts: Optional[List[str]] = None):
        """Initialise un objet :class:`Travel`.

        Args:
            name: Nom du voyage.
            start_date: Date de début (format texte).
            end_date: Date de fin (format texte).
            escorts: Liste des usernames des accompagnateurs.
        """
        self.name = name
        self.start_date = start_date
        self.end_date = end_date
        self.escorts = escorts if escorts else []

class CreateTravelView(ctk.CTkFrame):
    """Vue Tkinter de création de voyage.

    Args:
        parent: Application/contrôleur principal.
        id_user: Identifiant de l'utilisateur propriétaire.
    """

    def __init__(self, parent, id_user: int = None): 
        """Initialise la page et ses dépendances CRUD."""
        super().__init__(parent)
        self.master = parent
        self.id_user = id_user
        self.crud_Voyage = VoyagesCRUD()
        self.crud_Accomp = accompCRUD()
        self.crud_Users = UsersCRUD()
        self.travel = Travel()
        self.escorts: List[str] = []
        self.setup_ui()
        self.id_voyage: Optional[int] = None

    def setup_ui(self):
        """Initialise la mise en page (Header compact + Formulaire)."""
        
        # --- 1. HEADER COMPACT ---
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.pack(fill="x", padx=20, pady=(5, 0)) # Padding haut minimal

        ctk.CTkButton(
            header_frame, 
            text="← Retour", 
            command=lambda: self.master.show_page("Home"),
            width=100, height=32,
            fg_color="#3a3a3a", hover_color="#505050", font=("Arial", 13, "bold"),
        ).pack(side="left")
        
        ctk.CTkLabel(
            header_frame, 
            text="Création d'un Voyage",
            font=("Courgette", 26, "bold")
        ).pack(side="left", padx=20)

        # --- 2. SCROLL PRINCIPAL ---
        self.scroll = ctk.CTkScrollableFrame(self, fg_color=self.cget("fg_color"))
        self.scroll.pack(padx=10, pady=(5, 10), fill="both", expand=True)
        
        # --- 3. SECTIONS (Appels directs sans gros espaces) ---
        # Je garde tout tes appels de fonctions
        self.display_name()
        self.display_dates()
        self.display_escorts()
        self.display_create_button()

    def display_name(self):
        """Affiche la section de saisie du nom du voyage."""
        frame = ctk.CTkFrame(self.scroll, corner_radius=15, fg_color="#1f1f1f")
        frame.pack(fill="x", pady=10, padx=20)
        ctk.CTkLabel(frame, text="Nom du Voyage", font=("Arial", 15, "bold")).pack(anchor="w", padx=15, pady=(10,5))
        self.name_entry = ctk.CTkEntry(frame, width=400, placeholder_text="Nom du Voyage")
        self.name_entry.pack(anchor="w", padx=15, pady=(0,5))
        self.name_error = ctk.CTkLabel(frame, text="", text_color="red", font=("Arial", 12))
        self.name_error.pack(anchor="w", padx=15, pady=(0,10))

    def display_dates(self):
        """Affiche la section de saisie des dates (début/fin)."""
        frame = ctk.CTkFrame(self.scroll, corner_radius=15, fg_color="#1f1f1f")
        frame.pack(fill="x", pady=10, padx=20)
        ctk.CTkLabel(frame, text="Dates du Voyage", font=("Arial", 15, "bold")).pack(anchor="w", padx=15, pady=(10,5))
        date_wrapper = ctk.CTkFrame(frame, fg_color="transparent")
        date_wrapper.pack(anchor="w", padx=15, pady=5)
        ctk.CTkLabel(date_wrapper, text="Début:", font=("Arial", 13, "bold")).pack(side="left", padx=(0,5))
        self.date_debut = DateEntry(date_wrapper, date_pattern="dd/mm/yyyy", width=15)
        self.date_debut.pack(side="left", padx=(0,15), pady=5)
        ctk.CTkLabel(date_wrapper, text="Fin:", font=("Arial", 13, "bold")).pack(side="left", padx=(5,5))
        self.date_fin = DateEntry(date_wrapper, date_pattern="dd/mm/yyyy", width=15)
        self.date_fin.pack(side="left", padx=5, pady=5)
        self.date_error = ctk.CTkLabel(frame, text="", text_color="red", font=("Arial", 12))
        self.date_error.pack(anchor="w", padx=15, pady=(0,10))

    def display_escorts(self):
        """Affiche le bloc accompagnateurs avec une hauteur ajustée au contenu."""
        # On définit height=0 pour que le frame se "colle" à son contenu
        frame = ctk.CTkFrame(self.scroll, corner_radius=15, fg_color="#1f1f1f", height=0)
        frame.pack(fill="x", pady=10, padx=20)
        
        # Titre avec moins d'espace en bas (pady=(10, 2))
        ctk.CTkLabel(
            frame, 
            text="Accompagnateurs", 
            font=("Arial", 15, "bold")
        ).pack(anchor="w", padx=15, pady=(10, 2))
        
        # Conteneur pour l'entrée et le bouton
        top_acc = ctk.CTkFrame(frame, fg_color="transparent")
        top_acc.pack(fill="x", padx=10, pady=(5, 5)) # Marges réduites
        
        self.escort_entry = ctk.CTkEntry(
            top_acc, 
            width=250, 
            placeholder_text="Nom de l'accompagnateur"
        )
        self.escort_entry.pack(side="left", padx=(5, 10))
        
        ctk.CTkButton(
            top_acc, 
            text="Ajouter", 
            width=80,
            command=self.add_escort, 
            fg_color="#00aaff", 
            hover_color="#0088cc"
        ).pack(side="left")

        # Conteneur des badges (est invisible/plat quand il est vide)
        self.badges_container = ctk.CTkFrame(frame, fg_color="transparent", height=0)
        self.badges_container.pack(fill="x", padx=10, pady=0) 

        # Label d'erreur avec pady minimal
        self.escort_error = ctk.CTkLabel(frame, text="", text_color="red", font=("Arial", 11))
        self.escort_error.pack(anchor="w", padx=15, pady=(0, 5))

    def display_create_button(self):
        """Affiche le bouton de création du voyage."""
        ctk.CTkButton(self.scroll, text="Créer le Voyage", command=self.create_travel, height=40, font=("Arial", 16, "bold")).pack(pady=20)

    def add_escort(self):
        """Ajoute un accompagnateur à la liste (validation côté UI + existence utilisateur)."""
        name = self.escort_entry.get().strip()
        if not name:
            return

        if len(self.escorts) >= 8:
            self.escort_error.configure(text="* Maximum 8 accompagnateurs")
            return
        user = self.crud_Users.get_user_by_username(name.strip().lower())
        if not user:
            self.escort_error.configure(text=f"* L'utilisateur '{name}' n'existe pas.")
            return
        self.escorts.append(name) 
        self.escort_entry.delete(0,"end")
        self.display_escorts_list()
        self.escort_error.configure(text="")

    def display_escorts_list(self):
        """Rafraîchit l'affichage des accompagnateurs (badges)."""
        for w in self.badges_container.winfo_children():
            w.destroy()

        for i, acc in enumerate(self.escorts):
            card = ctk.CTkFrame(self.badges_container, corner_radius=10, fg_color="#2b2b2b")
            card.pack(fill="x", pady=3, padx=10)
            ctk.CTkLabel(card, text=acc, font=("Arial", 12)).pack(side="left", padx=10, pady=5)
            ctk.CTkButton(card, text="✕", width=26, height=26, fg_color="red", hover_color="darkred",
                          corner_radius=13, command=lambda idx=i: self.delete_escort(idx)).pack(side="right", padx=10, pady=5)

    def delete_escort(self, idx):
        """Supprime un accompagnateur de la liste."""
        if 0 <= idx < len(self.escorts):
            self.escorts.pop(idx)
            self.display_escorts_list()

    def create_travel(self):
        """Valide le formulaire, crée le voyage en base et associe les accompagnateurs."""
        valid = True
        name = self.name_entry.get().strip()
        if not name:
            self.name_error.configure(text="* Nom obligatoire")
            valid = False
        else:
            self.name_error.configure(text="")

        start = self.date_debut.get_date()
        end = self.date_fin.get_date()
        if start >= end:
            self.date_error.configure(text="* Date début doit être avant date fin")
            valid = False
        else:
            self.date_error.configure(text="")


        self.travel.name = name
        self.travel.start_date = start.strftime("%Y-%m-%d")
        self.travel.end_date = end.strftime("%Y-%m-%d")
        self.travel.escorts = self.escorts
        try:
            print(f"id user = {self.id_user}")
            voyage_id = self.crud_Voyage.create_voyage(
                id_user=self.id_user,
                nom_voyage=self.travel.name,
                date_depart=self.travel.start_date,
                date_arrivee=self.travel.end_date
            )
            self.id_voyage = voyage_id
        except Exception as e:
            self.master.show_page("ErrorPage", error_message=e, redirect_page="CreateTravel", redirect_kwargs={"id_user": self.id_user})
        for escort in self.escorts:
            user = self.crud_Users.get_user_by_username(escort.strip().lower())
            if user:
                try:
                    self.crud_Accomp.create_accompagnateur(user["id_user"], voyage_id)
                except Exception:
                    pass
        self.master.after(2000, lambda: self.master.show_page("Home", force_reload=True))