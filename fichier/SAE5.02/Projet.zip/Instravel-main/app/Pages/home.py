"""Page d'accueil (UI).

Ce module contient l'écran d'accueil affichant des voyages publics, la recherche
et l'accès aux profils/utilisateurs.
"""

from tkinter import *
import tkinter.font as tkFont
import customtkinter as ctk
from PIL import Image, ImageDraw, ImageOps
from backend.crud.users import UsersCRUD
from backend.crud.voyages import VoyagesCRUD
from backend.crud.etapes import EtapesCRUD
from backend.crud.photo import PhotosCRUD
from backend.crud.etape_hashtag import EtapeHashtagCRUD
from backend.crud.hashtags import HashtagsCRUD
from backend.crud.abonnement import AbonnementCRUD
from io import BytesIO
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent 
IMAGES_DIR = BASE_DIR / "Images"

def __init__(self, master, username:str):
    super().__init__(master)
    self.current_view = "voyages"

def load_image(relative_name: str, size: tuple[int, int]) -> ctk.CTkImage:
    """Charge une image depuis le dossier Images et la convertit en :class:`ctk.CTkImage`.

    Args:
        relative_name: Nom du fichier (relatif au dossier Images).
        size: Taille cible (largeur, hauteur).

    Returns:
        Une image CTk redimensionnée. Si le fichier n'existe pas, retourne une image placeholder.
    """
    
    path = IMAGES_DIR / relative_name
    try:
        img = Image.open(path)
    except FileNotFoundError:
        img = Image.new("RGB", size, color=(64, 64, 64))
    return ctk.CTkImage(light_image=img, size=size)

def make_circle(img_input, size=(70, 70)):
    """Construit une image circulaire (RGBA) à partir d'un chemin ou d'un BLOB.

    Args:
        img_input: Chemin de fichier ou bytes (BLOB).
        size: Taille finale (par défaut 70x70).

    Returns:
        Image PIL en mode RGBA avec masque circulaire.
    """
    if isinstance(img_input, bytes):
        img = Image.open(BytesIO(img_input)).convert("RGBA")
    else:
        img = Image.open(img_input).convert("RGBA")
    img = ImageOps.fit(img, size, Image.LANCZOS) 
    
    mask = Image.new("L", size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0, size[0], size[1]), fill=255)
    img.putalpha(mask)
    return img


class HomePage(ctk.CTkFrame):
    """Écran d'accueil.

    Permet d'afficher des voyages publics, rechercher par hashtag/nom, et naviguer
    vers les profils.

    Args:
        master: Application/contrôleur principal gérant la navigation via ``show_page``.
        username: Nom d'utilisateur courant (utilisé par l'UI).
    """

    def __init__(self,master, username:str):
        """Initialise l'écran d'accueil."""
        super().__init__(master)

    
##
# Aside 
        self.aside = ctk.CTkFrame(self, width=170, height=400, corner_radius=20, fg_color="#353638")
        self.aside.place(x=10, y=90)
        self.aside.pack_propagate(False)

        ctk.CTkLabel(self.aside, text="MENU ", font=("Courgette", 20)).pack(pady=(10, 20))

        self.btn_all_voyages = ctk.CTkButton(
            self.aside, text="🌍 Voyages publics", width=150, height=35,
            fg_color="transparent", hover_color="#2b2b2b", anchor="w",
            command=lambda: self.show_voyages(self.get_all_voyages())
        )
        self.btn_all_voyages.pack(pady=5)

        self.btn_users = ctk.CTkButton(
            self.aside, text="👥 Utilisateurs", width=150, height=35,
            fg_color="transparent", hover_color="#2b2b2b", anchor="w",
            command=self.show_users
        )
        self.btn_users.pack(pady=5)

        self.btn_my_travels = ctk.CTkButton(
            self.aside, text="🧳 Mes voyages", width=150, height=35,
            fg_color="transparent", hover_color="#2b2b2b", anchor="w",
            command=self.go_to_my_profile
        )
        self.btn_my_travels.pack(pady=5)

        self.btn_notifications = ctk.CTkButton(
            self.aside, text="🔔 Notifications", width=150, height=35,
            fg_color="transparent", hover_color="#2b2b2b", anchor="w",
            command=self.show_notifications
        )
        self.btn_notifications.pack(pady=5)

        self.btn_add_travel = ctk.CTkButton(
            self.aside, text="➕ Nouveau voyage", width=150, height=35,
            fg_color="transparent", hover_color="#2b2b2b", anchor="w",
            command=lambda: self.master.show_page("CreateTravel", force_reload=True)
        )
        self.btn_add_travel.pack(pady=5)

        
        ctk.CTkLabel(self.aside, text="AUTRE ", font=("Courgette", 18)).pack(pady=(20, 10))

        ctk.CTkButton(
            self.aside, text="❓ Infos ", width=150, height=35,
            fg_color="transparent", hover_color="#2b2b2b", anchor="w",
            command=self.show_help
        ).pack(pady=5)


##
#
        self.voyage_crud = VoyagesCRUD()
        self.etape_crud = EtapesCRUD()
        self.photo_crud = PhotosCRUD()

        self.scrollable_voyages = ctk.CTkScrollableFrame(
            self, width=550, height=380, corner_radius=20, fg_color="#353638"
        )
        self.scrollable_voyages.place(x=200, y=90)

        self.search_bar = ctk.CTkEntry(self, width=400, height = 40, corner_radius=100,placeholder_text=" Recherchez un '#' ou un nom d'utilisateur !")
        self.search_bar.place(x=200, y=20)

        self.show_voyages(self.voyage_crud.get_voyages())

        user = UsersCRUD().get_user_by_username(self.master.current_user)
        photo_data = user.get("photo") if user else None

        if photo_data:
            try:
                circ_img = make_circle(photo_data, size=(70, 70))
            except Exception:
                circ_img = make_circle(IMAGES_DIR / "profil.jpg", size=(70, 70))
        else:
            circ_img = make_circle(IMAGES_DIR / "profil.jpg", size=(70, 70))

        self.circ_ctk_img = ctk.CTkImage(circ_img, size=(70, 70))
        self.profile = ctk.CTkLabel(self, text="", image=self.circ_ctk_img)
        self.profile.place(x=690, y=5)

        self.profile.bind("<Enter>", lambda e: self.profile.configure(font=("Courgette", 20)))
        self.profile.bind("<Leave>", lambda e: self.profile.configure(font=("Courgette", 20)))
        self.profile.bind("<Button-1>", self.go_to_my_profile)


        self.Logo_app = load_image('Logo.jpg', (200,100))
        self.Logo_app_set = ctk.CTkLabel(self, text="", image=self.Logo_app)
        self.Logo_app_set.place(x=0, y=-20)

        self.logo_logout = load_image('Logout.png', (40,40))
        self.logo_logout_set = ctk.CTkLabel(self, text="", image=self.logo_logout)
        self.logo_logout_set.place(x=630, y=20)

        self.logo_logout_set.bind("<Enter>", lambda e: self.logo_logout_set.configure(font=("Courgette", 20, "underline")))
        self.logo_logout_set.bind("<Leave>", lambda e: self.logo_logout_set.configure(font=("Courgette", 20)))
        self.logo_logout_set.bind("<Button-1>", self.logout)

        self.recherche = ctk.CTkLabel(self, text="🔍", font=("Courgette", 20),bg_color="#353638", text_color="cyan", cursor="hand2")
        self.recherche.place(x=558, y=27)

        self.recherche.bind("<Enter>", lambda e: self.recherche.configure(font=("Courgette", 20)))
        self.recherche.bind("<Leave>", lambda e: self.recherche.configure(font=("Courgette", 20)))
        self.recherche.bind("<Button-1>", lambda e: self.rechercher())


    def go_to_my_profile(self, event=None):
        """Navigue vers le profil de l'utilisateur courant."""
        self.master.show_page("ViewMyProfile", force_reload=True)

    def logout(self, event=None):
        """Déconnecte l'utilisateur et retourne à la page de connexion."""
        self.master.current_user = "" 
        self.master.show_page("SignIn", force_reload=True) 

    def get_all_users(self):
        """Retourne la liste des utilisateurs."""
        users_crud = UsersCRUD()
        return users_crud.get_users() 

    def show_help(self):
        """Affiche la page d'aide avec des marges de sécurité pour éviter les coupures."""
        import webbrowser

        # 1. On vide la zone de défilement actuelle
        self.current_view = "help"
        for widget in self.scrollable_voyages.winfo_children():
            widget.destroy()

        # --- 2. HEADER (Bouton Retour + Titre) ---
        # On utilise un petit frame transparent pour aligner proprement le haut
        header = ctk.CTkFrame(self.scrollable_voyages, fg_color="transparent")
        header.pack(fill="x", padx=30, pady=(15, 20))

        ctk.CTkButton(
            header, text="← Retour", 
            command=lambda: self.show_voyages(self.get_all_voyages()),
            width=100, height=32, fg_color="#3a3a3a", font=("Arial", 13, "bold")
        ).pack(side="left")
        
        ctk.CTkLabel(
            header, text="Aide & À Propos",
            font=("Courgette", 32, "bold")
        ).pack(side="left", padx=(40, 0))

        # --- 3. SECTION : LE PROJET ---
        # Titre avec une marge gauche de 40px pour être sûr qu'il ne soit pas coupé
        ctk.CTkLabel(
            self.scrollable_voyages, text="Le Projet", 
            font=("Arial", 20, "bold"), text_color="#00aaff", anchor="w"
        ).pack(fill="x", padx=40, pady=(10, 5))

        # Texte principal avec wraplength réduit (450) pour forcer le retour à la ligne avant le bord
        intro = (
            "Ce projet a été réalisé par une équipe de 7 personnes dans le but de mettre en pratique "
            "le travail collaboratif et la gestion de projet. \n\n"
            "Nous avons conçu une application de gestion de voyages en utilisant Python et une "
            "bibliothèque d'interface graphique moderne. Le concept est celui d'un réseau social "
            "dédié aux voyageurs, permettant de partager des parcours complets et des étapes détaillées."
        )
        ctk.CTkLabel(
            self.scrollable_voyages, text=intro, font=("Arial", 13),
            wraplength=450, justify="left", anchor="w"
        ).pack(fill="x", padx=40, pady=(0, 25))

        # --- 4. SECTION : FONCTIONNALITÉS ---
        ctk.CTkLabel(
            self.scrollable_voyages, text="Fonctionnalités", 
            font=("Arial", 20, "bold"), text_color="#00aaff", anchor="w"
        ).pack(fill="x", padx=40, pady=(10, 5))

        fonctions = (
            "• Social : Partagez vos aventures et interagissez grâce aux abonnements, likes et commentaires.\n\n"
            "• Recherche : Utilisez la page d'accueil pour trouver des amis ou découvrir des voyages via des hashtags.\n\n"
            "• Carte Interactive : Visualisez précisément les itinéraires et les étapes de vos contacts.\n\n"
            "• Sécurité & Vie Privée : Connexion sécurisée par email/mot de passe et option de compte privé."
        )
        ctk.CTkLabel(
            self.scrollable_voyages, text=fonctions, font=("Arial", 13),
            wraplength=450, justify="left", anchor="w"
        ).pack(fill="x", padx=40, pady=(0, 25))

        # --- 5. BOUTON GITHUB ---
        ctk.CTkButton(
            self.scrollable_voyages, text="Lien vers le GitHub",
            command=lambda: webbrowser.open("https://github.com/brioniep/Instravel/"),
            fg_color="#333333", width=200, height=35
        ).pack(pady=20)

    def show_notifications(self):
        """Affiche les notifications (nouveaux abonnés)."""
        self.current_view = "notifications"
        
        for widget in self.scrollable_voyages.winfo_children():
            widget.destroy()

        ctk.CTkLabel(self.scrollable_voyages, text="🔔 Tes Notifications", 
                     font=("Courgette", 24, "bold"), text_color="cyan").pack(pady=20)

        my_id = int(self.master.current_user_id)
        abo_crud = AbonnementCRUD()
        followers = abo_crud.get_followers(my_id) 

        if not followers:
            ctk.CTkLabel(self.scrollable_voyages, text="Aucun nouvel abonné pour le moment.", 
                         font=("Arial", 14), text_color="gray").pack(pady=50)
            return

        for f in followers:
            target_user = f['username']
            
            frame = ctk.CTkFrame(self.scrollable_voyages, fg_color="#2b2b2b", corner_radius=10)
            frame.pack(pady=5, padx=10, fill="x")

            ctk.CTkLabel(frame, text=f"👤 {target_user} s'est abonné à ton profil !", 
                         font=("Arial", 13)).pack(side="left", padx=15, pady=10)

            ctk.CTkButton(
                frame, 
                text="Voir Profil", 
                width=100, 
                height=28, 
                fg_color="#1f538d",
                command=lambda u=target_user: self.master.show_page(
                    "ViewOtherProfile", 
                    target_username=u, 
                    force_reload=True
                )
            ).pack(side="right", padx=10)

    def show_users(self):
        """Affiche la liste des utilisateurs (hors utilisateur courant)."""
        self.current_view = "users" 
        self.search_bar.configure(placeholder_text=" Recherchez un nom d'utilisateur...")
        self.search_bar.delete(0, 'end')
        
        for widget in self.scrollable_voyages.winfo_children():
            widget.destroy()

        all_users = self.get_all_users()
        users = [u for u in all_users if u['username'] != self.master.current_user]

        for u in users:
            target = u['username']
            
            bloc = ctk.CTkFrame(
                self.scrollable_voyages, width=400, height=80,
                corner_radius=10, fg_color="#2b2b2b", cursor="hand2"
            )
            bloc.pack(pady=10, padx=10, fill="x")

            photo_data = u.get("photo")
            img_path = photo_data if photo_data else IMAGES_DIR / "profil.jpg"
            img = ctk.CTkImage(make_circle(img_path, size=(60, 60)), size=(60, 60))

            img_label = ctk.CTkLabel(bloc, text="", image=img)
            img_label.place(x=10, y=10)

            nom_label = ctk.CTkLabel(
                bloc, text=f"{u['username']} ({u.get('nationalite','')})",
                font=("Courgette", 16), anchor="w"
            )
            nom_label.place(x=80, y=20)

            for widget in [bloc, img_label, nom_label]:
                widget.bind("<Button-1>", lambda e, t=target: self.master.show_page(
                    "ViewOtherProfile", 
                    target_username=t, 
                    force_reload=True
                ))

    def show_voyages(self, voyages):
        """Affiche une liste de voyages publics dans la zone scrollable."""
        self.current_view = "voyages"
        self.search_bar.configure(placeholder_text=" Recherchez un '#' ou un nom de voyage !")
        
        for widget in self.scrollable_voyages.winfo_children():
            widget.destroy()

        my_id = int(self.master.current_user_id)
        abo_crud = AbonnementCRUD()
        mutual_ids = {int(u["id_user"]) for u in abo_crud.get_mutuals(my_id)}
        users_crud = UsersCRUD()
        owner_cache: dict[int, dict | None] = {}

        voyages_visibles = []

        for v in voyages:
            owner_id = int(v["id_user"])
            if owner_id == my_id:
                continue

            if owner_id not in owner_cache:
                owner_cache[owner_id] = users_crud.get_user(owner_id)

            owner = owner_cache[owner_id]
            status_raw = (owner.get("status") if owner else None) or "public"
            normalized = str(status_raw).lower().replace("é", "e").replace("è", "e")
            is_private = normalized.startswith("priv")

            # On cache les voyages des profils privés si pas amis (abonnement mutuel).
            if is_private and owner_id not in mutual_ids:
                continue

            voyages_visibles.append(v)

        if not voyages_visibles:
            self._display_error_message("Aucun voyage accessible trouvé.")
            return

        for v in voyages_visibles:
            vid = v["id_voyage"]
            bloc = ctk.CTkFrame(self.scrollable_voyages, height=100, corner_radius=10, fg_color="#2b2b2b", cursor="hand2")
            bloc.pack(pady=10, padx=10, fill="x")

            photo_path = IMAGES_DIR / "landscape2.jpg"
            etapes = self.etape_crud.get_etapes_by_voyage(vid)
            if etapes:
                photos = self.photo_crud.get_photos_by_etape(etapes[0]["id_etape"])
                if photos and photos[0].get("photo"):
                    photo_path = photos[0]["photo"]

            img = ctk.CTkImage(make_circle(photo_path, size=(80, 80)), size=(80, 80))
            img_lbl = ctk.CTkLabel(bloc, text="", image=img)
            img_lbl.place(x=10, y=10)

            titre = ctk.CTkLabel(bloc, text=f"{v['nom_voyage']}\n{v['date_depart']} → {v['date_arrivee']}", 
                                font=("Courgette", 15), justify="left")
            titre.place(x=110, y=20)

            for widget in [bloc, img_lbl, titre]:
                widget.bind("<Button-1>", lambda e, id=vid: self.master.show_page(
                    "ViewOtherTravel", 
                    travel_id=id, 
                    force_reload=True
                ))

    def get_all_voyages(self) -> list[dict]:
        """Retourne tous les voyages."""
        return self.voyage_crud.get_voyages()



    def get_voyages_by_hashtag(self, hashtag_name: str) -> list[dict]:
        """Retourne les voyages liés à un hashtag.

        Args:
            hashtag_name: Nom du hashtag (sans le '#').

        Returns:
            Liste de voyages.
        """
        hashtags_crud = HashtagsCRUD()
        etape_hashtag_crud = EtapeHashtagCRUD()
        voyages_crud = VoyagesCRUD()

        hashtags = hashtags_crud.search_hashtags_By_Name(hashtag_name)
        voyages_ids = set()
        
        for h in hashtags:
            etapes = etape_hashtag_crud.get_etapes_for_hashtag(h["id_hashtag"])
            for e in etapes:
                voyages_ids.add(e["id_voyage"])

        voyages = []
        for vid in voyages_ids:
            v = voyages_crud.get_voyage(vid)
            if v:
                voyages.append(v)
        return voyages

    

    def rechercher(self, event=None):
        """Effectue la recherche selon la vue courante (users/voyages)."""
        recherche = self.search_bar.get().strip().lower()

        if not recherche:
            if self.current_view == "users":
                self.show_users()
            else:
                self.show_voyages(self.get_all_voyages())
            return
        for widget in self.scrollable_voyages.winfo_children():
            widget.destroy()

        
        if self.current_view == "users":
            username_query = recherche[1:].lower() if recherche.startswith("@") else recherche.lower()
            results = [u for u in self.get_all_users() if username_query in u["username"].lower()]
            
            if not results:
                self._display_error_message(f"❌ Aucun utilisateur trouvé pour '{recherche}'")
            else:
                self._display_users_list(results)

        else:
            if recherche.startswith("#"):
                hashtag = recherche[1:].lower()
                results = self.get_voyages_by_hashtag(hashtag)
            else:
                results = [v for v in self.get_all_voyages() if recherche.lower() in v["nom_voyage"].lower()]
            
            if not results:
                self._display_error_message(f"❌ Aucun voyage trouvé pour '{recherche}'")
            else:
                self.show_voyages(results)


    def _display_error_message(self, message):
        """Affiche un message d'erreur dans la zone scrollable."""
        msg = ctk.CTkLabel(
            self.scrollable_voyages,
            text=message,
            font=("Courgette", 16),
            text_color="red"
        )
        msg.pack(pady=20)

    def _display_users_list(self, users):
        """Affiche une liste d'utilisateurs (résultats de recherche)."""
        for u in users:
            target = u['username']
            
            bloc = ctk.CTkFrame(
                self.scrollable_voyages, width=400, height=80,
                corner_radius=10, fg_color="#2b2b2b",
                cursor="hand2" 
            )
            bloc.pack(pady=10, padx=10, fill="x")

            photo_data = u.get("photo")
            try:
                path = photo_data if photo_data else "Images/profil.jpg"
                circ_img = make_circle(path, size=(60, 60))
                img = ctk.CTkImage(circ_img, size=(60, 60))
            except:
                circ_img = make_circle("Images/profil.jpg", size=(60, 60))
                img = ctk.CTkImage(circ_img, size=(60, 60))

            img_label = ctk.CTkLabel(bloc, text="", image=img)
            img_label.image = img
            img_label.place(x=10, y=10)

            nom_label = ctk.CTkLabel(
                bloc, text=f"{u['username']} ({u.get('nationalite', u.get('email', ''))})",
                font=("Courgette", 16), anchor="w"
            )
            nom_label.place(x=80, y=20)
            for widget in [bloc, img_label, nom_label]:
                widget.bind("<Button-1>", lambda e, t=target: self.master.show_page(
                    "ViewOtherProfile", 
                    target_username=t, 
                    force_reload=True
                ))




