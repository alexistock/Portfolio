import customtkinter as ctk

class ErrorPage(ctk.CTkFrame):
    def __init__(self, master, error_message: str, redirect_page: str = "SignIn", redirect_kwargs: dict = {}):
        super().__init__(master)
        
        self.redirect_page = redirect_page
        self.redirect_kwargs = redirect_kwargs

        self.error_label = ctk.CTkLabel(self, text="Error", font=("Courgette", 30), text_color="red")
        self.error_label.pack(pady=(100, 20))

        self.message_label = ctk.CTkLabel(self, text="Une erreur est survenue dans l'application : ", font=("Courgette", 25))
        self.message_label.pack(pady=(0, 20))

        self.error_message_label = ctk.CTkLabel(self, text=error_message, font=("Courgette", 20), text_color="orange")
        self.error_message_label.pack(pady=(0, 50))

        self.back_button = ctk.CTkButton(self, text="Retour page d'accueil", command=self.go_back)
        self.back_button.pack(pady=(0, 100))

    def go_back(self):
        self.master.show_page(self.redirect_page, self.redirect_kwargs, force_reload=True)
