import customtkinter as ctk
from PIL import Image, ImageDraw, ImageOps
from pathlib import Path
from backend.crud.users import UsersCRUD
from backend.crud.abonnement import AbonnementCRUD
from backend.crud.photo import PhotosCRUD
from backend.crud.voyages import VoyagesCRUD
from backend.crud.etapes import EtapesCRUD
import io

BASE_DIR = Path(__file__).resolve().parent.parent
IMAGES_DIR = BASE_DIR / "Images"


def load_image(relative_name: str, size: tuple[int, int]) -> ctk.CTkImage:
    """Charge une image depuis le dossier Images et la convertit en CTkImage.
    
    Args:
        relative_name (str): Nom du fichier image relatif au dossier Images
        size (tuple[int, int]): Taille de l'image (largeur, hauteur)
        
    Returns:
        ctk.CTkImage: Image convertie pour CustomTkinter
    """
    path = IMAGES_DIR / relative_name
    try:
        img = Image.open(path)
    except FileNotFoundError:
        img = Image.new("RGB", size, color=(64, 64, 64))
    return ctk.CTkImage(light_image=img, size=size)


class PrivateContentNotice(ctk.CTkFrame):
    """Widget affichant un message de contenu privé.
    
    Utilisé pour informer l'utilisateur que le contenu est privé
    et inaccessible sans les autorisations appropriées.
    """
    def __init__(self, master, message: str):
        """Initialise le message de contenu privé.
        
        Args:
            master: Widget parent
            message (str): Message à afficher
        """
        super().__init__(master)
        self.configure(fg_color="transparent")
        label = ctk.CTkLabel(self, text=message, font=("Courgette", 16), justify="center", wraplength=560)
        label.pack(expand=True, fill="both", padx=24, pady=24)


class ViewOtherProfilePage(ctk.CTkFrame):
    """Page de profil d'un autre utilisateur avec gestion de la confidentialité.
    
    Cette classe gère l'affichage du profil d'un autre utilisateur,
    en respectant les paramètres de confidentialité (public/privé)
    et les relations d'abonnement mutuel.
    """
    def __init__(self, master, viewer_username: str, target_username: str):
        """Initialise la page de profil d'un autre utilisateur.
        
        Args:
            master: Widget parent (généralement l'application principale)
            viewer_username (str): Nom d'utilisateur de l'utilisateur qui consulte
            target_username (str): Nom d'utilisateur du profil consulté
        """
        super().__init__(master)
        self.configure(corner_radius=0)
        
        self.viewer_username = viewer_username
        self.target_username = target_username
        self.current_subpage = None
        self.current_page_name = None
        
        # Flags de confidentialité
        self.is_private = False
        self.can_view_private_content = True
        self.mutual_follow = False
        self.awaiting_friendship = False
        self.viewer_follows_target = False
        self.target_follows_viewer = False

        # Load user data
        self._load_user_data()
        
        # Show the profile page by default
        self.show_subpage("View_Profil")
    
    def _load_user_data(self):
        """Charge les données utilisateur depuis la base de données.
        
        Récupère les informations du profil cible et du viewer,
        ainsi que les relations d'abonnement entre les deux utilisateurs.
        """
        user = UsersCRUD()
        data_viewer = user.get_user_by_username(self.viewer_username)
        data_target = user.get_user_by_username(self.target_username)

        # Viewer data
        self.viewer_id = None
        if isinstance(data_viewer, dict):
            self.viewer_id = str(data_viewer.get("id_user"))

        # Target data
        self.target_id = None
        self.target_bio = ""
        self.target_nationalite = "Inconnu"
        self.target_photo = None
        self.target_status = "public"

        if isinstance(data_target, dict):
            self.target_id = str(data_target.get("id_user"))

            bio = data_target.get("biographie")
            if bio:
                self.target_bio = str(bio)

            nat = data_target.get("nationalite")
            if nat:
                self.target_nationalite = str(nat)

            photo = data_target.get("photo")
            if photo:
                self.target_photo = photo
            
            status = data_target.get("status")
            if status:
                self.target_status = str(status)

        follow = AbonnementCRUD()
        # Followers and following of the TARGET profile
        abonnées = follow.get_followers(self.target_id)
        self.nb_abonnées = len(abonnées)
        self.liste_abonnées = [a["username"] for a in abonnées]

        abonnements = follow.get_following(self.target_id)
        self.nb_abonnements = len(abonnements)
        self.liste_abonnements = [a["username"] for a in abonnements]

        # Is the viewer already following the target?
        self.viewer_follows_target = (self.viewer_username in self.liste_abonnées)
        # Does the target follow the viewer? (Checking inside target's following list)
        self.target_follows_viewer = (self.viewer_username in self.liste_abonnements)

        self._update_privacy_access()

    def _update_privacy_access(self):
        """Met à jour les flags de confidentialité selon les relations d'abonnement.
        
        Détermine si le viewer peut accéder au contenu privé
        en fonction du statut du profil et des abonnements mutuels.
        """
        status_value = (self.target_status or "public").lower()
        normalized = status_value.replace("é", "e").replace("è", "e")
        self.is_private = normalized.startswith("priv")
        
        viewer_is_owner = (
            self.viewer_id is not None
            and self.target_id is not None
            and str(self.viewer_id) == str(self.target_id)
        )
        
        # Ami = abonnement mutuel
        self.mutual_follow = self.viewer_follows_target and self.target_follows_viewer
        
        # On peut voir si : public, ou c'est nous, ou on est amis
        self.can_view_private_content = (
            not self.is_private
            or viewer_is_owner
            or self.mutual_follow
        )
        
        # En attente : c'est privé, on a follow, mais l'autre n'a pas follow back
        self.awaiting_friendship = (
            self.is_private
            and self.viewer_follows_target
            and not self.mutual_follow
            and not viewer_is_owner
        )

    def toggle_follow(self):
        """Bascule l'état d'abonnement entre le viewer et la cible.
        
        Ajoute ou supprime l'abonnement selon l'état actuel,
        et met à jour les flags de confidentialité.
        """
        if not self.viewer_id or not self.target_id:
            return
        follow = AbonnementCRUD()
        try:
            if self.viewer_follows_target:
                if hasattr(follow, "unfollow"):
                    follow.unfollow(int(self.viewer_id), int(self.target_id))
                elif hasattr(follow, "remove_follow"):
                    follow.remove_follow(int(self.viewer_id), int(self.target_id))
                elif hasattr(follow, "delete"):
                    follow.delete(int(self.viewer_id), int(self.target_id))
                self.viewer_follows_target = False
                if self.viewer_username in self.liste_abonnées:
                    self.liste_abonnées.remove(self.viewer_username)
                if self.nb_abonnées > 0:
                    self.nb_abonnées -= 1
            else:
                if hasattr(follow, "follow"):
                    follow.follow(int(self.viewer_id), int(self.target_id))
                elif hasattr(follow, "add_follow"):
                    follow.add_follow(int(self.viewer_id), int(self.target_id))
                elif hasattr(follow, "create"):
                    follow.create(int(self.viewer_id), int(self.target_id))
                self.viewer_follows_target = True
                if self.viewer_username not in self.liste_abonnées:
                    self.liste_abonnées.append(self.viewer_username)
                self.nb_abonnées += 1
        except Exception:
            pass
        self._update_privacy_access()
        if isinstance(self.current_subpage, View_Profil):
            self.current_subpage.refresh_follow_ui()

    def show_subpage(self, page_name):
        """Affiche une sous-page dans la page de profil.
        
        Args:
            page_name (str): Nom de la sous-page à afficher
        """
        if self.current_subpage:
            self.current_subpage.destroy()
            
        if page_name == "View_Profil":
            self.current_subpage = View_Profil(self)
        elif page_name == "View_All_Pictures":
            # Check privacy before allowing full gallery view
            if self.can_view_private_content:
                self.current_subpage = View_All_Pictures(self)
            else:
                self.current_subpage = PrivateContentNotice(
                    self,
                    message="Ce profil est privé. Vous devez être amis (abonnement mutuel) pour voir ses photos.",
                )
        elif page_name == "View_All_Followers":
            self.current_subpage = View_All_Followers(self)
        elif page_name == "View_All_Followings":
            self.current_subpage = View_All_Followings(self)
        else:
             self.current_subpage = PrivateContentNotice(
                self, message="Section indisponible."
            )
            
        self.current_page_name = page_name
        self.current_subpage.pack(fill="both", expand=True)
    
    def go_back(self):
        """Retourne à la page précédente dans l'application principale."""
        self.master.show_page("Home", force_reload=True)


class View_Profil(ctk.CTkFrame):
    """Sous-page affichant les informations principales du profil d'un autre utilisateur.
    
    Affiche l'avatar, le nom d'utilisateur, la biographie, la nationalité,
    les statistiques d'abonnés/abonnements, ainsi que les onglets Voyages et Galeries.
    """
    def __init__(self, master):
        """Initialise la sous-page de profil.
        
        Args:
            master: Instance de ViewOtherProfilePage parente
        """
        super().__init__(master)
        self.configure(fg_color="transparent")

        def see_all_pictures():
            if not self.master.can_view_private_content:
                return
            self.master.show_subpage("View_All_Pictures")

        def see_all_followers():
            self.master.show_subpage("View_All_Followers")

        def see_all_followings():
            self.master.show_subpage("View_All_Followings")

        # Conteneur principal
        main_frame = ctk.CTkFrame(self, corner_radius=15)
        main_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Header avec bouton retour
        header = ctk.CTkFrame(main_frame, fg_color="transparent")
        header.pack(padx=20, pady=15, fill="x")
        
        # Bouton retour
        back_btn = ctk.CTkButton(
            header, 
            text="← Retour", 
            width=80,
            command=self.master.go_back
        )
        back_btn.grid(row=0, column=0, padx=(0, 10), sticky="w")

        header.grid_columnconfigure(1, minsize=100)
        header.grid_columnconfigure(2, weight=1)
        header.grid_rowconfigure(0, weight=0)
        header.grid_rowconfigure(1, weight=0)
        header.grid_rowconfigure(2, weight=0)

        # Avatar (cercle)
        size = (90, 90)
        img = None
        if self.master.target_photo:
            try:
                # Si c'est des bytes (BLOB)
                if isinstance(self.master.target_photo, (bytes, bytearray)):
                    img = Image.open(io.BytesIO(self.master.target_photo)).convert("RGBA")
                # Si c'est un nom de fichier str
                elif isinstance(self.master.target_photo, str):
                     path = IMAGES_DIR / self.master.target_photo
                     if path.exists():
                         img = Image.open(path).convert("RGBA")
                
                if img:
                    img = ImageOps.fit(img, size, Image.LANCZOS)
            except Exception:
                img = None
        
        if img is None:
            try:
                img = Image.open(IMAGES_DIR / "profil.jpg").convert("RGBA")
                img = ImageOps.fit(img, size, Image.LANCZOS)
            except:
                img = Image.new("RGBA", size, (100, 100, 100, 255))

        mask = Image.new("L", size, 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, size[0], size[1]), fill=255)
        img.putalpha(mask)

        self.profile_img = ctk.CTkImage(light_image=img, size=size)
        self.profile_img_set = ctk.CTkLabel(header, text="", image=self.profile_img)
        self.profile_img_set.grid(row=0, column=1, rowspan=2, padx=(0, 20), sticky="nw")

        # Colonne de droite
        right = ctk.CTkFrame(header, fg_color="transparent")
        right.grid(row=0, column=2, sticky="nwe")
        right.grid_columnconfigure(0, weight=1)
        right.grid_columnconfigure(1, weight=0)

        # Ligne 0: username + bouton follow
        self.username = ctk.CTkLabel(
            right, text=self.master.target_username, font=("Courgette", 22, "bold")
        )
        self.username.grid(row=0, column=0, sticky="w")

        self.follow_btn = ctk.CTkButton(
            right,
            text="",
            width=120,
            height=36,
            command=self.master.toggle_follow,
        )
        self.follow_btn.grid(row=0, column=1, sticky="e", padx=(8, 0))

        # Ligne 1: stats
        stats = ctk.CTkFrame(right, fg_color="transparent")
        stats.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        stats.grid_columnconfigure(0, weight=1, uniform="stats")
        stats.grid_columnconfigure(1, weight=1, uniform="stats")

        def stat_block(parent, col, number, label_text, on_click=None):
            block = ctk.CTkFrame(parent, fg_color="transparent")
            block.grid(row=0, column=col, sticky="ew")
            num_lbl = ctk.CTkLabel(
                block,
                text=str(number),
                font=("Courgette", 20, "bold"),
                cursor="hand2" if on_click else "arrow",
            )
            num_lbl.pack()
            lbl = ctk.CTkLabel(block, text=label_text, font=("Courgette", 14))
            lbl.pack()
            if on_click:
                for w in (block, num_lbl, lbl):
                    w.bind("<Button-1>", lambda _e: on_click())
            return num_lbl

        self.followers_lbl = stat_block(stats, 0, self.master.nb_abonnées, "Abonnés", see_all_followers)
        self.following_lbl = stat_block(stats, 1, self.master.nb_abonnements, "Abonnements", see_all_followings)

        # Bio + nationalité + Message Privacy
        bio_frame = ctk.CTkFrame(header, fg_color="transparent")
        bio_frame.grid(row=2, column=1, columnspan=2, sticky="ew", pady=(8, 0))

        display_bio = self.master.target_bio.strip() if (self.master.target_bio and self.master.target_bio.strip()) else "Aucune bio pour le moment."
        display_nat = f"Pays: {self.master.target_nationalite}" if self.master.target_nationalite else ""

        bio_label = ctk.CTkLabel(
            bio_frame, text=display_bio, font=("Courgette", 14), justify="left", anchor="w", wraplength=740
        )
        bio_label.grid(row=0, column=0, sticky="w")
        
        row_idx = 1
        if display_nat:
            nat_label = ctk.CTkLabel(bio_frame, text=display_nat, font=("Courgette", 13), anchor="w")
            nat_label.grid(row=row_idx, column=0, sticky="w", pady=(4, 0))
            row_idx += 1
            
        # Message d'état du compte (Privé/Public)
        viewer_is_owner = (self.master.viewer_id == self.master.target_id)
        if self.master.is_private:
            if viewer_is_owner:
                privacy_msg = "Profil privé : c'est votre compte."
            elif self.master.mutual_follow:
                privacy_msg = "Profil privé : accès accordé (abonnement mutuel)."
            elif self.master.awaiting_friendship:
                privacy_msg = (
                    f"Profil privé : en attente que {self.master.target_username} s'abonne en retour."
                )
            else:
                privacy_msg = "Profil privé : suivez ce compte pour voir le contenu."
            
            privacy_label = ctk.CTkLabel(
                bio_frame,
                text=privacy_msg,
                font=("Courgette", 12),
                anchor="w",
                justify="left",
                text_color="#facc15" if not self.master.can_view_private_content else "#86efac",
            )
            privacy_label.grid(row=row_idx, column=0, sticky="w", pady=(6, 0))

        # Onglets: Voyages + Galeries
        photos_container = ctk.CTkFrame(main_frame, fg_color="transparent")
        photos_container.pack(padx=20, pady=(0, 0), fill="both", expand=True)

        tabs = ctk.CTkTabview(photos_container)
        tabs.pack(fill="both", expand=True, padx=6, pady=6)

        tabs.add("Voyages")
        tabs.add("Galeries")

        voyages_tab = tabs.tab("Voyages")
        galeries_tab = tabs.tab("Galeries")

        # LOGIQUE DE CONFIDENTIALITÉ POUR LE CONTENU
        if self.master.can_view_private_content:
            self._build_voyages_tab(voyages_tab)
            self._build_galerie_tab(galeries_tab)
        else:
            message = "Ce profil est privé. Devenez amis (abonnement mutuel) pour découvrir ses voyages et ses photos."
            PrivateContentNotice(voyages_tab, message).pack(fill="both", expand=True)
            PrivateContentNotice(galeries_tab, message).pack(fill="both", expand=True)

        # Init UI state for follow button and counts
        self.refresh_follow_ui()

    def _build_voyages_tab(self, parent_tab):
        """Construit l'onglet des voyages avec la liste des voyages de l'utilisateur.
        
        Args:
            parent_tab: Widget parent pour l'onglet des voyages
        """
        voyages_list = ctk.CTkScrollableFrame(parent_tab, fg_color="transparent")
        voyages_list.pack(fill="both", expand=True, padx=4, pady=(0, 0))
        voyage_crud = VoyagesCRUD()
        etapes_crud = EtapesCRUD()
        photos_crud = PhotosCRUD()
        voyages = []
        try:
            for voyage in voyage_crud.get_voyages_by_owner(int(self.master.target_id)):
                cover_img = "landscape2.jpg"
                cover_obj = None
                etapes = etapes_crud.get_etapes_by_voyage(voyage["id_voyage"])
                if etapes:
                    photos = photos_crud.get_photos_by_etape(etapes[0]["id_etape"])
                    if photos and photos[0].get("photo"):
                        try:
                            photo_binary = photos[0]["photo"]
                            img = Image.open(io.BytesIO(photo_binary)).convert("RGBA")
                            img = ImageOps.fit(img, (64, 64), Image.LANCZOS)
                            cover_obj = ctk.CTkImage(light_image=img, size=(64, 64))
                        except Exception:
                            cover_img = "landscape2.jpg"
                voyages.append({
                    "id_voyage": voyage["id_voyage"],
                    "titre": voyage.get("nom_voyage", "Voyage sans titre"),
                    "date": voyage.get("date_depart", ""),
                    "cover": cover_img,
                    "cover_obj": cover_obj
                })
        except Exception:
            pass

        def ouvrir_voyage(v):
            self.master.master.show_page("ViewOtherTravel", travel_id=v['id_voyage'], force_reload=True)

        if not voyages:
             ctk.CTkLabel(voyages_list, text="Aucun voyage pour le moment.").pack(pady=20)

        for i, v in enumerate(voyages):
            item = ctk.CTkFrame(
                voyages_list,
                corner_radius=12,
                fg_color="#1f1f1f" if i % 2 == 0 else "#232323",
            )
            item.pack(fill="x", padx=4, pady=4)

            left = ctk.CTkFrame(item, fg_color="transparent")
            left.pack(side="left", padx=10, pady=6)

            if v.get("cover_obj"):
                cover = v["cover_obj"]
            else:
                cover = load_image(v.get("cover", "landscape1.jpg"), (64, 64))
            cover_lbl = ctk.CTkLabel(left, text="", image=cover)
            cover_lbl.pack(side="left", padx=(0, 10))

            text_col = ctk.CTkFrame(left, fg_color="transparent")
            text_col.pack(side="left")

            titre_lbl = ctk.CTkLabel(text_col, text=v["titre"], font=("Courgette", 16, "bold"))
            titre_lbl.pack(anchor="w")
            date_lbl = ctk.CTkLabel(text_col, text=v.get("date", ""), font=("Courgette", 13))
            date_lbl.pack(anchor="w")

            action_btn = ctk.CTkButton(
                item, text="Ouvrir", width=100, height=32, command=lambda vv=v: ouvrir_voyage(vv)
            )
            action_btn.pack(side="right", padx=10, pady=6)

            for w in (item, left, cover_lbl, text_col, titre_lbl, date_lbl):
                w.configure(cursor="hand2")
                w.bind("<Button-1>", lambda _e, vv=v: ouvrir_voyage(vv))

    def _build_galerie_tab(self, parent_tab):
        """Construit l'onglet de la galerie avec les photos de l'utilisateur.
        
        Args:
            parent_tab: Widget parent pour l'onglet de la galerie
        """
        gallery_scroll = ctk.CTkScrollableFrame(parent_tab, fg_color="transparent")
        gallery_scroll.pack(fill="both", expand=True, padx=4, pady=(0, 0))
        grid = ctk.CTkFrame(gallery_scroll, fg_color="transparent")
        grid.pack(fill="both", expand=True)
        gallery_items: list[tuple[ctk.CTkImage, int]] = []
        voyage_crud = VoyagesCRUD()
        etapes_crud = EtapesCRUD()
        photos_crud = PhotosCRUD()
        self.voyages = voyage_crud.get_voyages_by_owner(self.master.target_id)
        etapes_des_voyages = []
        for v in self.voyages:
            etapes = etapes_crud.get_etapes_by_voyage(v["id_voyage"])
            etapes_des_voyages.extend(etapes)
        etapes_photos = []
        for etape in etapes_des_voyages:
            photos = photos_crud.get_photos_by_etape(etape["id_etape"])
            etapes_photos.extend(photos)
        for img_to_gallery in etapes_photos:
            photo_data = img_to_gallery.get("photo")
            if isinstance(photo_data, bytes):
                try:
                    pil_img = Image.open(io.BytesIO(photo_data))
                    gallery_items.append((ctk.CTkImage(light_image=pil_img, size=(200, 200)), img_to_gallery['id_etape']))
                except Exception:
                    pass
        if not gallery_items:
            ctk.CTkLabel(gallery_scroll, text="Aucune photo trouvée.", font=("Courgette", 16)).pack(pady=12)
        else:
            cols = 3
            for c in range(cols):
                grid.grid_columnconfigure(c, weight=1, uniform="gal")
            for i, (img, etape_id) in enumerate(gallery_items):
                r, c = divmod(i, cols)
                lbl = ctk.CTkLabel(grid, text="", image=img)
                lbl.grid(row=r, column=c, padx=6, pady=4, sticky="nsew")

    def refresh_follow_ui(self):
        """Rafraîchit l'interface utilisateur du bouton d'abonnement.
        
        Met à jour le texte et la couleur du bouton selon l'état d'abonnement
        et le nombre d'abonnés affiché.
        """
        if self.master.viewer_follows_target:
            if self.master.mutual_follow:
                self.follow_btn.configure(text="Amis ✓", fg_color="#3b82f6", hover_color="#2563eb")
            elif self.master.is_private:
                 self.follow_btn.configure(text="En attente", fg_color="#f59e0b", hover_color="#d97706")
            else:
                 self.follow_btn.configure(text="Abonné", fg_color="#374151", hover_color="#4b5563")
        else:
            self.follow_btn.configure(text="S'abonner", fg_color="#22c55e", hover_color="#16a34a")
        self.followers_lbl.configure(text=str(self.master.nb_abonnées))


class View_All_Pictures(ctk.CTkFrame):
    """Sous-page affichant la galerie photos complète d'un autre utilisateur.
    
    Affiche uniquement les photos si l'utilisateur a l'autorisation
    de voir le contenu privé du profil consulté.
    """
    def __init__(self, master):
        """Initialise la galerie photos d'un autre utilisateur.
        
        Args:
            master: Instance de ViewOtherProfilePage parente
        """
        super().__init__(master)
        self.configure(fg_color="transparent")

        if not self.master.can_view_private_content:
            notice = PrivateContentNotice(
                self,
                message="Ce profil est privé. Vous devez être amis (abonnement mutuel) pour voir ses photos.",
            )
            notice.pack(fill="both", expand=True, padx=12, pady=12)
            return

        top_bar = ctk.CTkFrame(self, fg_color="transparent")
        top_bar.pack(fill="x", pady=(0, 0))

        close_btn = ctk.CTkButton(
            top_bar, 
            text="✖", 
            width=40, 
            height=30,
            fg_color="red",
            hover_color="#aa0000",
            command=lambda: self.master.show_subpage("View_Profil")
        )
        close_btn.pack(side="right", padx=10)

        titre = "Galerie photos"
        titre = ctk.CTkLabel(top_bar, text=titre, font=("Courgette", 20, "bold"))
        titre.pack(side="left")

        photos_frame = ctk.CTkFrame(self, fg_color="transparent")
        photos_frame.pack(padx=10, pady=(0, 0), fill="both", expand=True)
        photos_frame.columnconfigure(0, weight=1)
        photos_frame.columnconfigure(1, weight=1)
        photos_frame.columnconfigure(2, weight=1)
        photos_frame.rowconfigure(1, weight=1)

        photo_1 = load_image('landscape1.jpg', (200, 200))
        photo_1_set = ctk.CTkLabel(photos_frame, text="", image=photo_1)
        photo_1_set.grid(row=1, column=0, padx=10, pady=8, sticky="nsew")

        photo_2 = load_image('landscape2.jpg', (200, 200))
        photo_2_set = ctk.CTkLabel(photos_frame, text="", image=photo_2)
        photo_2_set.grid(row=1, column=1, padx=10, pady=8, sticky="nsew")

        photo_3 = load_image('landscape3.webp', (200, 200))
        photo_3_set = ctk.CTkLabel(photos_frame, text="", image=photo_3)
        photo_3_set.grid(row=1, column=2, padx=10, pady=8, sticky="nsew")


class View_All_Followers(ctk.CTkFrame):
    """Sous-page affichant la liste complète des abonnés d'un autre utilisateur.
    
    Permet de visualiser et naviguer vers les profils des abonnés
    du profil consulté.
    """
    def __init__(self, master):
        super().__init__(master)
        self.configure(fg_color="transparent")

        # Data
        self.tous_abonnes = list(self.master.liste_abonnées)
        self.filtrés = list(self.tous_abonnes)

        # Header
        top_bar = ctk.CTkFrame(self, fg_color="transparent")
        top_bar.pack(fill="x", pady=(10, 0))

        close_btn = ctk.CTkButton(
            top_bar,
            text="✖",
            width=40,
            height=30,
            fg_color="red",
            hover_color="#aa0000",
            command=lambda: self.master.show_subpage("View_Profil"),
        )
        close_btn.pack(side="right", padx=10)

        titre = ctk.CTkLabel(top_bar, text="Abonnés", font=("Courgette", 20, "bold"))
        titre.pack(side="left")

        self.compte_label = ctk.CTkLabel(
            top_bar,
            text=f"{len(self.filtrés)} au total",
            font=("Courgette", 14),
        )
        self.compte_label.pack(side="left", padx=(10, 0))

        # Search
        search_frame = ctk.CTkFrame(self, corner_radius=12)
        search_frame.pack(fill="x", padx=12, pady=(12, 0))
        self.search_entry = ctk.CTkEntry(
            search_frame,
            placeholder_text="Rechercher un abonné...",
            height=36,
            font=("Courgette", 14),
        )
        self.search_entry.pack(fill="x", padx=12, pady=12)
        self.search_entry.bind("<KeyRelease>", self._filtrer)

        # List
        self.list_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.list_frame.pack(fill="both", expand=True, padx=12, pady=12)

        self._construire_liste(self.filtrés)

    def _construire_liste(self, utilisateurs):
        # Clear
        for w in self.list_frame.winfo_children():
            w.destroy()

        if not utilisateurs:
            vide = ctk.CTkLabel(
                self.list_frame,
                text="Aucun abonné trouvé",
                font=("Courgette", 16),
            )
            vide.pack(pady=20)
            self.compte_label.configure(text="0 au total")
            return

        avatar_img = load_image("profil.jpg", (40, 40))

        for i, username in enumerate(utilisateurs):
            item = ctk.CTkFrame(
                self.list_frame,
                corner_radius=12,
                fg_color="#1f1f1f" if i % 2 == 0 else "#232323",
            )
            item.pack(fill="x", padx=4, pady=6)

            left = ctk.CTkFrame(item, fg_color="transparent")
            left.pack(side="left", padx=10, pady=8)

            avatar = ctk.CTkLabel(left, text="", image=avatar_img)
            avatar.pack(side="left", padx=(0, 10))

            nom = ctk.CTkLabel(left, text=username, font=("Courgette", 16, "bold"))
            nom.pack(side="left")
            
            if username == self.master.viewer_username:
                btn = ctk.CTkButton(
                    item,
                    text="Moi",
                    width=80,
                    height=32,
                    fg_color="#6b7280",
                    hover_color="#4b5563",
                    state="disabled",
                )
            else: 
                btn = ctk.CTkButton(
                    item,
                    text="Voir",
                    width=80,
                    height=32,
                    fg_color="#2563eb",
                    hover_color="#1d4ed8",
                    command=lambda u=username: self._open_other_profile(u),
                )
            btn.pack(side="right", padx=10, pady=8)

        self.compte_label.configure(text=f"{len(utilisateurs)} au total")

    def _filtrer(self, _event=None):
        """Filtre la liste des abonnés selon le texte de recherche.
        
        Args:
            _event: Événement de clavier (non utilisé)
        """
        q = self.search_entry.get().strip().lower()
        if not q:
            self.filtrés = list(self.tous_abonnes)
        else:
            self.filtrés = [u for u in self.tous_abonnes if q in u.lower()]
        self._construire_liste(self.filtrés)

    def _open_other_profile(self, target_username: str):
        self.master.master.show_page(
            "ViewOtherProfile",
            target_username=target_username,
            force_reload=True,
        )


class View_All_Followings(ctk.CTkFrame):
    """Sous-page affichant la liste complète des abonnements d'un autre utilisateur.
    
    Permet de visualiser et naviguer vers les profils des abonnements
    du profil consulté.
    """
    def __init__(self, master):
        super().__init__(master)
        self.configure(fg_color="transparent")

        # Data
        self.tous_abonnements = list(self.master.liste_abonnements)
        self.filtrés = list(self.tous_abonnements)

        # Header
        top_bar = ctk.CTkFrame(self, fg_color="transparent")
        top_bar.pack(fill="x", pady=(10, 0))

        close_btn = ctk.CTkButton(
            top_bar,
            text="✖",
            width=40,
            height=30,
            fg_color="red",
            hover_color="#aa0000",
            command=lambda: self.master.show_subpage("View_Profil"),
        )
        close_btn.pack(side="right", padx=10)

        titre = ctk.CTkLabel(top_bar, text="Abonnements", font=("Courgette", 20, "bold"))
        titre.pack(side="left")

        self.compte_label = ctk.CTkLabel(
            top_bar,
            text=f"{len(self.filtrés)} au total",
            font=("Courgette", 14),
        )
        self.compte_label.pack(side="left", padx=(10, 0))

        # Search
        search_frame = ctk.CTkFrame(self, corner_radius=12)
        search_frame.pack(fill="x", padx=12, pady=(12, 0))
        self.search_entry = ctk.CTkEntry(
            search_frame,
            placeholder_text="Rechercher un abonnement...",
            height=36,
            font=("Courgette", 14),
        )
        self.search_entry.pack(fill="x", padx=12, pady=12)
        self.search_entry.bind("<KeyRelease>", self._filtrer)

        # List
        self.list_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.list_frame.pack(fill="both", expand=True, padx=12, pady=12)

        self._construire_liste(self.filtrés)

    def _construire_liste(self, utilisateurs):
        # Clear
        for w in self.list_frame.winfo_children():
            w.destroy()

        if not utilisateurs:
            vide = ctk.CTkLabel(
                self.list_frame,
                text="Aucun abonnement trouvé",
                font=("Courgette", 16),
            )
            vide.pack(pady=20)
            self.compte_label.configure(text="0 au total")
            return

        avatar_img = load_image("profil.jpg", (40, 40))

        for i, username in enumerate(utilisateurs):
            item = ctk.CTkFrame(
                self.list_frame,
                corner_radius=12,
                fg_color="#1f1f1f" if i % 2 == 0 else "#232323",
            )
            item.pack(fill="x", padx=4, pady=6)

            left = ctk.CTkFrame(item, fg_color="transparent")
            left.pack(side="left", padx=10, pady=8)

            avatar = ctk.CTkLabel(left, text="", image=avatar_img)
            avatar.pack(side="left", padx=(0, 10))

            nom = ctk.CTkLabel(left, text=username, font=("Courgette", 16, "bold"))
            nom.pack(side="left")

            if username == self.master.viewer_username:
                btn = ctk.CTkButton(
                    item,
                    text="Moi",
                    width=80,
                    height=32,
                    fg_color="#6b7280",
                    hover_color="#4b5563",
                    state="disabled",
                )
            else: 
                btn = ctk.CTkButton(
                    item,
                    text="Voir",
                    width=80,
                    height=32,
                    fg_color="#2563eb",
                    hover_color="#1d4ed8",
                    command=lambda u=username: self._open_other_profile(u),
                )
            btn.pack(side="right", padx=10, pady=8)

        self.compte_label.configure(text=f"{len(utilisateurs)} au total")

    def _filtrer(self, _event=None):
        q = self.search_entry.get().strip().lower()
        if not q:
            self.filtrés = list(self.tous_abonnements)
        else:
            self.filtrés = [u for u in self.tous_abonnements if q in u.lower()]
        self._construire_liste(self.filtrés)

    def _open_other_profile(self, target_username: str):
        self.master.master.show_page(
            "ViewOtherProfile",
            target_username=target_username,
            force_reload=True,
        )


if __name__ == "__main__":
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
    root = ctk.CTk()
    root.title("Instravel - Profils")
    root.withdraw()
    win = ViewOtherProfilePage(viewer_username="marie_dubois", target_username="lucas_martin", master=root)
    win.focus()
    root.mainloop()