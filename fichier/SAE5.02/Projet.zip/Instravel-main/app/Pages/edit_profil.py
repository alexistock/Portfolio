"""Édition du profil utilisateur (UI).

Ce module contient l'écran permettant à un utilisateur de modifier son profil :
photo, email, username, biographie, nationalité et statut de confidentialité.
"""

import customtkinter as ctk
from PIL import Image, ImageDraw, ImageOps
import pycountry, hashlib
from tkinter import StringVar, BooleanVar, messagebox, filedialog
from backend.crud.users import UsersCRUD
from io import BytesIO


class EditProfil(ctk.CTkFrame):
    """Écran d'édition du profil.

    Args:
        master: Application/contrôleur principal gérant la navigation via ``show_page``.
        username: Nom d'utilisateur courant.
    """

    def __init__(self, master, username: str):
        """Initialise l'écran et charge les données utilisateur depuis la base."""
        super().__init__(master)

        self.username = username

        # Liste des pays
        self.country_list = []
        for country in pycountry.countries:
            self.country_list.append(country.name)
        self.country_list.sort()

        # Récupération des infos de l'utilisateur
        self.user = UsersCRUD()
        data = self.user.get_user_by_username(self.username)

        self.picture = data.get("photo")  # bytes (BLOB)
        self.id_user = data.get("id_user")
        self.username = data.get("username")
        self.mail = data.get("mail")
        self.password = data.get("password")
        self.bio = data.get("biographie")
        self.nationality = data.get("nationalite")
        self.status = data.get("status")

        # Bouton fermeture
        self.close_btn = ctk.CTkButton(
            self,
            text="✖",
            width=40,
            height=30,
            fg_color="#cc2e2e",
            hover_color="#ff3b3b",
            command=lambda: self.master.show_page("ViewMyProfile", force_reload=True)
        )
        self.close_btn.place(relx=1.0, x=-10, y=16, anchor="ne")

        # Titre
        self.title_label = ctk.CTkLabel(
            self,
            text="⚙️ Modifier mon profil",
            font=("Arial", 26, "bold"),
            anchor="w"
        )
        self.title_label.pack(anchor="w", padx=10, pady=(8, 5))

        # Carte principale
        self.card = ctk.CTkFrame(self, corner_radius=15, fg_color="#1e1e1e")
        self.card.pack(fill="both", expand=True, padx=12, pady=5)
        self.card.grid_columnconfigure((0, 1, 2), weight=1)

        # Photo de profil
        if self.picture:  # si une photo existe en DB
            try:
                img = Image.open(BytesIO(self.picture))
                circ = self._circular_image(img, size=(90, 90))
                self.photo_image = ctk.CTkImage(light_image=circ, size=(90, 90))
            except Exception as e:
                default_square = Image.new("RGBA", (90, 90), (0, 0, 0, 0))
                default_circle = self._circular_image(default_square, size=(90, 90), fill_color=(120, 120, 120, 255))
                self.photo_image = ctk.CTkImage(light_image=default_circle, size=(90, 90))
        else:
            default_square = Image.new("RGBA", (90, 90), (0, 0, 0, 0))
            default_circle = self._circular_image(default_square, size=(90, 90), fill_color=(120, 120, 120, 255))
            self.photo_image = ctk.CTkImage(light_image=default_circle, size=(90, 90))

        self.photo_label = ctk.CTkLabel(self.card, image=self.photo_image, text="")
        self.photo_label.grid(row=1, column=0, padx=16, pady=(12, 6), sticky="n")

        self.change_picture_btn = ctk.CTkButton(
            self.card, text="Changer la photo", command=self.change_picture, height=30
        )
        self.change_picture_btn.grid(row=2, column=0, padx=16, pady=(0, 12), sticky="n")

        # Variables Tkinter
        self.email_var = StringVar(value=self.mail)
        self.username_var = StringVar(value=self.username)
        self.password_var = StringVar(value=self.password)
        self.bio_var = StringVar(value=self.bio)
        is_private = True if self.status is None else (str(self.status).lower() != "public")
        self.private_var = BooleanVar(value=is_private)
        self.nationality_var = StringVar(value=self.nationality)
        self.show_password_var = BooleanVar(value=False)

        # Champs du formulaire
        email_label = ctk.CTkLabel(self.card, text="Adresse email :", anchor="w")
        email_label.grid(row=1, column=1, padx=16, pady=6, sticky="w")
        self.email_entry = ctk.CTkEntry(self.card, textvariable=self.email_var)
        self.email_entry.grid(row=1, column=2, padx=16, pady=6, sticky="ew")

        username_label = ctk.CTkLabel(self.card, text="Nom d'utilisateur :", anchor="w")
        username_label.grid(row=2, column=1, padx=16, pady=6, sticky="w")
        self.username_entry = ctk.CTkEntry(self.card, textvariable=self.username_var)
        self.username_entry.grid(row=2, column=2, padx=16, pady=6, sticky="ew")


        nationality_label = ctk.CTkLabel(self.card, text="Nationalité :", anchor="w")
        nationality_label.grid(row=5, column=1, padx=16, pady=6, sticky="w")
        self.nationality_combobox = ctk.CTkComboBox(
            self.card,
            values=self.country_list,
            variable=self.nationality_var,
            width=260,
        )
        self.nationality_combobox.grid(row=5, column=2, padx=16, pady=6, sticky="ew")
        try:
            self.nationality_combobox._entry.bind("<KeyRelease>", self.filter_countries)
        except Exception:
            pass

        bio_label = ctk.CTkLabel(self.card, text="Biographie :", anchor="w")
        bio_label.grid(row=6, column=1, padx=16, pady=6, sticky="w")
        self.bio_entry = ctk.CTkTextbox(
            self.card,
            height=60,
            fg_color="#343638",
            border_width=2,
            border_color="#565B5E",
        )
        try:
            self.bio_entry.insert("1.0", self.bio if self.bio else "")
        except Exception:
            pass
        self.bio_entry.grid(row=6, column=2, padx=16, pady=6, sticky="ew")

        self.private_check = ctk.CTkCheckBox(
            self.card, text="Rendre le profil privé", variable=self.private_var
        )
        self.private_check.grid(row=7, column=1, columnspan=2, pady=(14, 8), sticky="w", padx=16)

        self.save_btn = ctk.CTkButton(
            self.card, text="💾 Sauvegarder", height=40, corner_radius=10, command=self.save_profile
        )
        self.save_btn.grid(row=8, column=1, columnspan=2, pady=(6, 12), padx=16, sticky="ew")

    def change_picture(self):
        """Permet de sélectionner une nouvelle photo et met à jour l'aperçu."""
        file_path = filedialog.askopenfilename(
            title="Sélectionner une image",
            filetypes=(("Images", "*.png *.jpg *.jpeg"), ("Tous les fichiers", "*.*"))
        )
        if file_path:
            try:
                # Lire l'image en bytes pour stockage DB
                with open(file_path, "rb") as f:
                    self.picture = f.read()

                # Charger avec PIL pour affichage
                image = Image.open(BytesIO(self.picture))
                circ = self._circular_image(image, size=(90, 90))
                self.photo_image = ctk.CTkImage(light_image=circ, size=(90, 90))
                self.photo_label.configure(image=self.photo_image)

            except Exception as e:
                self.master.show_page("ErrorPage", error_message=e, redirect_page="EditProfil", redirect_kwargs={"username": self.username})

    def save_profile(self):
        """Valide les champs et met à jour l'utilisateur en base."""
        nat_input = self.nationality_var.get().strip()
        canonical = self._canonical_country_name(nat_input)
        if canonical is None:
            messagebox.showerror(
                "Nationalité invalide",
                "Le pays saisi n'existe pas. Sélectionnez une nationalité valide dans la liste."
            )
            try:
                self.nationality_combobox.focus_set()
            except Exception:
                pass
            return

        self.nationality_var.set(canonical)

        new_username = self.username_var.get().strip()
        
        # Vérification si le pseudo est déjà pris par quelqu'un d'autre
        if new_username != self.username:
            existing_user = self.user.get_user_by_username(new_username)
            if existing_user:
                messagebox.showerror("Erreur", "Ce nom d'utilisateur est déjà utilisé.")
                return

        new_status = "private" if self.private_var.get() else "public"
        update_user = self.user.update_user(
            id_user=self.id_user,
            username=self.username_var.get(),
            mail=self.email_var.get(),
            nationalite=self.nationality_var.get(),
            photo=self.picture if self.picture else None,  # toujours en bytes
            password=self.password_var.get(),
            biographie=self.bio_entry.get("1.0", "end").strip(),
            status=new_status,
        )

        if update_user:
            self.master.current_user = self.username_var.get()
            self.master.show_page("ViewMyProfile", force_reload=True)
        else:
            messagebox.showerror("Erreur", "La mise à jour du profil a échoué.")


    def change_password(self):
        """Point d'extension: changement de mot de passe."""
        pass

    def filter_countries(self, event=None):
        """Filtre la liste de pays proposée par la combobox (auto-complétion)."""
        text = self.nationality_var.get().strip()
        if not text:
            filtered = self.country_list
        else:
            lower = text.lower()
            filtered = [c for c in self.country_list if c.lower().startswith(lower)]
        self.nationality_combobox.configure(values=filtered if filtered else self.country_list)

    def _circular_image(self, img: Image.Image, size=(90, 90), fill_color=None) -> Image.Image:
        """Construit une image circulaire à partir d'une image PIL.

        Args:
            img: Image PIL source.
            size: Taille finale (largeur, hauteur).
            fill_color: Si défini, génère un disque plein (placeholder) plutôt que d'utiliser `img`.

        Returns:
            Image PIL en mode RGBA.
        """
        w, h = size
        if fill_color is None:
            square = ImageOps.fit(img.convert("RGBA"), (w, h), method=Image.LANCZOS, centering=(0.5, 0.5))
        else:
            square = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        mask = Image.new("L", (w, h), 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, w, h), fill=255)
        if fill_color is None:
            out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            out.paste(square, (0, 0), mask)
        else:
            out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            disc = Image.new("RGBA", (w, h), fill_color)
            out.paste(disc, (0, 0), mask)
        return out

    def _canonical_country_name(self, value: str):
        """Retourne le nom canonique du pays s'il est présent dans la liste."""
        if not value:
            return None
        low = value.lower()
        for name in self.country_list:
            if name.lower() == low:
                return name
        return None

