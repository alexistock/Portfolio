"""Page de vérification et réinitialisation du mot de passe (UI).

Ce module gère la saisie d'un code de vérification puis la mise à jour du mot de passe
de l'utilisateur.
"""

import hashlib
import customtkinter as ctk
from backend.crud.users import UsersCRUD

class ResetPassword(ctk.CTkFrame):
    """Écran de réinitialisation du mot de passe.

    Args:
        master: Application/contrôleur principal gérant la navigation via ``show_page``.
        user: Identifiant utilisateur cible.
        code_verif: Code de vérification attendu.
    """

    def __init__(self, master, user="", code_verif=""):
        """Initialise l'écran de réinitialisation du mot de passe.

        Args:
            master: Application/contrôleur principal gérant la navigation via ``show_page``.
            user: Identifiant utilisateur cible.
            code_verif: Code de vérification attendu.
        """
        super().__init__(master)
        self.user = user
        self.code_verif = code_verif

        self.title = ctk.CTkLabel(self, text="Réinitialisation du mot de passe", font=("Courgette", 20))
        self.title.place (x=150, y=25)

        self.info_label = ctk.CTkLabel(self, text="Veuillez entrer le code de vérification reçu par mail : ", font=("Courgette", 14))
        self.info_label.place(x=50, y=100)

        self.code_entry = ctk.CTkEntry(self, width=250, placeholder_text="Entrez le code de vérification")
        self.code_entry.place(x=175, y=160)

        self.new_password_entry = ctk.CTkEntry(self, width=250, placeholder_text="Entrez votre nouveau mot de passe", show="*")
        self.new_password_verify_entry = ctk.CTkEntry(self, width=250, placeholder_text="Confirmez votre nouveau mot de passe", show="*")

        self.reset_button = ctk.CTkButton(self, text="Valider", command=self.verify_code)
        self.reset_button.place(x=200, y=200)

        self.back_button = ctk.CTkButton(self, text="Retour", command=lambda: self.master.show_page("LostPassword"))
        self.back_button.place(x=0, y=0)

    def verify_code(self):
        """Vérifie le code et affiche les champs de nouveau mot de passe si correct."""
        code = self.code_entry.get().strip()
        if code == str(self.code_verif):
            self.info_label.configure(text="Veuillez entrer votre nouveau mot de passe.", text_color="white")
            self.code_entry.destroy()
            self.new_password_entry.place(x=175, y=150)
            self.new_password_verify_entry.place(x=175, y=200)
            self.reset_button.configure(text="Valider nouveau mot de passe", command=self.reset_password)
            self.reset_button.place(x=200, y=250)
        else:
            self.info_label.configure(text="Code de vérification incorrect.", text_color="red")

    def reset_password(self):
        """Met à jour le mot de passe en base si les deux saisies correspondent."""
        crud = UsersCRUD()
        if self.new_password_entry.get().strip() != self.new_password_verify_entry.get().strip():
            self.info_label.configure(text="Les mots de passe ne correspondent pas.", text_color="red")
        else:
            hashed_password = hashlib.sha256(self.new_password_entry.get().strip().encode()).hexdigest()
            crud.update_user(self.user, password=hashed_password)
            self.info_label.configure(text="Mot de passe réinitialisé avec succès.", text_color="green")
            self.after(2000, lambda: self.master.show_page("SignIn"))
            self.master.geometry("800x500")