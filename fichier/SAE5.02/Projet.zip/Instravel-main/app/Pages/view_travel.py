import customtkinter as ctk
from PIL import Image
from typing import List, Optional
import io
from CTkMessagebox import CTkMessagebox
from tkintermapview import TkinterMapView
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter
from backend.crud.voyages import VoyagesCRUD
from backend.crud.accomp import accompCRUD
from backend.crud.users import UsersCRUD 
from backend.crud.etapes import EtapesCRUD
from backend.crud.photo import PhotosCRUD 
from backend.crud.commentaire import CommentairesCRUD
from backend.crud.hashtags import HashtagsCRUD
from backend.crud.etape_hashtag import EtapeHashtagCRUD


class ViewTravelView(ctk.CTkFrame):
    """Vue détaillée d'un voyage personnel.
    
    Affiche les informations du voyage, la carte interactive,
    les accompagnateurs, et permet de modifier/supprimer le voyage
    et ses étapes.
    """
    def __init__(self, parent, travel_id: int):
        """Initialise la vue détaillée d'un voyage personnel.
        
        Args:
            parent: Widget parent (généralement l'application principale)
            travel_id (int): Identifiant du voyage à afficher
        """
        super().__init__(parent)
        
        #: Référence à l'application principale pour la navigation.
        self.master = parent
        #: ID unique du voyage actuellement affiché.
        self.id_voyage = travel_id
        
        # --- Attributs de données du voyage ---
        self.name_of_travel: Optional[str] = None
        self.beginning_date: Optional[str] = None
        self.end_date: Optional[str] = None
        self.escorts: List[str] = []
        
        #: Liste pour maintenir les références des objets CtkImage des étapes.
        self.stage_photos_refs = []
        
        # --- Initialisation des CRUDs ---
        self.crud_Voyage = VoyagesCRUD()
        self.crud_Accomp = accompCRUD()
        self.crud_Users = UsersCRUD()
        self.crud_Etapes = EtapesCRUD()
        self.crud_Photos = PhotosCRUD()
        self.crud_Commentaire = CommentairesCRUD()
        self.crud_Hashtags = HashtagsCRUD()
        self.crud_EtapeHashtag = EtapeHashtagCRUD()
        
        self.load_travel_data()
        
        if not self.name_of_travel:
            ctk.CTkLabel(self, text=f"Erreur: Le voyage {travel_id} n'existe pas.", text_color="red", font=("Arial", 18, "bold")).pack(pady=50)
            ctk.CTkButton(
                self, 
                text="← Retour à la gestion", 
                command=lambda: self.master.show_page("ManageTravel", force_reload=True),
                width=200, fg_color="#3a3a3a"
            ).pack(pady=20)
            return

        self.setup_ui()
        
    def load_travel_data(self):
        """Charge les données du voyage depuis la base de données.
        
        Récupère les informations du voyage, les dates de départ/arrivée,
        et la liste des accompagnateurs associés.
        """
        voyage_data = self.crud_Voyage.get_voyage(self.id_voyage)
        
        escorts_names = []
        rows = self.crud_Accomp.get_accompagnateurs_by_voyage(self.id_voyage)
        
        if rows:
            for row in rows:
                user = self.crud_Users.get_user(row["id_user"])
                if user:
                    escorts_names.append(user["username"])
        
        if voyage_data:
            self.name_of_travel = voyage_data["nom_voyage"]
            self.beginning_date = voyage_data["date_depart"]
            self.end_date = voyage_data["date_arrivee"]
            self.escorts = escorts_names

    def setup_ui(self):
        """Configure l'interface utilisateur de la vue voyage personnel.
        
        Crée le header avec boutons d'action, les sections d'informations,
        la carte interactive et la liste des étapes avec gestion.
        """
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.pack(fill="x", padx=20, pady=(15, 5))
        
        left_header = ctk.CTkFrame(header_frame, fg_color="transparent")
        left_header.pack(side="left")

        ctk.CTkButton(
            left_header, 
            text="← Retour", 
            command=lambda: self.master.show_page("ViewMyProfile", force_reload=True),
            width=120, height=35, fg_color="#3a3a3a", hover_color="#505050", font=("Arial", 14, "bold"),
        ).pack(side="left")
        
        ctk.CTkLabel(
            header_frame, 
            text=self.name_of_travel,
            font=("Courgette", 32, "bold")
        ).pack(padx=(50, 0), expand=True)

        right_header = ctk.CTkFrame(header_frame, fg_color="transparent")
        right_header.pack(side="right")
        
        ctk.CTkButton(
            right_header, text="✏️ Modifier", width=80, 
            fg_color="orange", hover_color="#cc8800",
            command=lambda id=self.id_voyage: self.master.show_page("EditTravel",force_reload=True, travel_id=id)
        ).pack(side="left", padx=(0, 10))
        
        ctk.CTkButton(
            right_header, text="🗑️ Supprimer", width=80, 
            fg_color="red", hover_color="darkred",
            command=lambda name=self.name_of_travel: self.confirm_delete(name)
        ).pack(side="left")
        
        scroll = ctk.CTkScrollableFrame(self, width=780, height=480, fg_color=self.cget("fg_color"))
        scroll.pack(padx=10, pady=(0, 10), fill="both", expand=True)
        
        content_wrapper = ctk.CTkFrame(scroll, fg_color="transparent")
        content_wrapper.pack(pady=20, padx=20, fill="x")

        left_frame = ctk.CTkFrame(content_wrapper, fg_color="transparent")
        left_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))
        
        right_frame = ctk.CTkFrame(content_wrapper, fg_color="transparent")
        right_frame.pack(side="right", fill="both", expand=True, padx=(10, 0))





        self.map_markers = []
        self.map_path = None


        self.geolocator = Nominatim(user_agent="Instravel")
        self.geocode = RateLimiter(self.geolocator.geocode, min_delay_seconds=1)





        self.map_frame = ctk.CTkFrame(scroll, fg_color="#2b2b2b")
        self.map_frame.configure(height=500)            # hauteur souhaitée
        self.map_frame.pack_propagate(False)            # empêche le frame de se réduire
        self.map_frame.pack(fill="x", expand=False, padx=(10, 20), pady=(0, 20))




        self.map_widget = TkinterMapView(self.map_frame, corner_radius=15, height=480)
        self.map_widget.pack(fill="both", expand=True, padx=5, pady=5)






        self.display_date(left_frame)
        self.display_escorts(right_frame)

        self.stages_wrapper = ctk.CTkFrame(scroll, fg_color="transparent")
        self.stages_wrapper.pack(fill="x", pady=(0, 20), padx=20)
        self.display_stages_section(self.stages_wrapper)

    def display_date(self, parent):
        """Affiche la période du voyage dans un cadre.
        
        Args:
            parent: Widget parent pour l'affichage des dates
        """
        frame = ctk.CTkFrame(parent, corner_radius=10, fg_color="#1f1f1f")
        frame.pack(fill="x", pady=10, padx=5)
        
        ctk.CTkLabel(frame, text="🗓️ Période du voyage", font=("Arial", 16, "bold"), text_color="#00aaff").pack(anchor="w", padx=20, pady=(10, 5))
        
        date_frame = ctk.CTkFrame(frame, fg_color="transparent")
        date_frame.pack(fill="x", padx=15, pady=(5, 15))
        
        ctk.CTkLabel(date_frame, text="Départ :", font=("Arial", 14, "bold"), text_color="#dcdcdc").pack(side="left", padx=(5, 10))
        ctk.CTkLabel(date_frame, text=self.beginning_date, font=("Arial", 14)).pack(side="left")
        
        ctk.CTkLabel(date_frame, text="Arrivée :", font=("Arial", 14, "bold"), text_color="#dcdcdc").pack(side="left", padx=(40, 10))
        ctk.CTkLabel(date_frame, text=self.end_date, font=("Arial", 14)).pack(side="left")

    def display_escorts(self, parent):
        """Affiche la liste des accompagnateurs du voyage.
        
        Args:
            parent: Widget parent pour l'affichage des accompagnateurs
        """
        frame = ctk.CTkFrame(parent, corner_radius=10, fg_color="#1f1f1f")
        frame.pack(fill="x", pady=10, padx=5)
        
        ctk.CTkLabel(frame, text="👥 Accompagnateurs", font=("Arial", 16, "bold"), text_color="#00aaff").pack(anchor="w", padx=20, pady=(10, 5))
        
        escorts_frame = ctk.CTkFrame(frame, fg_color="transparent")
        escorts_frame.pack(fill="x", padx=15, pady=(0, 10))

        if self.escorts:
            escorts_text = ", ".join(self.escorts)
            ctk.CTkLabel(escorts_frame, text=escorts_text, font=("Arial", 14), text_color="#dcdcdc", wraplength=350, justify="left").pack(anchor="w", padx=5, pady=5)
        else:
            ctk.CTkLabel(escorts_frame, text="Aucun accompagnateur n'a été ajouté.", font=("Arial", 12), text_color="#bdbdbd").pack(anchor="w", padx=5, pady=10)









    def clear_map(self):
        for m in getattr(self, "map_markers", []):
            try:
                m.delete()
            except Exception:
                pass
        self.map_markers = []
        if getattr(self, "map_path", None):
            try:
                self.map_path.delete()
            except Exception:
                pass
        self.map_path = None




    def update_map(self, etapes):
        if not hasattr(self, "map_widget"):
            return

        self.clear_map()
        coords = []

        for e in etapes:
            loc_query = e.get("localisation")
            if not loc_query:
                continue

            try:
                loc = self.geocode(loc_query, exactly_one=True, timeout=10)
            except Exception:
                loc = None

            if not loc:
                continue

            lat, lon = loc.latitude, loc.longitude
            coords.append((lat, lon))

            try:
                marker = self.map_widget.set_marker(lat, lon, text=e.get("nom_etape") or loc_query)
                self.map_markers.append(marker)
            except Exception:
                pass

        if coords:
            self.map_widget.set_position(coords[0][0], coords[0][1])
            self.map_widget.set_zoom(8 if len(coords) == 1 else 5)

            try:
                self.map_path = self.map_widget.set_path(coords)
            except Exception:
                self.map_path = None

















    def display_stages_section(self, parent):
        stages_frame = ctk.CTkFrame(parent, corner_radius=15, fg_color="#1f1f1f")
        stages_frame.pack(fill="x", pady=10)
        
        header_stages = ctk.CTkFrame(stages_frame, fg_color="transparent")
        header_stages.pack(fill="x", padx=15, pady=10)

        ctk.CTkLabel(header_stages, text="🗺️ Étapes du Voyage", font=("Arial", 18, "bold"), text_color="#00aaff").pack(side="left")
        
        ctk.CTkButton(
            header_stages, 
            text="+ Ajouter Étape",
            command=lambda: self.master.show_page("CreateStage", id_item=self.id_voyage, force_reload=True),
            width=150,
            fg_color="#00aaff"
        ).pack(side="right")

        self.stages_container = ctk.CTkFrame(stages_frame, fg_color="transparent")
        self.stages_container.pack(fill="x", padx=15, pady=10)
        
        self.load_and_display_stages()

    def load_and_display_stages(self):
        for widget in self.stages_container.winfo_children():
            widget.destroy()
        self.stage_photos_refs.clear()

        etapes = self.crud_Etapes.get_etapes_by_voyage(self.id_voyage)
        
        if not etapes:
            ctk.CTkLabel(self.stages_container, text="Aucune étape n'a encore été ajoutée.", text_color="#bdbdbd").pack(pady=10)
            return

        for etape in etapes:
            self.create_stage_card(self.stages_container, etape)
        self.update_map(etapes)

    def create_stage_card(self, parent, etape_data: dict):
        id_etape = etape_data["id_etape"]
        
        card = ctk.CTkFrame(parent, corner_radius=10, fg_color="#2b2b2b")
        card.pack(fill="x", pady=5)
        card.grid_columnconfigure(1, weight=1)

        photo_blob = self.crud_Photos.get_first_photo_blob_by_etape(id_etape)
        
        img_label = ctk.CTkLabel(card, text="📸", width=80, height=80, fg_color="#3a3a3a")
        img_label.grid(row=0, column=0, rowspan=2, padx=10, pady=10, sticky="n")

        if photo_blob:
            try:
                img = Image.open(io.BytesIO(photo_blob))
                img.thumbnail((70, 70))
                photo_tk = ctk.CTkImage(light_image=img, size=(70, 70))
                img_label.configure(image=photo_tk, text="")
                self.stage_photos_refs.append(photo_tk) # Conserver la référence
            except Exception:
                img_label.configure(text="Erreur img")

        title = etape_data.get("nom_etape", "Sans titre")
        location = etape_data.get("localisation", "Localisation inconnue")
        
        ctk.CTkLabel(
            card, text=title, font=("Arial", 15, "bold")
        ).grid(row=0, column=1, sticky="w", padx=10, pady=(10, 2))
        
        ctk.CTkLabel(
            card, text=f"📍 {location}", font=("Arial", 11), text_color="#bdbdbd"
        ).grid(row=1, column=1, sticky="w", padx=10, pady=(0, 10))


        actions_frame = ctk.CTkFrame(card, fg_color="transparent")
        actions_frame.grid(row=0, column=2, rowspan=2, padx=15, pady=10)

        ctk.CTkButton(
            actions_frame, text="Voir", width=80,
            command=lambda id=id_etape: self.master.show_page("StageView", id_item=id, force_reload=True)
        ).pack(pady=3)
        
        ctk.CTkButton(
            actions_frame, text="Modifier", width=80, fg_color="orange",
            command=lambda id=id_etape: self.master.show_page("EditStage", id_etape=id, force_reload=True)
        ).pack(pady=3)
        
        ctk.CTkButton(
            actions_frame, text="Supprimer", width=80, fg_color="red",
            command=lambda id=id_etape: self.confirm_delete_stage(id)
        ).pack(pady=3)

    def confirm_delete(self, nom_voyage: str):
        msg = CTkMessagebox(
            title="Confirmation de Suppression", 
            message=f"Êtes-vous sûr de vouloir supprimer le voyage '{nom_voyage}' (ID: {self.id_voyage}) ?\n\nTOUTES les données associées (étapes, commentaires, photos, etc.) seront supprimées.",
            icon="question",
            option_1="Annuler",
            option_2="Supprimer Définitivement",
            width=500
        )
        if msg.get() == "Supprimer Définitivement":
            self.delete_travel(self.id_voyage)

    def delete_travel(self, id_voyage: int):
        try:
            self.crud_Accomp.delete_accompagnateurs_by_voyage(id_voyage)
            etapes = self.crud_Etapes.get_etapes_by_voyage(id_voyage)
            etape_ids = [e['id_etape'] for e in etapes]
            self.crud_Photos.delete_photos_by_voyage(id_voyage)
            self.crud_Commentaire.delete_commentaires_by_voyage(id_voyage)
            self.crud_EtapeHashtag.delete_etape_hashtags_by_voyage(id_voyage)
            for id_etape in etape_ids:
                self.crud_Etapes.delete_etape(id_etape)
            success = self.crud_Voyage.delete_voyage(id_voyage)
            if success:
                CTkMessagebox(title="Succès", message="Voyage supprimé.", icon="check")
                self.master.show_page("ViewMyProfile", force_reload=True) 
            else:
                CTkMessagebox(title="Erreur", message="Échec de la suppression du voyage principal.", icon="cancel")
        except Exception as e:
            CTkMessagebox(title="Erreur BDD", message=f"Erreur lors de la suppression en cascade. Erreur : {e}", icon="cancel")

    def confirm_delete_stage(self, id_etape: int):
        msg = CTkMessagebox(
            title="Confirmation de Suppression", 
            message=f"Êtes-vous sûr de vouloir supprimer l'étape ID {id_etape} ?\n\nTous les commentaires et photos associés seront supprimés.",
            icon="question",
            option_1="Annuler",
            option_2="Supprimer Définitivement",
            width=500
        )
        if msg.get() == "Supprimer Définitivement":
            self.delete_stage(id_etape)

    def delete_stage(self, id_etape: int):
        try:
            self.crud_Photos.delete_photos_for_etape(id_etape) 
            self.crud_EtapeHashtag.delete_all_for_etape(id_etape)
            self.crud_Commentaire.delete_commentaires_by_etape(id_etape) 
            success = self.crud_Etapes.delete_etape(id_etape)
            if success:
                CTkMessagebox(title="Succès", message="Étape supprimée avec succès.", icon="check")
            else:
                CTkMessagebox(title="Erreur", message="Échec de la suppression de l'étape principale.", icon="cancel")
            self.load_and_display_stages()
        except Exception as e:
            CTkMessagebox(title="Erreur BDD", message=f"Erreur lors du nettoyage des dépendances de l'étape. Erreur : {e}", icon="cancel")