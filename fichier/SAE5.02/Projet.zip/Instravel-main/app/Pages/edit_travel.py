"""Édition d'un voyage (UI).

Ce module contient la vue permettant de modifier les informations d'un voyage
et de gérer les accompagnateurs.
"""

import customtkinter as ctk
from CTkMessagebox import CTkMessagebox
from tkcalendar import DateEntry 
import datetime 
from backend.crud.voyages import VoyagesCRUD
from backend.crud.accomp import accompCRUD
from backend.crud.users import UsersCRUD
try:
    from app.app import Application
except ImportError:
    class Application: pass 

class EditTravelView(ctk.CTkFrame):
    """Page d'édition d'un voyage existant.

    Permet de modifier les informations de base (nom, dates) et de gérer la liste
    des accompagnateurs.

    Args:
        parent: Référence à l'application principale.
        travel_id: ID unique du voyage à éditer.
    """
    def __init__(self, parent: Application, travel_id: int = 1):
        """Initialise la vue d'édition et charge les données du voyage."""
        super().__init__(parent)
        self.master = parent
        self.id_voyage = travel_id

        self.crud_Voyage = VoyagesCRUD()
        self.crud_Accomp = accompCRUD()
        self.crud_Users = UsersCRUD()
        self.escorts = [] 
        self.is_dirty = False 
        voyage_data = self.crud_Voyage.get_voyage(travel_id)
        if not voyage_data:
            raise ValueError(f"Le voyage {travel_id} n'existe pas !")
        self.travel_name = voyage_data["nom_voyage"]
        self.date_depart = voyage_data["date_depart"]
        self.date_arrivee = voyage_data["date_arrivee"]
        self.load_escorts()
        self.setup_ui()
    def mark_as_dirty(self, *args):
        """Marque l'état comme modifié (utilisé pour prévenir avant de quitter)."""
        self.is_dirty = True
    def check_unsaved_changes(self):
        """Vérifie si des modifications non enregistrées existent avant navigation."""
        if self.is_dirty:

            msg = CTkMessagebox(
                title="Modifications non enregistrées", 
                message="Vous avez des modifications non enregistrées. Voulez-vous abandonner ces changements ?",
                icon="warning",
                option_1="Non",
                option_2="Abandonner"
            )
            response = msg.get()
            if response == "Abandonner":
                self.is_dirty = False 
                self.master.show_page("ViewTravelDetail", travel_id=self.id_voyage, force_reload=True)
        else:
            self.master.show_page("ViewTravelDetail", travel_id=self.id_voyage, force_reload=True)
    def setup_ui(self):
        """Construit l'interface (header + sections + bouton sauvegarde)."""
        header_frame = ctk.CTkFrame(self, fg_color="transparent")

        header_frame.pack(fill="x", padx=20, pady=(15, 5))
        ctk.CTkButton(
            header_frame, 
            text="← Retour", 
            command=self.check_unsaved_changes, 
            width=120,
            height=35,
            fg_color="#3a3a3a", 
            hover_color="#505050",
            font=("Arial", 14, "bold"),
        ).pack(side="left")
        ctk.CTkLabel(
            header_frame, 
            text=f"Modifier : {self.travel_name}",
            font=("Courgette", 32, "bold")
        ).pack(side="left", padx=(50, 0), expand=True)
        self.scroll = ctk.CTkScrollableFrame(self, width=780, height=480, fg_color=self.cget("fg_color"))
        self.scroll.pack(padx=10, pady=(0, 10), fill="both", expand=True)
        self.display_name_dates_section()
        self.display_escorts_section()
        self.display_save_button()
    def display_name_dates_section(self):
        """Affiche la section de modification du nom et des dates."""
        frame = ctk.CTkFrame(self.scroll, corner_radius=15, fg_color="#1f1f1f")

        frame.pack(fill="x", pady=10, padx=20)
        ctk.CTkLabel(frame, text="✏️ Détails du Voyage", font=("Arial", 16, "bold"), text_color="#00aaff").pack(anchor="w", padx=15, pady=(10, 5))
        content_frame = ctk.CTkFrame(frame, fg_color="transparent")
        content_frame.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(content_frame, text="Nom du Voyage", font=("Arial", 13, "bold")).pack(anchor="w", padx=15, pady=(5, 5))
        self.name_entry = ctk.CTkEntry(content_frame, width=300)
        self.name_entry.insert(0, self.travel_name)
        self.name_entry.bind('<KeyRelease>', self.mark_as_dirty) 
        self.name_entry.pack(anchor="w", padx=15, pady=(0, 10))
        date_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
        date_frame.pack(fill="x", padx=15, pady=(5, 10))
        depart_label_frame = ctk.CTkFrame(date_frame, fg_color="transparent")
        depart_label_frame.pack(side="left", padx=(0, 30))
        ctk.CTkLabel(depart_label_frame, text="Départ", font=("Arial", 13, "bold")).pack(anchor="w")
        depart_entry_frame = ctk.CTkFrame(depart_label_frame, fg_color="transparent")
        depart_entry_frame.pack(anchor="w")
        self.date_depart_entry = DateEntry(
            depart_entry_frame, 
            date_pattern='dd/mm/yyyy',
            width=15, 
            bordercolor="#00aaff", 
            foreground='white',
            selectbackground="#00aaff",
            normalbackground="#2b2b2b",
        )
        if self.date_depart:
            if isinstance(self.date_depart, str):
                try:
                    initial_date = datetime.datetime.strptime(self.date_depart, '%Y-%m-%d').date()
                    self.date_depart_entry.set_date(initial_date)
                except ValueError:
                    pass
            elif isinstance(self.date_depart, (datetime.date, datetime.datetime)):
                self.date_depart_entry.set_date(self.date_depart)
        self.date_depart_entry.bind("<<DateEntrySelected>>", self.mark_as_dirty) 
        self.date_depart_entry.pack(side="left")
        arrivee_label_frame = ctk.CTkFrame(date_frame, fg_color="transparent")
        arrivee_label_frame.pack(side="left")
        ctk.CTkLabel(arrivee_label_frame, text="Arrivée", font=("Arial", 13, "bold")).pack(anchor="w")
        arrivee_entry_frame = ctk.CTkFrame(arrivee_label_frame, fg_color="transparent")
        arrivee_entry_frame.pack(anchor="w")
        self.date_arrivee_entry = DateEntry(
            arrivee_entry_frame, 
            date_pattern='dd/mm/yyyy',
            width=15, 
            bordercolor="#00aaff", 
            foreground='white',
            selectbackground="#00aaff",
            normalbackground="#2b2b2b",
        )
        if self.date_arrivee:
            if isinstance(self.date_arrivee, str):
                try:
                    initial_date = datetime.datetime.strptime(self.date_arrivee, '%Y-%m-%d').date()
                    self.date_arrivee_entry.set_date(initial_date)
                except ValueError:
                    pass
            elif isinstance(self.date_arrivee, (datetime.date, datetime.datetime)):
                self.date_arrivee_entry.set_date(self.date_arrivee)
        self.date_arrivee_entry.bind("<<DateEntrySelected>>", self.mark_as_dirty)
        self.date_arrivee_entry.pack(side="left")
    def display_escorts_section(self):
        """Affiche la section de gestion des accompagnateurs."""
        frame = ctk.CTkFrame(self.scroll, corner_radius=15, fg_color="#1f1f1f")

        frame.pack(fill="x", pady=10, padx=20)
        ctk.CTkLabel(frame, text="👥 Gérer les Accompagnateurs", font=("Arial", 16, "bold"), text_color="#00aaff").pack(anchor="w", padx=15, pady=(10, 5))
        top_frame = ctk.CTkFrame(frame, fg_color="transparent")
        top_frame.pack(fill="x", padx=15, pady=5)
        self.escort_entry = ctk.CTkEntry(top_frame, width=250, placeholder_text="Nom accompagnateur")
        self.escort_entry.pack(side="left", padx=(0, 10))
        ctk.CTkButton(top_frame, text="Ajouter", command=self.add_escort, width=100, fg_color="#00aaff", hover_color="#0088cc").pack(side="left")
        self.accomp_container = ctk.CTkFrame(frame, fg_color="transparent")
        self.accomp_container.pack(fill="both", padx=15, pady=10)
        self.display_escorts()
    def display_save_button(self):
        """Affiche le bouton de sauvegarde des modifications."""
        ctk.CTkButton(
            self.scroll, 
            text="💾 Sauvegarder les Modifications", 
            height=40, 
            command=self.save_travel,
            font=("Arial", 16, "bold"),
            fg_color="#00aaff", hover_color="#0088cc"
        ).pack(pady=20)
    def load_escorts(self):
        """Charge la liste des accompagnateurs depuis la base."""
        self.escorts = []

        rows = self.crud_Accomp.get_accompagnateurs_by_voyage(self.id_voyage)
        if rows:
            for row in rows:
                user = self.crud_Users.get_user(row["id_user"]) 
                if user:
                    self.escorts.append({"id_user": row["id_user"], "username": user["username"]})
    def display_escorts(self):
        """Rafraîchit l'affichage des accompagnateurs."""
        for w in self.accomp_container.winfo_children():
            w.destroy()

        for i, acc in enumerate(self.escorts):
            card = ctk.CTkFrame(self.accomp_container, corner_radius=10, fg_color="#2b2b2b")
            card.pack(fill="x", padx=5, pady=5)
            ctk.CTkLabel(card, text=acc["username"], font=("Arial", 13, "bold")).pack(side="left", padx=10, pady=10)
            ctk.CTkButton(
                card, text="Supprimer", width=80, fg_color="red", hover_color="darkred",
                command=lambda idx=i: self.delete_escort(idx)
            ).pack(side="right", padx=10, pady=10)
    def add_escort(self):
        """Ajoute un accompagnateur au voyage (si l'utilisateur existe)."""
        name = self.escort_entry.get().strip()

        if not name:
            return
        user = self.crud_Users.get_user_by_username(name)
        if user is None:
            return
        id_user = user["id_user"]
        self.load_escorts()
        if any(a["id_user"] == id_user for a in self.escorts):
            return
        self.crud_Accomp.create_accompagnateur(id_user=id_user, id_voyage=self.id_voyage)
        self.load_escorts()
        self.display_escorts()
        self.escort_entry.delete(0, 'end')
        self.is_dirty = True 
    def delete_escort(self, index: int):
        """Supprime un accompagnateur du voyage."""
        if 0 <= index < len(self.escorts):

            id_user = self.escorts[index]["id_user"]
            self.crud_Accomp.db.cursor.execute(
                "DELETE FROM accomp WHERE id_user=%s AND id_voyage=%s",
                (id_user, self.id_voyage)
            )
            self.crud_Accomp.db.commit()
            self.load_escorts()
            self.display_escorts()
            self.is_dirty = True 
    def save_travel(self):
        """Sauvegarde les modifications du voyage (nom + dates) en base."""
        try:
            self.travel_name = self.name_entry.get().strip()
            depart_date_obj = self.date_depart_entry.get_date()
            arrivee_date_obj = self.date_arrivee_entry.get_date()
            self.date_depart = depart_date_obj.strftime("%Y-%m-%d") if depart_date_obj else None
            self.date_arrivee = arrivee_date_obj.strftime("%Y-%m-%d") if arrivee_date_obj else None

            self.crud_Voyage.update_voyage(
                id_voyage=self.id_voyage,
                nom_voyage=self.travel_name,
                date_depart=self.date_depart,
                date_arrivee=self.date_arrivee
            )
            self.is_dirty = False
            self.master.show_page("ViewTravelDetail", force_reload=True, travel_id=self.id_voyage)
        except Exception as e:
            CTkMessagebox(title="Erreur de sauvegarde", 
                          message=f"Une erreur est survenue lors de la sauvegarde du voyage: {e}",
                          icon="cancel")