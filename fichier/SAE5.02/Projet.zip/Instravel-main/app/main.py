from app.app import Application

if __name__ == "__main__":
    app = Application()
    app.mainloop()
