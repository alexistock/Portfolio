# Marks 'app' as a Python package.
