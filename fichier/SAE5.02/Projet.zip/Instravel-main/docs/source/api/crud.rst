CRUD module
============

.. automodule:: crud
   :members:
   :undoc-members:
   :show-inheritance:

abonnement module
=================

.. automodule:: crud.abonnement
   :members:
   :undoc-members:
   :show-inheritance:

accomp module
============

.. automodule:: crud.accomp
   :members:
   :undoc-members:
   :show-inheritance:

commentaire module
=================

.. automodule:: crud.commentaire
   :members:
   :undoc-members:
   :show-inheritance:

commentaire_hastag module
========================

.. automodule:: crud.commentaire_hastag
   :members:
   :undoc-members:
   :show-inheritance:

etape_hashtag module
====================

.. automodule:: crud.etape_hashtag
   :members:
   :undoc-members:
   :show-inheritance:

etapes module
==============

.. automodule:: crud.etapes
   :members:
   :undoc-members:
   :show-inheritance:

hashtags module
================

.. automodule:: crud.hashtags
   :members:
   :undoc-members:
   :show-inheritance:

likes module
============

.. automodule:: crud.likes
   :members:
   :undoc-members:
   :show-inheritance:

photo module
============

.. automodule:: crud.photo
   :members:
   :undoc-members:
   :show-inheritance:

users module
============

.. automodule:: crud.users
   :members:
   :undoc-members:
   :show-inheritance:

voyages module
==============

.. automodule:: crud.voyages
   :members:
   :undoc-members:
   :show-inheritance:
