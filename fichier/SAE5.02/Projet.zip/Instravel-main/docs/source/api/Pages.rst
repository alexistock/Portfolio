Pages module
============

.. automodule:: Pages
   :members:
   :undoc-members:
   :show-inheritance:

View_My_Profil module
======================

.. automodule:: Pages.View_My_Profil
   :members:
   :undoc-members:
   :show-inheritance:

View_Other_Profil module
========================

.. automodule:: Pages.View_Other_Profil
   :members:
   :undoc-members:
   :show-inheritance:

view_other_stage module
======================

.. automodule:: Pages.view_other_stage
   :members:
   :undoc-members:
   :show-inheritance:

view_other_travel module
=======================

.. automodule:: Pages.view_other_travel
   :members:
   :undoc-members:
   :show-inheritance:

view_stage module
=================

.. automodule:: Pages.view_stage
   :members:
   :undoc-members:
   :show-inheritance:

view_travel module
==================

.. automodule:: Pages.view_travel
   :members:
   :undoc-members:
   :show-inheritance:

Error_page module
=================

.. automodule:: Pages.Error_page
   :members:
   :undoc-members:
   :show-inheritance:

create_stage module
===================

.. automodule:: Pages.create_stage
   :members:
   :undoc-members:
   :show-inheritance:

create_travel module
====================

.. automodule:: Pages.create_travel
   :members:
   :undoc-members:
   :show-inheritance:

edit_profil module
==================

.. automodule:: Pages.edit_profil
   :members:
   :undoc-members:
   :show-inheritance:

edit_stage module
=================

.. automodule:: Pages.edit_stage
   :members:
   :undoc-members:
   :show-inheritance:

edit_travel module
==================

.. automodule:: Pages.edit_travel
   :members:
   :undoc-members:
   :show-inheritance:

home module
===========

.. automodule:: Pages.home
   :members:
   :undoc-members:
   :show-inheritance:

lost_password module
====================

.. automodule:: Pages.lost_password
   :members:
   :undoc-members:
   :show-inheritance:

reset_password module
=====================

.. automodule:: Pages.reset_password
   :members:
   :undoc-members:
   :show-inheritance:

sign_in module
==============

.. automodule:: Pages.sign_in
   :members:
   :undoc-members:
   :show-inheritance:

sign_up module
==============

.. automodule:: Pages.sign_up
   :members:
   :undoc-members:
   :show-inheritance:
