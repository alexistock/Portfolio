import os
import sys

sys.path.insert(0, os.path.abspath("../../app"))
sys.path.insert(0, os.path.abspath("../../app/backend"))

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = 'Instravel'
copyright = '2025, Léonard - Yanis - Thibaut - Aldéric - Eric - Alexis - Adel'
author = 'Léonard - Yanis - Thibaut - Aldéric - Eric - Alexis - Adel'

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
    "sphinx.ext.autosummary",
]

autosummary_generate = True

autodoc_default_options = {
    "members": True,
    "undoc-members": False,
    "show-inheritance": True,
}

autodoc_mock_imports = [
    "customtkinter",
    "PIL",
    "tkcalendar",
]

templates_path = ['_templates']
exclude_patterns = []

language = 'fr'

# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = 'alabaster'
html_static_path = ['_static']
