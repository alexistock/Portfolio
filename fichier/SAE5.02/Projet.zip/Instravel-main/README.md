# Guide d'installation

## 🐳 Base de données

### Installation de Docker

**Linux:**
```bash
sudo apt-get update
sudo apt-get install docker.io docker-compose
sudo usermod -aG docker $USER
```

**Windows & MacOS:**
Téléchargez [Docker Desktop](https://www.docker.com/products/docker-desktop) et installez-le.



### Initialisation de la base de données

```bash
docker-compose up --build
```

Cette commande créera la base de données à partir du fichier `dump.sql` dans le dossier `backend`.

## 🐍 Environnement Python

### Installation de Conda

Téléchargez [Anaconda](https://www.anaconda.com/download) et installez-le.

### Création de l'environnement

```bash
conda env create -f environment.yml
conda activate Instravel_env
```

## 🚀 Lancement de l'application

```bash
cd app
python app.py
```

## Données par défaut

POur simplifier la suite, nous avons créer des utilisateurs, des voyages et des étapes par défaut afin de ne pas commencer avec une base vide à recréer de zéro.




# Guide d'utilisation

## Architecture de l'application

### 1ère connexion 🔐

Dans le cas d'une première connexion à l'app, il faudra au préalable créer un utilisateur en cliquant sur le lien en bas "S'inscrire".

L'utilisateur sera renvoyé sur la page d'inscription : 

![Page d'inscription](./img-readme/Sign_in.png "Page d'inscription")

Il faudra donc ensuite remplir les formulaires d'entrée :
- **Nom d'utilisateur** : nom affiché pour tous dans l'application
- **Mail** : sert principalement à la connexion
- **Mot de passe** : sécurité du compte

Une fois fait, l'utilisateur sera automatiquement redirigé sur la page de connexion où il devra entrer ses identifiants afin de se connecter à l'application.

### Mot de passe oublié 🔑

Si le mot de passe de l'application a été oublié, l'utilisateur peut cliquer sur le lien "mot de passe oublié".

L'utilisateur devra entrer son adresse mail. Si celle-ci existe et est correcte :
1. Un mail sera automatiquement envoyé avec un code de vérification à 6 chiffres
2. L'utilisateur sera redirigé pour saisir ce code
3. Si le code est correct, il pourra changer son mot de passe

### Connexion à l'application 📱

Pour se connecter, il suffit d'entrer ses identifiants sur la page de connexion (mail et mot de passe). Si ceux-ci sont corrects, l'utilisateur sera redirigé sur la page d'accueil.

### Page d'accueil 🏠

**Menu de gauche** — Accès aux différentes fonctionnalités :
- 🌍 Vue des voyages publics
- 👥 Liste des utilisateurs
- ✈️ Vos voyages
- 🔔 Notifications
- ➕ Création d'un nouveau voyage
- ℹ️ Informations de l'app


![Page d'inscription](./img-readme/Home.png "Page d'inscription")



**Zone centrale** — Affichage par défaut de tous les voyages publics (ou utilisateurs selon la sélection)

**Barre de recherche** 🔍 — La barre de recherche en haut permet la recherche de voyages ou utilisateurs par le nom dans la liste des voyages et des utilisateurs publics, pour cela il suffit de bien sélectionner la bonne catégorie à rechercher (via l'onglet Menu a gauche) et donc d'inscire un nom de voyage ou un utilisateur à rechercher et d'appuyer sur la loupe afin de valider la recherche.


**Haut droit** — Deux boutons :
- 🚪 Déconnexion
- 👤 Profil

---

## Les Voyages ✈️

Pour créer un voyage, accédez à la page d'accueil et cliquez sur "Créer un voyage" dans le menu de gauche. Vous arriverez sur un formulaire demandant le nom, les accompagnateurs, etc.

**Important** : Les étapes s'ajoutent après la création du voyage via votre profil.

## Les Étapes 📍

Une fois le voyage créé, vous pouvez ajouter des étapes avec :
- Nom et description
- Hashtags et photos
- Dates

Les utilisateurs ayant accès à vos voyages peuvent commenter vos étapes et vous pouvez leur répondre dans la section commentaires.

## Le Profil 👤

### Consultation
Visualisez l'ensemble de vos :
- 📂 Voyages
- 👥 Abonnés et abonnements
- 🖼️ Galerie de photos


![Page d'inscription](./img-readme/Profile.png "Page d'inscription")


### Édition ⚙️
Cliquez sur "Configuration" pour modifier :
- Nationalité (obligatoire lors de la 1ère édition)
- Nom (unique)
- Photo de profil
- Adresse mail
- Biographie
- Privé/Publique

### Confidentialité 🔒
Si votre profil est privé, les autres utilisateurs doivent :
1. Être abonnés à vous
2. Vous suivre en retour

Sans cela, ils ne pourront pas accéder à vos voyages.

